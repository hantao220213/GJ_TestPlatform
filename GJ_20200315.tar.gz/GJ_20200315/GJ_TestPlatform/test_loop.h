//
// Created by hantao on 18-12-28.
//

#ifndef GJ_TESTPLATFORM_TEST_LOOP_H
#define GJ_TESTPLATFORM_TEST_LOOP_H

#include "include/pub.h"



class test_loop{

private:
    int count;
    int fd;
    int connfd;
    struct sockaddr_in sockaddr;
    char snd_buff[1024];
    char rcv_buff[1024];

    ev::default_loop *defaultLoop;
    ev::timer testTimer;
    ev::io read_io;
    ev::io write_io;
    ev::timer conn_t;
    mutex mutex1;
public:
    test_loop();
    //test_loop(ev::default_loop *loop);

    ~test_loop();

    void callback_conn(ev::timer &conn_io,int revents);
    void callback_write(ev::io &writ_io, int revents);
    void callback_read(ev::io &read_io,int revents);

    void callback_loop(ev::timer &w,int revents);

    void  start();
    void conn_svr();

//    test_loop &operator=(ev::default_loop *ll);

    void create_thread();

};

#endif //GJ_TESTPLATFORM_TEST_LOOP_H
