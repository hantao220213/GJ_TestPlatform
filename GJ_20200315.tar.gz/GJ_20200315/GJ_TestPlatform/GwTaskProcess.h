//
// Created by hantao on 18-12-13.
//

#ifndef GJ_TESTPLATFORM_GW_TASK_PROCESS_H
#define GJ_TESTPLATFORM_GW_TASK_PROCESS_H

#include "include/pub.h"
#include "include/Glog.h"
#include "common/config.h"
#include "include/ev/ev++.h"
#include "include/GJjson.h"
#include <time.h>
#include <ctime>
/*#define  conPATH "/GJ_TestPlatform/etc/config/GJ_config.ini"*/
#define MAXLEN 1024

#include "ParseJsonFileLock.h"
#include "LockTaskProcess.h"
#include "include/crypt_src.h"
#include "SQLITE3.h"
using namespace SQLITE3;

class Gw_Task_Process: public LockDevice{
private:
    int listenfd;
    ev::io write_io;
    ev::io read_io;
    ev::timer hurt_time;
    ev::timer _timer;
    ev::timer fdout;

    ev::timer next_timer;

    string _data;
    map<string,string>_gw_data;//发生的数据
    map<string,string>_gw_data_repeat;//重复接入使用此数据给_gw_data

    queue<DATA> *gwData;

    string _gw_cmd;
    string _gw_id;
    string _lock_id;
    int _timeInterval;

    string _auth_data;

    int gw_off_sucess;//1-网关正在加入服务器 2-网关加入服务器成功

    uint32_t node_id;

    DH_KEY gw_private_key;
    uint32_t gw_public_key[4];

    DH_KEY old_gw_private_key;
    DH_KEY old_gw_public_key;
    DH_KEY old_key;
    uint8_t cmdsend[1024];

    uint16_t cmdlength;


    u32 auth_data; //服务器下发的随机数
    u32 check_auth_data;

    u32 check_node_random_data; //node_random_data 随机数的校验值
    u8 svr_pulic[DH_KEY_LENGTH]; //服务断的通信密钥
    u8 node_svr_key[DH_KEY_LENGTH];
    DH_KEY key;
    u32 gw_keyword[DH_KEY_LENGTH];

    SVR_ECHO_NOTIFY_VALID_INFO cmd4002;

    u32 svr_public_key[DH_KEY_LENGTH];
    //string next_cmd;
    int link_first;//是否首次接入

    string GW_LOG;
    int n_hap_Port;
    string n_hap_Ip;
    string tmpPort;

    string DownQuestCmd;
    char DownQuestCmdData[1024];

    int hurt_send_off; //1-10S后发送 ,通过此标志控制10s 发送一次心跳包，有交易时不发
    int gw_scond_conn; /* 1- 掉线接入*/
    int lock_data_off;
    int timeout_nun;
    int timeout_flag;
    int read_flag;
    unsigned int rand_data; //更新密钥确认

    unsigned int del_serial_no;
    u8 ucData[1024];
    u16 ucDataLen;

    ev::timer lockStartTimer;
    map<string,string>lockDv;
    string l_file;
    vector<string>id;

    queue<MYLOCK_NODE_FRAME>taskData;
    map<u32 ,MYLOCK_NODE_FRAME>taskWriteData;
    struct sockaddr_in serv_addr;
    string ServerListIp;
    int    ServerListPort;
    string ServerListEdition;
    int sListModule;
    double  startTime;
    double  endTime;
    int sListRunCount;

    ev::timer sListTime;
    ev::io sListW;
    ev::io sListR;
    ev::timer sListO;

    //v2.0
    string rcvServerlistIp;
    int rcvServerlistPort;
    string rcvIdsIp;
    int rcvIdsPort;
    string rcvNhapIp;
    int rcvNhapPort;

    int idCount;

    int gwRequestNhapFlag;

    map<u16,u32>u32ID;

    int lockOnLineFlag;
    SVR_DEL_LOCK_PWD_INFO cmd3007;
    int delPwdSerino;
    u8 pwd_en;
    u8 pwd_op_flag;

    u8 pwd_type;
    u8 pwd_num;

    ev::timer correntTimer;
    u32 cmd1007lockID;

    int gw_first_flag;
    int keyCount;
    sqlite3 *db;
    char **azReuslt;
    char *zErrMsg;
    int nrow;
    int ncolumn;

private:
    void lockStartCallBack(ev::timer &w,int revents);

    int CreateSocket();//创建套节字
    int Conn();//链接服务器

    void gw_callback(ev::timer &w,int revents); //回调事件
    void write_callback(ev::io &m_io,int revents); //io 写事件
    void read_callbaclk(ev::io &m_io,int revents);//io 读事件

    void correntTime_callback(ev::timer &w, int revents);

    void hurt_callbaclk(ev::timer &w,int revents);//心跳 读事件
    void hwrite_callback(ev::io &m_io,int revents); //io 写事件

    void fdout_callbaclk(ev::timer &w,int revents);//超时时间

    void nextConn_callbaclk(ev::timer &w,int revents);

    void setGwCmd(string &cmd);//设置下一条指令

    void setLinkFirst();
    void second_clear();
    void second_conn();
    int getSendData(string &src);//获取发送的数据存入MAP
    int getGwTaskData();//获取指令数据
    int enCodeSendData(unsigned char *cmddata, unsigned short int &cmdLen,unsigned short int &s_cmd,char &ucEncrypt_type);

    int ParseRcvMsg();

    void SvrHurt();

    void setNodeId();

    int  DownQuest(string &cmd, string &l_ID);


    void createLock(int &dvCount);
    int  getTaskQueueData(MYLOCK_NODE_FRAME &mylockNodeFram);
    int  ForwardLockMsg(MYLOCK_NODE_FRAME &mylockNodeFram);
    void PushLockData(MYLOCK_NODE_FRAME &mylockNodeFram,u32 idkey);
    void ParseLockData( char* rcvLockData,string cmd);



    //serverlist
    void sListLoopTimer(ev::timer &w,int revents);
    void sListW_callback(ev::io &m_io,int revents);
    void sListR_callback(ev::io &m_io,int revents);
    void sListO_callback(ev::timer &w,int revents);

    void getSerListConfig();
    int  sListPackge();
    int  sListParsePackge();
    void sListLoopConn(int flag,string msg);
    void sListStart();
    void sListMsgLog(int flag, string msg);

    int RequestRcvSvr(string cmd, u32 lockID);



public:

    Gw_Task_Process();
    ~Gw_Task_Process();
    void  setGwId(string &gwid,int &nhapPORT,string &nhapIP,int &sListMode);
    int setGwTaskData(queue<DATA>&gwata);//设置数据
    int Gw_Task_Process_start();//开始任务

    void setLockDvData(map<string,string> &lockDv,string &l_file,vector<string> &id);

};

#endif //GJ_TESTPLATFORM_GW_TASK_PROCESS_H
