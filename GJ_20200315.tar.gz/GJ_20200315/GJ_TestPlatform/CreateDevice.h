//
// Created by hantao on 18-12-25.
//

#ifndef GJ_TESTPLATFORM_CREATEDEVICE_H
#define GJ_TESTPLATFORM_CREATEDEVICE_H

#include "include/pub.h"
#include "GwTaskProcess.h"
#include "LockTaskProcess.h"

class CreateDevice{
private:
    ev::default_loop dv_loop;
    ev::timer dv_timer;
    ev::io dv_io;
    ev::default_loop *myloop;

public:
    CreateDevice(ev::default_loop *ll);
    ~CreateDevice();

    void DeviceStart();




};


#endif //GJ_TESTPLATFORM_CREATEDEVICE_H
