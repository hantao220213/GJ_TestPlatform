//
// Created by hantao on 18-12-25.
//

#include "CreateDevice.h"
CreateDevice::~CreateDevice() {
    dv_io.stop();
    dv_timer.stop();
    dv_loop.unloop();
}

CreateDevice::CreateDevice(ev::default_loop *ll)
{
    myloop=ll;
}


void CreateDevice::DeviceStart() {

    //创建网关门锁信息
    dv_loop.raw_loop;
    dv_loop.run(4);


}

