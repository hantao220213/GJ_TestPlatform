//
// Created by hantao on 18-12-15.
//

#ifndef GJ_TESTPLATFORM_PARSEJSONFILE_H
#define GJ_TESTPLATFORM_PARSEJSONFILE_H

#include "include/pub.h"
#include "common/config.h"
/*
 * 总数据
 */
class TotalFile
{
private:

    string simulatorName;
    string gwFile;
    string lockFile;
    string scenarioFile;
public:


    TotalFile(string file);
    ~TotalFile();

    void getJsonFileName();

    string getGWFile();
    string getLockFile();
    string getScenarioFile();

};



#endif //GJ_TESTPLATFORM_PARSEJSONFILE_H
