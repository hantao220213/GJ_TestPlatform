//
// Created by hantao on 18-12-15.
//

#include "ParseJsonFileGw.h"
GwDevice::GwDevice()
{
    _comment="";
    deviceName="";
    deviceType="";
    description="";
    params="";

    actionSeriesName="";
    startTime="";
    repeatMode="";

    divFilePath="";
    lockTotal=0;
}
GwDevice::~GwDevice()
{

}
void GwDevice::setDivMsg(string filepath,string divName)
{
    this->divFilePath=filepath;
    this->divName=divName;
}
int GwDevice::getDiveceACTION()
{

    string string1="";
    if (getSimulatorParam(divFilePath, string1) < 0) {
        LOG(ERROR) << " 获取文件:[" << divFilePath << "]失败";
        return -1;
    }
    Json::Reader reader;
    Json::Value value;
    Json::Value value1;
    Json::Value value3;

    reader.parse(string1, value);
    for (int k = 0; k < value.size(); ++k) {
        if (divName != value[k]["deviceName"].asString())
            continue;

        _comment = value[k]["_comment"].asString();
        deviceName = value[k]["deviceName"].asString();
        deviceType = value[k]["deviceType"].asString();
        description = value[k]["description"].asString();
        Json::Value par = value[k]["params"];
        if (!par.empty()){
            //解析params数组,待定
        }

        value1 = value[k]["actionSerials"];
        for (int i = 0; i < value1.size(); ++i)
        {

            actionSeriesName=value1[i]["actionSeriesName"].asString();
            startTime=value1[i]["startTime"].asString();
            repeatMode=value1[i]["repeatMode"].asString();

            Json::Value actions=value1[i]["actions"];

            for (int j = 0; j <actions.size() ; ++j)
            {
                DATA gwaction1;


                Json::Value action = actions[j]["action"];
                Json::Value params1=action["params"];

                gwaction1.action=action["actionName"].asString();
                gwaction1.data=params1.toStyledString();
                gwaction1.timeInterval=actions[j]["timeInterval"].asString();

                /*
                memset(&gwaction1,0x00,sizeof(gwaction1));
                string act=action["actionName"].asString();
                memcpy(gwaction1.action,act.c_str(),act.size());
                string data=params1.toStyledString();
                memcpy(gwaction1.data,data.c_str(),data.size());
                gwaction1.timeInterval=atoi(actions[j]["timeInterval"].asString().c_str());
                */
                GW_DATA.push(gwaction1);

            }

        }

        Json::Value value2;
        value2 = value[k]["locks"];
        int n=value2.size();
        for (int j = 0; j < n; ++j) {
            gwAndLock.insert(
                    pair<string, string>(value2[j]["deviceName"].asString(), value2[j]["number"].asString()));
//            LOG(INFO)<<"-------------------------------- LOCK NUMBER : "<<value2[j]["number"].asString();
            lockTotal+=atoi(value2[j]["number"].asString().c_str());
 //           LOG(INFO)<<"-------------------------------- LOCK NUMBER : "<<lockTotal;

        }

    }
    return 0;
}
