//
// Created by hantao on 18-12-15.
//

#ifndef GJ_TESTPLATFORM_TESTPLATFORM_H
#define GJ_TESTPLATFORM_TESTPLATFORM_H

#include "include/pub.h"

#include "GwTaskProcess.h"
#include "LockTaskProcess.h"
#include "ParseJsonFileSimulator.h"
#include "ParseJsonFileScenario.h"
#include "ParseJsonFileGw.h"
#include "ParseJsonFileLock.h"



class TestPlatForm{
private:

    string  JsonFile;//json脚本描述文件名
    //string dir_home;//$HOME
    string JF_DIR;
    string scenario_file;
    string lock_file;
    string gw_file;

    string l_file;
    ev::default_loop main_loop;

    map<string,int > scenNum; //场景描述
    Gw_Task_Process *Gw[50000];
    //Lock_Task_Process *Lock[500000];





    /*
     * 门锁
     */
    int l_n;
    int  dv_lock_num;//记录本网关下有几类门锁

    int l_Len;
    int dv_l_n[20];//此类门锁的数量
    int l_start_time[20];//门锁的开始时间
    int l_repeat[20];//此门锁重复的次数

    int repeatCount;
    string gw_ID;

    string m_GatewayIDRange;
    string m_LockIDRange;


    queue<DATA> GWDATA;
    map<string,string>gwAndLock;

    queue<DATA> LOCKDATA;

    int nhapPORT;
    string nhapIP;

    vector<string>mygw_id;
    vector<string>mylock_id;

    int fork_base_num;

	int lockTotal;
    int test_module;
    int idCount;

private:
    int InitLog1();
    int GetJsonFileData();

    int CreatGateWay();
    void start();
    void produceGW_ID(int *a,int *b);
    void setGatewayID();
    void produceLOCK_ID(int a[],int b[]);
    void setLockID();


public:
    TestPlatForm();
    ~TestPlatForm();
    void setJsonFileName(string &file);
    void run();
    void dvTask(int &repead,int &gwNum,int &n);
    void getConnMsg();
};



#endif //GJ_TESTPLATFORM_TESTPLATFORM_H
