//
// Created by hantao on 18-12-15.
//

#include "ParseJsonFileScenario.h"
Scenario::Scenario()
{
    _comment="";
    scenarioName="";
    GatewayIDRange="";
    LockIDRange="";
}
Scenario::~Scenario()
{

}
void Scenario::setFilePathGwOrLock(string filepath)
{
    scenarioNameFile=filepath;
}
int Scenario::getScenarioName(string &m_GatewayIDRange, string &m_LockIDRange, map<string, int> &scenNum)
{
    string string1="";
    if(getSimulatorParam(scenarioNameFile,string1) <0){
        LOG(ERROR)<<" 获取文件:["<<scenarioNameFile<<"]失败";
        return -1;
    }

    Json::Reader reader;
    Json::Value value;
    reader.parse(string1,value);
    _comment=value["_comment"].asString();
    scenarioName=value["scenarioName"].asString();

    GatewayIDRange=value["GatewayIDRange"].asString();
    LOG(INFO)<<"GatewayIDRange:"<<GatewayIDRange;

    LockIDRange=value["LockIDRange"].asString();
    LOG(INFO)<<"LockIDRange:"<<LockIDRange;

    m_GatewayIDRange=GatewayIDRange;
    m_LockIDRange=LockIDRange;

    Json::Value value1;
    value1=value["devices"];
    for (int i = 0; i < value1.size(); ++i) {
        string deviceName=value1[i]["deviceName"].asString();
        //LOG(INFO)<<"deviceName:"<<deviceName;
        string number=value1[i]["number"].asString();
        //LOG(INFO)<<"number:"<<number;

        int number1=atoi(number.c_str());
        devTotalNum=+number1;
        // scenNum.insert(pair<string,int >(value1["deviceName"].asString(),value1["number"].asInt()));
        scenNum.insert(pair<string,int >(deviceName,number1));
    }

    return 0;
}
