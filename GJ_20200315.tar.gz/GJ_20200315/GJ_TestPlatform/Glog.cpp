//
// Created by hantao on 18-11-5.
//

#include "include/pub.h"
void SignalHandle(const char *data,int size)
{
    ofstream fs("GJ_TESTPLATFORM_dump.log",ios::app);
    string str=string(data,size);
    fs<<str;
    fs.close();
    LOG(ERROR)<<str;
}
int InitGLog(const  char* program){



    string path =getdir()+"log";
    string mkdir="mkdir -p "+path;

    string MYLOGDIR=path;
    string INFODIR=MYLOGDIR+"/INFO_";
    string WARNINGDIR=MYLOGDIR+"/WARNING_";
    string ERRORDIR=MYLOGDIR+"/ERROR_";
    int ret  = system(mkdir.c_str());
    if (ret <0)
    {
        return -1;
    }
    google::InitGoogleLogging(program);

    google::SetStderrLogging(google::INFO); //设置级别高于 google::INFO 的日志同时输出到屏幕
    FLAGS_colorlogtostderr=true;    //设置输出到屏幕的日志显示相应颜色
    //google::SetLogDestination(google::ERROR,"log/error_");    //设置 google::ERROR 级别的日志存储路径和文件名前缀
    google::SetLogDestination(google::INFO,INFODIR.c_str()); //设置 google::INFO 级别的日志存储路径和文件名前缀
    google::SetLogDestination(google::WARNING,WARNINGDIR.c_str());   //设置 google::WARNING 级别的日志存储路径和文件名前缀
    google::SetLogDestination(google::ERROR,ERRORDIR.c_str());   //设置 google::ERROR 级别的日志存储路径和文件名前缀
    FLAGS_logbufsecs =0;        //缓冲日志输出，默认为30秒，此处改为立即输出
    FLAGS_max_log_size =800;  //最大日志大小为 100MB
    FLAGS_stop_logging_if_full_disk = true;     //当磁盘被写满时，停止日志输出
    google::SetLogFilenameExtension("GJ_");     //设置文件名扩展，如平台？或其它需要区分的信息
    google::InstallFailureSignalHandler();      //捕捉 core dumped
    google::InstallFailureWriter(&SignalHandle);    //默认捕捉 SIGSEGV 信号信息输出会输出到 stderr，可以通过下面的方法自定义输出>方式：

    return 0;
}
