//
// Created by hantao on 18-11-9.
//

#include "config.h"
map<string,queue<string>> gw_queue ;//门锁和网关交互的数据队列

int getGwJson(string filepath,vector<string> &vc1){

    fstream outfile;
    outfile.open(filepath.data());
    assert(outfile.is_open());
    string string1;
    string tmpstr;


    while (getline(outfile,string1)){

        if (string1[0] == '(')
            tmpstr=tmpstr+string1;
        else if(string1[string1.size()] != ')')
            tmpstr=tmpstr+string1;
        vc1.push_back(string1);
    }
    outfile.close();

    return 0;
}

mutex mutex_t1;
int getSimulatorParam(string filepath ,string &sParam){
    //mutex_t1.lock();

    fstream outfile;
    outfile.open(filepath.data());
    //assert(outfile.is_open());
    if (!outfile.is_open())
        return -1;

    string string1;
    while (getline(outfile,string1)){
        sParam=sParam+string1;
    }
    outfile.close();

    //mutex_t1.unlock();

    return 0;
}

/*
 * 获取配置文件
 */
string  getConfig(string confilepath,string param){

    string returnCode;
    fstream outfile;
    outfile.open(confilepath.data());
    //assert(outfile.is_open());
    if (!outfile.is_open()){
        outfile.close();
        return "";
    }
    string strLine;
    while (!outfile.eof())
    {
        getline(outfile, strLine);
        size_t pos = strLine.find('=');
        string key = strLine.substr(0, pos);

        if(key == param)
        {
            returnCode = strLine.substr(pos + 1);
            break;
        }
    }
   outfile.close();

    return returnCode;
}

/*
 * 分割字符串
 */
vector<string> split(const string &str,const string &pattern)
{
    //const char* convert to char*
    char * strc = new char[strlen(str.c_str())+1];
    strcpy(strc, str.c_str());
    vector<string> resultVec;
    char* tmpStr = strtok(strc, pattern.c_str());
    while (tmpStr != NULL)
    {
        resultVec.push_back(string(tmpStr));
        tmpStr = strtok(NULL, pattern.c_str());
    }

    delete[] strc;

    return resultVec;
}
queue<string> split_1(const string &str,const string &pattern)
{
    //const char* convert to char*
    char * strc = new char[strlen(str.c_str())+1];
    strcpy(strc, str.c_str());
    queue<string> resultVec;
    char* tmpStr = strtok(strc, pattern.c_str());
    while (tmpStr != NULL)
    {
        resultVec.push(string(tmpStr));
        tmpStr = strtok(NULL, pattern.c_str());
    }

    delete[] strc;

    return resultVec;
}

/*
 * 分割IP
 */
int  split_ip(const string& strip,int a[])
{
    //int a[4];
    string ip = strip;
    string strtemp;
    size_t pos;
    size_t i=0;

    do
    {
        pos = ip.find(".");   //以点将IP地址分成四段,对每段的数字进行转换
        if(pos != string::npos)  //当搜索整个字符串完后,仍没find到要的字符,则返回npos
        {
            strtemp = ip.substr(0,pos);
            a[i] = atoi(strtemp.c_str());
            //cout<<"a[i]"<<a[i]<<endl;
            i++;
            ip.erase(0,pos+1);
        }
        else
        {
            strtemp = ip;
            a[i] = atoi(strtemp.c_str());
            break;
        }
    }while(1);
    return 0;
}

mutex mutex1;
//static int i=0;//测试
void pushQueueData(string &key,string &data){

    mutex1.lock();
    //LOG(INFO)<<"PUSH DATA KEY :"<<key<<" data :"<<data;
    queue<string> q;

    if (gw_queue.empty()){
        q.push(data);
       // LOG(INFO)<<"--------PUSH INIT DATA--------";

        gw_queue.insert(pair<string, queue<string>>(key, q));
        //test->insert(pair<string,queue<string>>(key,q));

        //it->second.push(data);
       // LOG(INFO)<<"--------PUSH INIT DATA--------";
    }
    else {
        map<string, queue<string>>::iterator it = gw_queue.find(key);
        if (it == gw_queue.end()){
            q.push(data);
           // LOG(INFO)<<"--------queue not empty  key is not find key :"<<key;
            gw_queue.insert(pair<string, queue<string>>(key, q));
        } else{
            it->second.push(data);
        }
        //LOG(INFO)<<"PUSH DATA SIZE :"<<it->second.size();
    }

    mutex1.unlock();
}
void popQueueData(string &key,string &data){


    mutex1.lock();
    LOG(INFO )<< " POPQUEUE DATA KEY:"<<key;
    queue<string> qt;
    if (gw_queue.empty()){
        //cout<< " get msg empty ,continue "<<endl;
        mutex1.unlock();
        return;
    }
    else
    {
        map<string,queue<string>>::iterator it=gw_queue.find(key);
        if (it == gw_queue.end()){
            //   LOG(INFO)<<key<<"  <<没有待处理数据>>";
            mutex1.unlock();
            return;
        }

        qt=it->second;

        int num=qt.size();
        cout<<"size:"<<num<<endl;

        if (!qt.empty()) {
            data=qt.front();
            cout << "data:" << data << endl;
            it->second.pop();
        }

    }

    mutex1.unlock();

}

/*
 * 讲IP"1.168.229.200" 转换为十六进制的buf :01a8e5c8
 */
int converIntAddToHexAdd(string &intIP,char *buffer)
{
    int temp = 0;
    if(intIP.empty())
    {
        cout << "The int IP address is empty." << endl;
        return -1;
    }
    for(string::iterator iter = intIP.begin();iter != intIP.end();iter ++)
    {
        if(*iter == '.')temp++;
    }
    if(temp != 3)
    {
        cout << "wrong format int IP address." << endl;
        return -1;
    }
    string newStr = intIP + '.';
    int beginMark = 0,midInt,offset = 0;
    for(int num =0;num < 4;num ++)
    {
        temp = newStr.find_first_of('.',beginMark);
        string tempStr = newStr.substr(beginMark,temp);
        beginMark = temp +1;
        midInt = atoi(tempStr.c_str());
        if((midInt < 0)||(midInt > 255))return -1;
        if(midInt >= 16)
            sprintf(buffer + offset,"%x",midInt);
        else
            sprintf(buffer + offset,"0%x",midInt);
        offset += 2;
    }
    return 0;
}

uint32_t HostIpToNet(string &ipstr)
{
    uint32_t ipu;
    ipu = inet_addr(ipstr.c_str());//将10进制地址转成网络传输(整数)的格式

    return  htonl(ipu);
}

/*
 * 32位随机数
 */
string Rnd32()
{
    string r = "";
    int i;
    srand(time(NULL));
    for(i=0;i<32;i++)
    {
        r = r + char(rand()%10+'0');
    }
    return r;
}
/*
 * 生成制定位数的随机数
 */
string MyRand(int n)
{
    string r = "";
    int i;
    srand(time(NULL));
    for(i=0;i<n;i++)
    {
        r = r + char(rand()%10+'0');
    }
    return r;
}

string DecIntToHexStr(u32 num)
{
    string str;
    long long Temp = num / 16;
    int left = num % 16;
    if (Temp > 0)
        str += DecIntToHexStr(Temp);
    if (left < 10)
        str += (left + '0');
    else
        str += ('A' + left - 10);
    return str;
}

short int SplitPoint(string &strip,string &point)
{
    //int a[4];
    string ip = strip;
    string strtemp;
    size_t pos;
    size_t i=0;

    string ret;
    short int retNum;
    do
    {
        pos = ip.find(point);   //以点将IP地址分成四段,对每段的数字进行转换
        if(pos != string::npos)  //当搜索整个字符串完后,仍没find到要的字符,则返回npos
        {
            strtemp = ip.substr(0,pos);
            //a[i] = atoi(strtemp.c_str());
            //cout<<"a[i]"<<a[i]<<endl;
            ret+=strtemp;
            i++;
            ip.erase(0,pos+1);
        }
        else
        {
            strtemp = ip;
            //a[i] = atoi(strtemp.c_str());
            ret+=strtemp;
            break;
        }
    }while(1);

    retNum=atoi(ret.c_str());
    return retNum;
}

/*
 * 将字符转换为数值
 * */
int c2i(char ch)
{
    // 如果是数字，则用数字的ASCII码减去48, 如果ch = '2' ,则 '2' - 48 = 2
    if(isdigit(ch))
        return ch - 48;

    // 如果是字母，但不是A~F,a~f则返回
    if( ch < 'A' || (ch > 'F' && ch < 'a') || ch > 'z' )
        return -1;

    // 如果是大写字母，则用数字的ASCII码减去55, 如果ch = 'A' ,则 'A' - 55 = 10
    // 如果是小写字母，则用数字的ASCII码减去87, 如果ch = 'a' ,则 'a' - 87 = 10
    if(isalpha(ch))
        return isupper(ch) ? ch - 55 : ch - 87;

    return -1;
}
/*
 * 功能：将十六进制字符串转换为整型(int)数值
 * */
int hex2dec(char *hex)
{
    int len;
    int num = 0;
    int temp;
    int bits;
    int i;

    // 此例中 hex = "1de" 长度为3, hex是main函数传递的
    len = strlen(hex);

    for (i=0, temp=0; i<len; i++, temp=0)
    {
        // 第一次：i=0, *(hex + i) = *(hex + 0) = '1', 即temp = 1
        // 第二次：i=1, *(hex + i) = *(hex + 1) = 'd', 即temp = 13
        // 第三次：i=2, *(hex + i) = *(hex + 2) = 'd', 即temp = 14
        temp = c2i( *(hex + i) );
        // 总共3位，一个16进制位用 4 bit保存
        // 第一次：'1'为最高位，所以temp左移 (len - i -1) * 4 = 2 * 4 = 8 位
        // 第二次：'d'为次高位，所以temp左移 (len - i -1) * 4 = 1 * 4 = 4 位
        // 第三次：'e'为最低位，所以temp左移 (len - i -1) * 4 = 0 * 4 = 0 位
        bits = (len - i - 1) * 4;
        temp = temp << bits;

        // 此处也可以用 num += temp;进行累加
        num = num | temp;
    }

    // 返回结果
    return num;
}

/*
 * 获取当前时间到S
 */
int GetTime()
{
    struct timeval tv;
    struct timezone tz;
    gettimeofday(&tv,&tz);
    int tt=tv.tv_sec;
    return tt;

}



void signal_exit(int dunno)
{
    string signal_str = "";
    char dunno_str[10] = {0};
    sprintf(dunno_str, "%d", dunno);
    switch (dunno)
    {
        case 1:
            signal_str = "SIGHUP(1)";
            break;
        case 2:
            signal_str = "SIGINT(2:CTRL_C)"; //CTRL_C
            break;
        case 3:
            signal_str = "SIGQUIT(3)";
            break;
        case 4:
        {
            signal_str = "SIGILL(4)";
            out_stack(signal_str.c_str());
        }
            break;
        case 5:
        {
            signal_str = "SIGTRAP(5)";
            out_stack(signal_str.c_str());
        }
            break;
        case 6:
        {
            signal_str = "SIGABRT(6)";
            out_stack(signal_str.c_str());
        }
            break;
        case 7:
        {
            signal_str = "SIGBUS(7)";
            out_stack(signal_str.c_str());
        }
            break;
        case 8:
        {
            signal_str = "SIGFPE(7)";
            out_stack(signal_str.c_str());
        }
            break;
        case 9:
            signal_str = "SIGKILL(9)";
            break;
        case 10:
        {
            signal_str = "SIGUSR1(10)";
            out_stack(signal_str.c_str());
        }
            break;
        case 15:
            signal_str = "SIGTERM(15 KILL)"; //kill
            break;
        case 11:
        {
            signal_str = "SIGSEGV(11)"; //SIGSEGV
            out_stack(signal_str.c_str());
        }
            break;
        case 13:
            {
                signal_str = "SIGPIPE(13)"; //SIGPIPE
                signal(SIGPIPE,SIG_IGN);
                out_stack(signal_str.c_str());
            }
            break;
        default:
            signal_str = "OTHER";
            break;
    }
    signal(SIGPIPE,SIG_IGN);

    exit(0);
}

static void output_addrline(char addr[])
{
    char cmd[256];
    char line[256];
    char addrline[32]={0,};
    char *str1, *str2;
    FILE* file;

    str1 = strchr(addr,'[');
    str2 = strchr(addr, ']');
    if(str1 == NULL || str2 == NULL)
    {
        return;
    }
    memcpy(addrline, str1 + 1, str2 -str1);
    snprintf(cmd, sizeof(cmd), "addr2line -e /proc/%d/exe %s ", getpid(), addrline);
    file = popen(cmd, "r");
    if(NULL != fgets(line, 256, file))
    {
        //printf("%s\n", line);
        LOG(INFO)<<" hantao :"<<line;
    }
    pclose(file);
}

void out_stack(const char *sig)
{
    void *array[256];
    size_t size;
    char **strings;
    int i;

    printf("%s\n", sig);
    size = backtrace (array, 256);
    strings = backtrace_symbols (array, size);
    if (NULL == strings)
    {
        printf("backtrace_symbols\n");
        return ;
    }
    LOG(ERROR)<<"hantao ;"<<array;
    LOG(ERROR)<<"hantao ;"<<strings;
    for (i = 0; i < size; i++)
    {
        printf("%s",strings[i]);
        output_addrline(strings[i]);
    }

    free(strings);
}

double getCurrentTime()
{
    struct timeval tv;
    gettimeofday(&tv,NULL);
    return tv.tv_sec * 1000 + tv.tv_usec / 1000;
}
string num2str(int num)
{
    stringstream ss;
    ss<<num;
    return ss.str();
}



//³õÊ¼»¯ÃÅËøÃÜÔ¿£¬ÃÜÔ¿Í¨¹ýËæ»úÊý²úÉú
void reinit_key_passwd(UINT32 Current_Time, UINT32 lock_id,UINT32 lock_passwd[4])
{
    UINT32  passwd[4];
    UINT8  i;
    UINT32   j=0;
    for(i=0;i<4;i++)
    {
        srand(Current_Time + Current_Time/(i+1+(lock_id%(255*(i+1)))));
        passwd[i] = rand()+rand()/(i+1+(lock_id%(255*(i+1))));                     //ÊÇ·ñÐèÒªsrand()²¥ÖÖ£¬²¢ÏÞÖÆrand()µÄ·¶Î§
        while(lock_passwd[i] == passwd[i])
        {
            srand(Current_Time + Current_Time/(j+1));
            passwd[i] = rand()+rand()/(j+1);
            j++;
            if(j > 0x320000)
                break;
        }
    }
    //½øÐÐ¼ÓÃÜËã·¨£ºlock_id,²¢ÇÒ±£´æµ½EEPROM
    memcpy(lock_passwd,passwd,sizeof(passwd));
}