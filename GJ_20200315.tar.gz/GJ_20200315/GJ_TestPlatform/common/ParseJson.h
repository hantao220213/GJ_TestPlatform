//
// Created by hantao on 18-11-12.
//

#ifndef GJ_TESTPLATFORM_PARSEJSON_H
#define GJ_TESTPLATFORM_PARSEJSON_H

#include "../include/pub.h"
#include "../include/GJjson.h"

int Parse_Simulator(string json_msg,map<string,vector<string>> &sMap);

#endif //GJ_TESTPLATFORM_PARSEJSON_H
