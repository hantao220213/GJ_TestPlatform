//
// Created by hantao on 18-11-12.
//

#include "ParseJson.h"

int Parse_Simulator(string json_msg,map<string,vector<string>> &sMap){

    Json::Reader reader;
    Json::Value value;
    vector<string> vector1;

    reader.parse(json_msg,value);
    string tmp=value["mulatorName"].asString();

    Json::Value value1;
    value1=value["JSONScripts"];

    for (int i = 0; i < value1.size(); ++i) {

        vector1.push_back(value1[i].asString());
    }

    sMap.insert(pair<string,vector<string>>(tmp,vector1));

    return 0;
}