//
// Created by hantao on 18-11-9.
//

#ifndef GJ_TESTPLATFORM_CONFIG_H
#define GJ_TESTPLATFORM_CONFIG_H
#include "../include/pub.h"


int getGwJson(string filepath,vector<string> &vc1);
int getSimulatorParam(string filepath ,string &sParam);

string  getConfig(string confilepath,string param);

vector<string> split(const string &str,const string &pattern);
queue<string> split_1(const string &str,const string &pattern);

int  split_ip(const string& strip,int a[]);

void pushQueueData(string &key,string &data);
void popQueueData(string &key,string &data);

int converIntAddToHexAdd(string &intIP,char *buffer);
uint32_t HostIpToNet(string &ipstr);
string Rnd32();
string MyRand(int n);
string DecIntToHexStr(u32 num);

short int SplitPoint(string &strip,string &point);

int c2i(char ch);
int hex2dec(char *hex);

int GetTime();

void out_stack(const  char *sig);
void signal_exit(int dunno);
double getCurrentTime();
string num2str(int num);
void reinit_key_passwd(UINT32 Current_Time, UINT32 lock_id,UINT32 lock_passwd[4]);

#endif //GJ_TESTPLATFORM_CONFIG_H
