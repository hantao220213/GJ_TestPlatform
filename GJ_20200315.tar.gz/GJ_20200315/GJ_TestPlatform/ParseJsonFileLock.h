//
// Created by hantao on 18-12-15.
//

#ifndef GJ_TESTPLATFORM_PARSEJSONFILELOCK_H
#define GJ_TESTPLATFORM_PARSEJSONFILELOCK_H

#include "include/pub.h"
#include "common/config.h"
#include "include/LockMsgGw.h"

class LockDevice{
private:
    string lock_file;
    string Lock_Name;

    string _comment;
    string deviceName;
    string deviceType;
    string description;

    string divName;
public:
    string actionSeriesName;
    string startTime;
    string repeatMode;
    string params;

    queue<DATA>LOCK_DATA;

public:
    LockDevice();
    ~LockDevice();

    void setLockFilePaht(string file,string divName );

    //int getLockDvAction(string divName, map<string,map<string,string>> &lockdvMap);
    int getLockDvAction();


};


#endif //GJ_TESTPLATFORM_PARSEJSONFILELOCK_H
