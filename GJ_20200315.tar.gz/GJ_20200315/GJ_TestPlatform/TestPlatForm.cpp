//
// Created by hantao on 18-12-15.
//

#include "TestPlatForm.h"



TestPlatForm::TestPlatForm() {
    JsonFile="";
    //dir_home="";
    JF_DIR="";
    scenario_file="";
    lock_file="";
    gw_file="";

    l_n=0;
    dv_lock_num=0;

    l_Len=0;
    memset(dv_l_n,0x00,sizeof(dv_l_n));
    memset(l_start_time,0x00,sizeof(l_start_time));
    memset(l_repeat,0x00,sizeof(l_repeat));

    repeatCount=0;
    gw_ID="";

    m_GatewayIDRange="";
    m_LockIDRange="";

    lockTotal=0;
    idCount=0;
}
TestPlatForm::~TestPlatForm() {
    try {

        for (int i = 0; i <50000 ; ++i) {
            if(!Gw[i])
                delete Gw[i];
        }

    }catch (...){
        LOG(INFO)<<" not't delete memory .....!!!";
    }

}

int TestPlatForm::InitLog1() {


    if(InitGLog("GJ_TestPlatForm")<0){
        return -1;
    }
    return 0;
}
void TestPlatForm::setJsonFileName(string &file) {
    JsonFile=file;
}


int TestPlatForm::GetJsonFileData()
{
    int ret=0;
    string path =getdir() + "etc/testData/";
    string simulator_fille_Dir=path+JsonFile;
    TotalFile totalFile(simulator_fille_Dir);
    scenario_file=totalFile.getScenarioFile();
    gw_file=totalFile.getGWFile();
    lock_file=totalFile.getLockFile();

    JF_DIR=path;
    Scenario gwOrLock;
    string file=JF_DIR+scenario_file;
    gwOrLock.setFilePathGwOrLock(file);

    ret = gwOrLock.getScenarioName(m_GatewayIDRange,m_LockIDRange,scenNum);
    if(ret <0)
    {
        LOG(ERROR)<<"获取设备总体信息失败 ";
        return 0;
    }

    setGatewayID();
    setLockID();
    //LOG(INFO)<<"m_GatewayIDRange:"<<m_GatewayIDRange;
    //LOG(INFO)<<"m_LockIDRange:"<<m_LockIDRange;


    return 0;
}

void TestPlatForm::produceGW_ID(int a[], int b[]) {
    //以下逻辑太绕

    //ofstream in;
    //in.open("gwid.txt",ios::trunc);
    for (int i = a[0]; i <=b[0] ; ++i)
    {
        for (int j = a[1]; j <=b[1] ; ++j)
        {
            for (int k = a[2]; k <=b[2] ; ++k)
            {
                for (int l = a[3]; l <=b[3] ; ++l)
                {
                    char buf[32]={'\0'};
                    sprintf(buf,"%d%s%d%s%d%s%d",i,".",j,".",k,".",l);
                    mygw_id.push_back(buf);
                    //in<<buf<<"\n";

                }
            }
        }
    }

    return;
}

void TestPlatForm::produceLOCK_ID(int *a, int *b)
{
   // ofstream in;
    //in.open("lockid.txt",ios::trunc);
    for (int i = a[0]; i <=b[0] ; ++i)
    {
        for (int j = a[1]; j <=b[1] ; ++j)
        {
            for (int k = a[2]; k <=b[2] ; ++k)
            {
                for (int l = a[3]; l <=b[3] ; ++l)
                {
                    char buf[32]={'\0'};
                    sprintf(buf,"%d%s%d%s%d%s%d",i,".",j,".",k,".",l);
                    mylock_id.push_back(buf);
                   // in<<buf<<"\n";

                }
            }
        }
    }

    return;
}

void TestPlatForm::setGatewayID()
{
    //GatewayIDRange
    vector<string> tmp = split(m_GatewayIDRange, "~");
    string string1 = tmp[0];
    string string2 = tmp[1];

    int _ip1[4], _ip2[4];
    memset(_ip1, 0x00, sizeof(_ip1));
    memset(_ip2, 0x00, sizeof(_ip2));
    split_ip(string1, _ip1);
    split_ip(string2, _ip2);
    produceGW_ID(_ip1,_ip2);
    return;
}
void TestPlatForm::setLockID()
{
    //GatewayIDRange
    vector<string> tmp = split(m_LockIDRange, "~");
    string string1 = tmp[0];
    string string2 = tmp[1];

    int _ip1[4], _ip2[4];
    memset(_ip1, 0x00, sizeof(_ip1));
    memset(_ip2, 0x00, sizeof(_ip2));
    split_ip(string1, _ip1);
    split_ip(string2, _ip2);
    produceLOCK_ID(_ip1,_ip2);

}


void TestPlatForm::dvTask(int &repeatCount,int &gwNum,int &n)
{
    int ret=0;
    repeatCount=0;
    int idNmber=0;
    idNmber=gwNum*n;
    int start1=0;
    int end1=0;
    int idLockCount=gwNum*n;
    for (int i = 0; i < gwNum ; ++i) {
       // for (int k = 0; k <=repeatCount ; ++k)
       // {

            // gw_ID="200.140.2.131";
            vector<string> id;
            if(!gwAndLock.empty())
            {
                id.clear();
                start1=(i*lockTotal)+(idLockCount*lockTotal);
                LOG(INFO)<<" start : "<<start1;
                end1=((i+1)*lockTotal)+(idLockCount*lockTotal);
                LOG(INFO)<<"end : "<<end1;
                id.insert(id.begin(),mylock_id.begin()+start1,mylock_id.begin()+end1);
            }

            string gw_ID=mygw_id[idNmber];
        LOG(INFO)<<"ID START ："<<start1<<" end : "<<end1 <<" gwid: "<<gw_ID;

        //test-20190314
       // gw_ID="200.140.2.44";

            Gw[idNmber]= new Gw_Task_Process();
            Gw[idNmber]->setGwId(gw_ID,nhapPORT,nhapIP,test_module);
            ret = Gw[idNmber]->setGwTaskData(GWDATA);
            Gw[idNmber]->setLockDvData(gwAndLock,l_file,id);
            Gw[idNmber]->Gw_Task_Process_start();
            idNmber++;
       // }
    }
}

void mysignal(int signal)
{
    int status;
    int ret;
    while(ret = waitpid(-1, &status, WNOHANG)>0) {
        if (ret < 0) {
            LOG(ERROR) << " 等待子进程结束错误";
        }
        if (WIFEXITED(status))
            LOG(ERROR) << " 没有任何子程需要等待,exit status : " << WEXITSTATUS(status);
        else if (WIFSIGNALED(status))
            LOG(ERROR) << " hantao 进程推出的信息 signal number : " << WTERMSIG(status) <<"PID :"<<getpid();
        else if (WIFSTOPPED(status))
            LOG(ERROR) << " 子进程停止的信号,child stop signal number :" << WSTOPSIG(status) <<"mysignal "<<signal;
    }
}

int TestPlatForm::CreatGateWay()
{

    getConnMsg();

    l_n=0;

    string file;


    map<string,int >::iterator iterator1=scenNum.begin();
    //LOG(INFO)<<"ONE param:"<<iterator1->first;
    //LOG(INFO)<<"two param:"<<iterator1->second;

    /*
     * 网关设置
     */
    GwDevice diveseAction;

    LOG(INFO)<<" -----------------JF_DIR : "<<JF_DIR;
    file=JF_DIR+gw_file;
    LOG(INFO)<<" -----------------JF_DIR file: "<<file;

    diveseAction.setDivMsg(file,iterator1->first);


    /*
     * 门锁设置
     */

    l_file = JF_DIR;
    l_file += lock_file;

    LOG(INFO)<<" -----------------JF_DIR file: "<<l_file;

    signal(SIGCHLD,mysignal);

    if (scenNum.empty()){
        LOG(ERROR)<<"网关，门锁描述数据不存在";
        return 0;
    }
   // for (iterator1=scenNum.begin();iterator1!=scenNum.end();++iterator1)
    {


        lockTotal=0;
        diveseAction.getDiveceACTION();
        GWDATA =diveseAction.GW_DATA;
        gwAndLock=diveseAction.gwAndLock;
        lockTotal=diveseAction.lockTotal;

        if(GWDATA.empty())
        {
            LOG(ERROR) <<" 设备数据不存在";
            return 0;
        }


        /*

        map<string,string>::iterator lockDiv=gwAndLock.begin();
        LOG(INFO) <<" 设备下的门锁类别种类: "<<gwAndLock.size();


        l_Len=gwAndLock.size();
        dv_lock_num=0;
        for (;lockDiv!=gwAndLock.end();lockDiv++)
        {


            LockDevice lockDives;

            string lockDivName=lockDiv->first;
            dv_l_n[dv_lock_num]=atoi(lockDiv->second.c_str());

            lockDives.setLockFilePaht(l_file,lockDivName);

            lockDives.getLockDvAction();
            LOCKDATA=lockDives.LOCK_DATA;

            if(LOCKDATA.empty())
            {
                LOG(ERROR)<<"门锁设备 ["<<lockDivName<<" ] 数据不存在";
                continue;
            }

            string s1 = lockDives.startTime;
            l_start_time[dv_lock_num] = atoi(s1.c_str());
            string s2 = lockDives.repeatMode;
            l_repeat[dv_lock_num] = atoi(s2.c_str());
            dv_lock_num++;
        }


        int start_time = atoi(diveseAction.startTime.c_str());
        int repeatCount = atoi(diveseAction.repeatMode.c_str());

        LOG(INFO) << "repeatCount : " << repeatCount;
        */

        /*
         * 网关
         */
        int gwNumber = iterator1->second;
        LOG(INFO) << "网关数量 ：" << gwNumber;

        //gwNumber = 30000;
       // int x = 3000;


        //int n = gwNumber / x;
        int size_gw = mygw_id.size();
        int count = 0;
        int j = 0;
        pid_t pid;
        for (j = 0; j < gwNumber / fork_base_num  ; ++j)
        {
            if (mygw_id.empty() || gwNumber >= size_gw) {
                LOG(INFO) << " 网关编号超出，或者不存在 网关数量:" << size_gw;
                continue;
            }
            pid = fork();
            if (pid == 0 || pid == -1)
                break;
        }
        if (pid == 0) {

            signal(SIGHUP, &signal_exit);
            signal(SIGINT, &signal_exit);
            signal(SIGQUIT, &signal_exit);
            signal(SIGABRT, &signal_exit);
            signal(SIGKILL, &signal_exit);
            signal(SIGTERM, &signal_exit);
            signal(SIGSEGV, &signal_exit);

            signal(SIGPIPE, &signal_exit);

            //signal(SIGPIPE,SIG_IGN);

            ev::default_loop child_loop; //=new ev::default_loop;
            LOG(INFO) << "创建资金臣成功";
            ev_loop_fork(main_loop);
            dvTask(repeatCount, fork_base_num, j);
            child_loop.run(EVBACKEND_EPOLL);


        } else if (pid < 0) {
            LOG(ERROR) << "创建进程失败";
        } else {
            LOG(INFO) << " 等待资金臣结束";


            /*
            while (1)
            {
                sleep(2);
            }
            */

            /*
            int status;
            int ret;
            while(ret = waitpid(-1, &status, WNOHANG)>0) {
                if (ret < 0) {
                    LOG(ERROR) << " 等待子进程结束错误";
                }
                if (WIFEXITED(status))
                    LOG(ERROR) << " 没有任何子程需要等待,exit status : " << WEXITSTATUS(status);
                else if (WIFSIGNALED(status))
                    LOG(ERROR) << " 进程推出的信息 signal number : " << WTERMSIG(status);
                else if (WIFSTOPPED(status))
                    LOG(ERROR) << " 子进程停止的信号,child stop signal number :" << WSTOPSIG(status);

            }
             */
        }
    }
    return 0;

}



void TestPlatForm::start() {

    main_loop.run(EVBACKEND_EPOLL);
}
void TestPlatForm::run() {
    GetJsonFileData();
    CreatGateWay();
    start();

}

void TestPlatForm::getConnMsg()
{

    string confdir = getdir()+"etc/config/GJ_config.ini";

    string tmpPort=getConfig(/*conPATH*/ confdir,string("N_HAP_PORT"));
    nhapPORT=atoi(tmpPort.c_str());
    nhapIP=getConfig(/*conPATH*/ confdir,string("N_HAP_IP"));

    //单个进程中的网关个数
    string tmpBaseNum=getConfig(confdir,string("FORK_BASE_NUM"));
    fork_base_num=atoi(tmpBaseNum.c_str());

    string tmpModule=getConfig(confdir,string("TEST_MODULE"));
    test_module=atoi(tmpModule.c_str());
}


