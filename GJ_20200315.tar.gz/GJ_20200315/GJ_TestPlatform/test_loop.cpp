//
// Created by hantao on 18-12-28.
//

#include "test_loop.h"




test_loop::test_loop() {
    //defaultLoop= new ev::default_loop;
    //defaultLoop=ll;
    count=0;
    connfd=0;
}

test_loop::~test_loop() {
    //testTimer.stop();
   // defaultLoop.break_loop();

}

void test_loop::callback_conn(ev::timer &conn_io1, int revents)
{
    time_t now;
    now = time(NULL);
    printf(" start ----begin time time is %s\n", ctime(&now));

    connfd=socket(AF_INET,SOCK_STREAM,0);
    if (connfd <= 0)
    {
        conn_t.stop();
        close(connfd);
        cout<<__FILE__<<__LINE__ <<" 创建套接字失败 ,errrno : "<<errno<<" errmsg : "<<strerror(errno)<<endl;
        return;
    }

    cout<<__FILE__<<__LINE__ <<" 创建套接字成功......"<<" connfd : " << connfd<<endl;

    memset(&sockaddr,0x00,sizeof(sockaddr));
    sockaddr.sin_family=AF_INET;
    sockaddr.sin_port=htons(40100);
    sockaddr.sin_addr.s_addr=inet_addr("118.190.88.78");
    if (connect(connfd,(struct  sockaddr *)&sockaddr,sizeof(sockaddr)) ==-1)
    {
        conn_t.stop();
        close(connfd);
        cout<<__FILE__<<__LINE__ << " 链接服务器失败 ,errno : "<<errno << "errmsg : "<<strerror(errno);
        return;
    }
    cout<<__FILE__<<__LINE__ <<" 链接成功......"<<endl;

    time_t now1;
    now = time(NULL);
    printf("end ------begin time time is %s\n", ctime(&now1));

    /*
    write_io.set<test_loop,&test_loop::callback_write>(this);
    write_io.start(connfd,EV_WRITE);
    */
}

void test_loop::conn_svr()
{
    time_t now;
    now = time(NULL);
    printf(" start ----begin time time is %s\n", ctime(&now));

    connfd=socket(AF_INET,SOCK_STREAM,0);
    if (connfd <= 0)
    {
        conn_t.stop();
        close(connfd);
        cout<<__FILE__<<__LINE__ <<" 创建套接字失败 ,errrno : "<<errno<<" errmsg : "<<strerror(errno)<<endl;
        return;
    }

    cout<<__FILE__<<__LINE__ <<" 创建套接字成功......"<<" connfd : " << connfd<<endl;

    memset(&sockaddr,0x00,sizeof(sockaddr));
    sockaddr.sin_family=AF_INET;
    sockaddr.sin_port=htons(40100);
    sockaddr.sin_addr.s_addr=inet_addr("118.190.88.78");
    if (connect(connfd,(struct  sockaddr *)&sockaddr,sizeof(sockaddr)) ==-1)
    {
        conn_t.stop();
        close(connfd);
        cout<<__FILE__<<__LINE__ << " 链接服务器失败 ,errno : "<<errno << "errmsg : "<<strerror(errno);
        return;
    }
    cout<<__FILE__<<__LINE__ <<" 链接成功......"<<endl;

    time_t now1;
    now = time(NULL);
    printf("end ------begin time time is %s\n", ctime(&now1));
    while(1)
    {
        cout << " pthread_self : "<<pthread_self()<<" connfd :" <<connfd <<endl;
    }
}

void test_loop::callback_write(ev::io &writ_io1, int revents)
{
    int ret = send(connfd,snd_buff,strlen(snd_buff),0);
    if (ret < 0){
        cout<<__FILE__<<__LINE__ << " 发送数据失败";
        close(connfd);
        conn_t.stop();
        write_io.stop();
        return;
    }

    write_io.stop();
    read_io.set<test_loop,&test_loop::callback_read>(this);
    read_io.start(connfd,EV_READ);
}

void test_loop::callback_read(ev::io &read_io, int revents)
{

    go_recv:
    int ret = recv(connfd,rcv_buff,1024,0);
    if(ret ==0){
        write_io.stop();
        read_io.stop();
        conn_t.stop();
        close(connfd);
        cout<<__FILE__<<__LINE__ <<" 接受数据失败"<< " errno : " << errno << " ermsg : "<<strerror(errno);
        return;
    } else if(ret >0)
    {
        cout<<__FILE__<<__LINE__ <<" 接受数据成功";
    }
    else{
        if(errno == EINTR||errno == EWOULDBLOCK||errno == EAGAIN)
            goto go_recv;
        else
        {
            write_io.stop();
            read_io.stop();
            conn_t.stop();
            close(connfd);
            cout<<__FILE__<<__LINE__ <<" 接受数据失败"<< " errno : " << errno << " ermsg : "<<strerror(errno);
            return;
        }
    }


    read_io.stop();
    write_io.set<test_loop,&test_loop::callback_write>(this);
    write_io.start(connfd,EV_WRITE);

}


void test_loop::callback_loop(ev::timer &w, int revents) {
    pthread_t pid = pthread_self();

    cout<<__FILE__<<__LINE__ <<  "my name is :"<<get_id()<<endl;
}
mutex mutex123;

void test_loop::start() {

    /*
    defaultLoop= new ev::default_loop;
    defaultLoop=&main_loop;
    */
    cout << " start......"<<endl;
   // testTimer.set<test_loop, &test_loop::callback_loop>(this);
    //testTimer.start(0, 0);
    //conn_t.set<test_loop,&test_loop::callback_conn>(this);
    //conn_t.start(0,0);
    conn_svr();
    cout << " start -- end ---......"<<endl;
    //defaultLoop->run(EVBACKEND_EPOLL);

}

/*
test_loop& test_loop::operator=(ev::default_loop *ll) {
    defaultLoop=ll;
    return *this;
}
 */

void test_loop::create_thread() {


    thread thread1(&test_loop::start,this);
    thread1.detach();
}

