//
// Created by hantao on 18-12-13.
//

#include "GwTaskProcess.h"
#include "include/pub.h"
#include "include/GwMsgNhap.h"


Gw_Task_Process::Gw_Task_Process() {
    listenfd=-1;
    cmdlength=0;
    _gw_id="";
    GW_LOG="";
    node_id=0;
    hurt_send_off=0;
    gw_scond_conn=0;
    timeout_nun=0;
    read_flag=0;

    auth_data=0;
    check_auth_data=0;
    check_node_random_data=0;
    memset(&gw_private_key,0x00,sizeof(gw_private_key));
    memset(&gw_public_key,0x00,sizeof(gw_public_key));
    memset(&old_gw_private_key,0x00,sizeof(old_gw_private_key));
    memset(&old_gw_public_key,0x00,sizeof(old_gw_public_key));
    memset(&old_key,0x00,sizeof(old_key));
    memset(&cmdsend,0x00,sizeof(cmdsend));
    memset(&key,0x00,sizeof(key));
    memset(&gw_keyword,0x00,sizeof(gw_keyword));
    memset(&svr_public_key,0x00,sizeof(svr_public_key));
    memset(&DownQuestCmdData,0x00,sizeof(DownQuestCmdData));
    memset(&ucData,0x00,sizeof(ucData));
    ucDataLen=0;
    memset(&cmd4002,0x00,sizeof(cmd4002));


    memset(&serv_addr,0x00,sizeof(serv_addr));

    ServerListIp="";
    ServerListPort=0;
    ServerListEdition="";

    startTime=0;
    endTime=0;
    sListModule=0;
    sListRunCount=0;

    rcvServerlistIp="";
    rcvServerlistPort=0;
    rcvIdsIp="";
    rcvIdsPort=0;
    rcvNhapIp="";
    rcvNhapPort=0;


    gwData= new queue<DATA>;

    idCount=0;

    gwRequestNhapFlag=0;
    lockOnLineFlag=0;


    SVR_DEL_LOCK_PWD_INFO cmd3007;
    memset(&cmd3007,00,sizeof(SVR_DEL_LOCK_PWD_INFO));
    delPwdSerino=0;
    pwd_en=0;
    pwd_op_flag=0;

    pwd_type=0;
    pwd_num=0;
    gw_first_flag=0;
    keyCount=0;
    sqlite3 *db;
    azReuslt=NULL;
    nrow=0;
    ncolumn=0;

}

Gw_Task_Process::~Gw_Task_Process() {

    sqlite3_close(db);
    delete(gwData);
    //SocketClose();
    //write_io.stop();
    //read_io.stop();
}

int Gw_Task_Process::CreateSocket() {
    listenfd = socket(AF_INET, SOCK_STREAM, 0);
    if (listenfd < 0) {
        LOG(ERROR) << GW_LOG <<" 创建套接字失败 errno :" << errno;
        return -1;
    }

    return 0;
}

int Gw_Task_Process::Conn() {

    memset(&serv_addr,0x00,sizeof(serv_addr));
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(n_hap_Port);
    serv_addr.sin_addr.s_addr =inet_addr(n_hap_Ip.c_str());

    int ret=-1;
    if (ret =connect(listenfd,(struct sockaddr *)&serv_addr,sizeof(serv_addr)) ==-1){
            if (ret < 0) {
                close(listenfd);
                listenfd=-1;
                LOG(ERROR) << "链接服务器失败[" << n_hap_Ip << "] port:" << n_hap_Port;
                LOG(ERROR) << "连接服务器失败信息 errno[" << errno << "]:" << strerror(errno);
                return -1;
            }


    }

    /*
     * 只要每一次接入服务器，都的重新来,非首次接入link_first=1;
     */
    gw_off_sucess=0;

    LOG(WARNING)<<GW_LOG<<" connnect sucess fd :"<< listenfd;

    return 0;
}




void Gw_Task_Process::setGwCmd(string &cmd) {
    _gw_cmd=cmd;
}
void Gw_Task_Process::setGwId(string &gwid,int &nhapPORT,string &nhapIP,int &sListModule)
{

    _gw_id=gwid;

    GW_LOG="["+_gw_id+"]";
    node_id=HostIpToNet(_gw_id);

    n_hap_Ip=nhapIP;
    n_hap_Port=nhapPORT;

    this->sListModule=sListModule;




}
void Gw_Task_Process::setNodeId() {
    node_id=HostIpToNet(_gw_id);
}


void Gw_Task_Process::setLinkFirst() {
    /*
     * 获取加密密钥
     * if加密数据存在-link_first=1
     * if加密数据不存在-link_list=0
     */

    link_first=0;

}
/*
 *将
 */
int  Gw_Task_Process::getSendData(string &src) {

    if (src.empty()){
        LOG(ERROR)<< GW_LOG <<"指令数据为空，无法指令解析";
        return -1;
    }

    pair<map<string,string>::iterator, bool >ret;
    Json::Reader reader;
    Json::Value value;
    reader.parse(src,value);

    int cn=0;
    int j=0;
    for (int i = 0; i < 100; ++i) {
        char buf[16]={'\0'};
        if (i< 10)
            sprintf(buf,"%s%02d","0x10",i);
        else if(i>=10 && i<37)
        {
            char t=char(55+i);
            sprintf(buf,"%s%c","0x100",t);
        }
        else if(i>=37)
        {
            sprintf(buf,"%s%d","0x101",j++);
        } else{
            break;
        }


        if (value[cn][buf].isNull())
            continue;
        string cmdData= value[cn][buf].toStyledString();
        if (cmdData.empty())
        {
            LOG(ERROR)<<GW_LOG<<"指令数据为空";
            return -2;
        }
        ret = _gw_data.insert(pair<string,string>(buf,cmdData));
        if (ret.second == false){
            LOG(INFO)<<GW_LOG<<"------插入指令操作数据失败---------";
            return -3;
        }

    }

    _gw_data_repeat=_gw_data;
    return 0;
}

void Gw_Task_Process::SvrHurt() {

    //node_id=HostIpToNet(_gw_id);
    //setNodeId();//讲127.0.0.1 转换为网络字节序

    u16 slength=0;

    //if(cmdsend == 0)
     //   return ;


    _gw_cmd="0x1000";
    NODE_HELLO_INFO helloInfo;
    memset(&helloInfo,0x00,sizeof(helloInfo));
    int length=4;
    short int cmd=0x1000;

    int serialnum=1234;
    helloInfo.hello=0;


    cmdsend[0] = length & 0xFF;
    cmdsend[1] = length >> 8;

    cmdsend[2] = cmd & 0xFF;
    cmdsend[3] = cmd >> 8;

    cmdsend[4] = serialnum & 0xFF;
    cmdsend[5] = (serialnum >> 8) & 0xFF;
    cmdsend[6] = (serialnum >> 16) & 0xFF;
    cmdsend[7] = (serialnum >> 24) & 0xFF;

    uint8_t data[4];
    memset(data,0x00,sizeof(data));
    data[0]=helloInfo.hello&0xFF;
    data[1]=(helloInfo.hello>>8)&0xFF;
    data[2]=(helloInfo.hello>>16)&0xFF;
    data[3]=(helloInfo.hello>>24)&0xFF;

    memcpy(cmdsend+8,data,length);

    slength = length+8;
    //LOG(INFO)<<GW_LOG<<" 加密数据的长度 :"<<sendlength;
    //u8 NetEncodePacket(u32 node_id, u32 *keyword, u8 *ucData, u16 *ucData_len, u8 ucEncrypt_type);
    uint32_t keyword=0;
    u8 ucEncrypt_type=0;
    u8  ret = NetEncodePacket(node_id,&keyword,cmdsend,&slength,ucEncrypt_type);
    if (ret == HUOHE_FAIL)
    {
        LOG(INFO)<<GW_LOG<<"心跳 打包数据失败..............................!!!!!!!";
       // return;
    }
    else
    {
        LOG(INFO)<<GW_LOG<<"心跳打包数据成功................................~~~~~";
        cmdlength=slength;
    }

   // LOG(INFO)<<GW_LOG<<"打印发送数据完成...........";

    return;

}

int Gw_Task_Process::enCodeSendData(unsigned char *cmdData, unsigned short int &cmdLen, unsigned short int &s_cmd ,char &ucEncrypt_type)
{
    //LOG(INFO)<<GW_LOG<<" 开始加密发送数据";
    u16 length=cmdLen;

    int serialnum=stoi(MyRand(4).c_str());

    if (s_cmd == 0x2007)
    {
        del_serial_no=serialnum;
    }
    unsigned  short int cmd1=s_cmd;
    memset(cmdsend,0,1024);
    cmdsend[0] = length & 0xFF;
    cmdsend[1] = length >> 8;

    cmdsend[2] = cmd1 & 0xFF;
    cmdsend[3] = cmd1 >> 8;

    cmdsend[4] = serialnum & 0xFF;
    cmdsend[5] = (serialnum >> 8) & 0xFF;
    cmdsend[6] = (serialnum >> 16) & 0xFF;
    cmdsend[7] = (serialnum >> 24) & 0xFF;

    if(s_cmd == 0x101b||s_cmd==0x1017)
    {
        NODE_QUERY_SERVER_LIST_INFO *cc=(NODE_QUERY_SERVER_LIST_INFO *)cmdData;
        memcpy(cmdsend+8,&(cc->list_num),length);
    } else{
        //memcpy(cmdsend+8,(char *)&cmdData,length);
    }





//    LOG(INFO)<<" encode list_num : "<<strtol((char *)cmdData,NULL,16);
    length=length+8;
    cmdlength=length;
/*
    LOG(INFO)<<GW_LOG<<"LENGTH: "<<cmdlength;
    char print[2]={'\0'};
    string s_print="";
    for (int i = 0; i < cmdlength; ++i) {
        sprintf(print,"%02x",cmdsend[i]);
        s_print=s_print+print;
    }
    LOG(INFO)<<GW_LOG<< " cmdlength :"<<cmdlength <<"  data : "<<s_print;

    LOG(INFO)<<GW_LOG<<"LENGTH: "<<cmdlength;
    char print2[2]={'\0'};
    string s_print2="";
    for (int i = 0; i < 16; ++i) {
        sprintf(print2,"%02x",key[i]);
        s_print2=s_print2+print2;
    }
    LOG(INFO)<<GW_LOG <<"  key : "<<s_print2;
    */
    char ret= NetEncodePacket(node_id,(u32 *) key,cmdsend,&cmdlength,ucEncrypt_type);
    if (ret == HUOHE_FAIL) {
        LOG(INFO) << GW_LOG << "[" << _gw_cmd << "] 指令 加密失败";
        return -1;
    } else {

        //LOG(INFO) << GW_LOG << "[" << _gw_cmd << "] 指令 加密成功，加密后的数据长度 : " << cmdlength;
        //return 0;
    }

    /*
    char print1[2]={'\0'};
    string s_print1="";
    for (int i = 0; i < cmdlength; ++i) {
        sprintf(print1,"%02x",cmdsend[i]);
        s_print1=s_print1+print1;
    }
    LOG(INFO)<<GW_LOG <<" cmdlength :"<<cmdlength <<"  data : "<<s_print1;
    */
    return 0;

}

int Gw_Task_Process::getGwTaskData() {

    cmdlength=0;
    //获取指令的数据
    if (_gw_data.empty())
    {

        _gw_cmd="0x1000";
        SvrHurt();

        LOG(INFO)<< GW_LOG <<" 无指令数据可以获取 ";
        return 0;
    }
    map<string,string>::iterator it=_gw_data.begin();

    string cmd=it->first;
    string cmdData=it->second;

    _gw_cmd=cmd;


    Json::Reader reader;
    Json::Value value;
    reader.parse(cmdData,value);

    int cn=0;
    if(cmd == "0x1000")
    {
        _gw_cmd="0x1000";
        SvrHurt();
    }
    else if(cmd == "0x1001")
    {


        _gw_cmd="0x1001";


        string join_flag;
        string node_public;
        string node_public_len;
        string node_random_data;
        join_flag=value["join_flag"].asString();
        //LOG(INFO)<<GW_LOG<<"join_flag "<<join_flag;
        node_random_data=value["node_random_data"].asString();
        //LOG(INFO)<<GW_LOG<<" node_random_data :"<<value["node_random_data"].asString();
        if (node_random_data.size() <=0){

            node_random_data=MyRand(4);
            //生产32位随机数
            //LOG(INFO)<< GW_LOG << " 产32位随机数 "<<node_random_data;

        }
        node_public=value["node_public"].asString();


        NODE_NODE_JOININ_INFO cmd1001;
        memset(&cmd1001,0x00,sizeof(NODE_NODE_JOININ_INFO));

        short int  datalen=0;
        try {
            DH_generate_key_pair((u8 *)gw_public_key, gw_private_key);
        }catch (...){
            throw " DH_generate_key_pair   fail";
        }
#if 1
        char *select = "select count(*) as count from gw_id_key where gw_id='%s';";
        char tmpsql[1024]={'\0'};
        sprintf(tmpsql,select,_gw_id.c_str());

        /*
       string path = getdir()+"DB/gwDatabase.db";


        int rc = sqlite3_open(path.c_str(),&db);
        if(rc < 0)
        {
            LOG(ERROR)<<" 创建gwDatabase.db数据库失败!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!1";
            return -1;
        }
        else
        {
            LOG(INFO)<<"打开gwDatabase.db数据库成功";
        }
        */
        int rc= sqlite3_get_table(db,tmpsql,&azReuslt,&nrow,&ncolumn,&zErrMsg);
        if(rc != SQLITE_OK)
        {
            LOG(INFO)<< GW_LOG <<"error : select gw_id key failed  id: "<<_gw_id<<" failed msg: "<<zErrMsg;
            sqlite3_free(zErrMsg);

        } else{
            keyCount=atoi(azReuslt[1]);
            sqlite3_free_table(azReuslt);
        }
        //sqlite3_close(db);
        LOG(INFO)<< GW_LOG <<" =====================select gw key sucess====================";

#endif
        //keyCount=0;
        /*
        char path[256]={'\0'};
        char *h=getenv("HOME");
        sprintf(path,"%s%s",h,PWD_DIR);
        struct stat buf;
        int ret1 =   stat(path,&buf);
        if(ret1 != 0)
          */
        if (keyCount ==0)
        {
            cmd1001.join_flag=0;

        } else{
            cmd1001.join_flag=1;

        }
        cmd1001.node_random_data=atoi(MyRand(4).data());

        cmd1001.node_public_len=DH_KEY_LENGTH;
        if (cmd1001.join_flag ==0||cmd1001.join_flag == 0xff){
            /*
             * 本机为大端序，若进行服务器时需要判断服务器是否为大端序
            for (int i = 0; i < DH_KEY_LENGTH / 4; ++i) {
                cmd1001.node_public[i * 4] = gw_public_key[i];
                cmd1001.node_public[i * 4 + 1] = gw_public_key[i] >> 8;
                cmd1001.node_public[i * 4 + 2] = gw_public_key[i] >> 16;
                cmd1001.node_public[i * 4 + 3] = gw_public_key[i] >> 24;
            }
             */
        } else{
            for (int i = 0; i <DH_KEY_LENGTH ; ++i) {
                cmd1001.node_public[i]=0;
            }
        }

        memcpy(cmd1001.node_public,(u8*)gw_public_key,16);
        uint16_t length;
        length=16+2+4+4; //NODE_NODE_JOININ_INFO结构体的长度

#if 1
        int serialnum=stoi(MyRand(4).data());

        short int cmd1=0x1001;
        memset(cmdsend,0,1024);
        cmdsend[0] = length & 0xFF;
        cmdsend[1] = length >> 8;

        cmdsend[2] = cmd1 & 0xFF;
        cmdsend[3] = cmd1 >> 8;

        cmdsend[4] = serialnum & 0xFF;
        cmdsend[5] = (serialnum >> 8) & 0xFF;
        cmdsend[6] = (serialnum >> 16) & 0xFF;
        cmdsend[7] = (serialnum >> 24) & 0xFF;

        memcpy(cmdsend+8,(u8*)&cmd1001,length);
        length=length+8;
        //LOG(INFO)<<GW_LOG<<"["<<_gw_cmd<<"] 加密前的数据长度 ："<<length;
        cmdlength=length;
        //u8 NetEncodePacket(u32 node_id, u32 *keyword, u8 *ucData, u16 *ucData_len, u8 ucEncrypt_type);

        u8  ret;
        u32 keyword=0;
        u8 ucEncrypt_type=0;
        ret = NetEncodePacket(node_id,&keyword,cmdsend,&cmdlength,ucEncrypt_type);
        if(ret == HUOHE_FAIL){
            gw_off_sucess=2;
            LOG(ERROR)<<GW_LOG<<"["<<_gw_cmd<<"] 指令 加密失败";
            return -1;
        } else
        {
            //LOG(INFO)<<GW_LOG<<"["<<_gw_cmd<<"] 加密后的数据长度 : "<<cmdlength;

        }
#endif
/*
        u8 tmp1001[1024]={0};
        memcpy(tmp1001,(u8*)&cmd1001,length);
        u16 c1001=0x1001;
        int ret =SndCmdData(tmp1001,length,c1001);
        if (ret < 0)
        {
            if (ret <0){
                gw_off_sucess=2;
                next_cmd="0x1001";
                setGwCmd(next_cmd);
                LOG(ERROR)<<_gw_id<<"["<<_gw_cmd<<"]拼装发送数据失败，sleep(120)后发起申请接入";
                return -1;
            }
            LOG(INFO)<<_gw_id<<"["<<_gw_cmd<<"]拼装发送数据成功";
        }
    */


    }
    else if (cmd == "0x1002")
    {
        _gw_cmd="0x1002";
        LOG(INFO)<< _gw_id<<" |0x1002 拼装数据开始 ....  ";
        string hard_ver="";
        string soft_ver="";
        string node_type="";
        string node_factory="";
        string check_auth_data1="";

        /*
        hard_ver=value["hard_ver"].asString();
        soft_ver=value["soft_ver"].asString();
        node_type=value["node_type"].asString();
        node_factory=value["node_factory"].asString();
        check_auth_data1=value["check_auth_data"].asString();
        if (check_auth_data1.size()<=0){

            //通过0x1001应答的auth_data ,生产此值

        }
         */
        //LOG(INFO)<<GW_LOG<<"["<<_gw_cmd<<"] 开始设置数据......";

        NODE_NODE_VALID cmd1002;
        memset(&cmd1002,0x00,sizeof(cmd1002));
        //string point=".";
        //cmd1002.hard_ver=SplitPoint(hard_ver,point);
        //cmd1002.soft_ver=SplitPoint(soft_ver,point);
        cmd1002.hard_ver=0x1234;
        cmd1002.soft_ver=0x3210;
        cmd1002.node_type=0x31;
        cmd1002.node_factory=0x33;

        cmd1002.check_auth_data=check_auth_data;
        u16 length;
        length=2+2+2+2+4; //NODE_NODE_VALID结构体的长度

#if 1

        int serialnum=stoi(MyRand(4).data());

        short int cmd1=0x1002;
        memset(cmdsend,0,1024);
        cmdsend[0] = length & 0xFF;
        cmdsend[1] = length >> 8;

        cmdsend[2] = cmd1 & 0xFF;
        cmdsend[3] = cmd1 >> 8;

        cmdsend[4] = serialnum & 0xFF;
        cmdsend[5] = (serialnum >> 8) & 0xFF;
        cmdsend[6] = (serialnum >> 16) & 0xFF;
        cmdsend[7] = (serialnum >> 24) & 0xFF;

        memcpy(cmdsend+8,(u8*)&cmd1002,length);
        length=length+8;
        cmdlength=length;
        u8  ret;
        u8 ucEncrypt_type=1;

        //LOG(INFO)<<GW_LOG<<"["<<_gw_cmd<<"] 加密数据开始..... cmdlength: "<<cmdlength<<"length :"<<length;
        ret = NetEncodePacket(node_id,(u32*)key,cmdsend,&length,ucEncrypt_type);
        if(ret == HUOHE_FAIL){
            gw_off_sucess=2;
            LOG(INFO)<< _gw_cmd<<"  指令 加密失败";
            return -1;
        } else
        {

            cmdlength=length;
            LOG(INFO)<<GW_LOG<<"["<<_gw_cmd<<"] 加密后的数据长度 : "<<cmdlength;

        }
        //LOG(INFO)<<GW_LOG<<"["<<_gw_cmd<<"] 设置发送数据完成....";
#endif
        /*
        u8 tmp1002[1024]={0};
        memcpy(tmp1002,(u8*)&cmd1002,length);
        u16 c1002=0x1002;
        int ret =SndCmdData(tmp1002,length,c1002);
        if (ret <0){
            gw_off_sucess=2;
             next_cmd="0x1001";
            setGwCmd(next_cmd);
            LOG(ERROR)<<_gw_id<<"["<<_gw_cmd<<"]拼装发送数据失败，sleep(120)后发起申请接入";
            return -1;
        }
        LOG(INFO)<<_gw_id<<"["<<_gw_cmd<<"]拼装发送数据成功";
         */


    }
    else if(cmd == "0x1004"){


    }
    else if (cmd == "0x1005")
    {
        _gw_cmd="0x1005";
        NODE_NTP_CALI_TIME_INFO cmd1005;
        memset(&cmd1005,0x00,sizeof(NODE_NTP_CALI_TIME_INFO));
        cmd1005.ms_time=0;
        cmd1005.time=0;
        u8 tmp1005[1024];
        memset(&tmp1005,0x00,sizeof(tmp1005));
        u16 len1005=sizeof(NODE_NTP_CALI_TIME_INFO);
        memcpy(tmp1005,(u8*)&cmd1005,len1005);

        int serialnum=stoi(MyRand(4).data());

        u16 length;
        length=len1005;
        short int cmd1=0x1005;
        memset(cmdsend,0,1024);
        cmdsend[0] = length & 0xFF;
        cmdsend[1] = length >> 8;

        cmdsend[2] = cmd1 & 0xFF;
        cmdsend[3] = cmd1 >> 8;

        cmdsend[4] = serialnum & 0xFF;
        cmdsend[5] = (serialnum >> 8) & 0xFF;
        cmdsend[6] = (serialnum >> 16) & 0xFF;
        cmdsend[7] = (serialnum >> 24) & 0xFF;

        memcpy(cmdsend+8,(u8*)&cmd1005,length);
        length=length+8;
        cmdlength=length;
        u8  ret;
        u8 ucEncrypt_type=1;

        //LOG(INFO)<<GW_LOG<<"["<<_gw_cmd<<"] 加密数据开始..... cmdlength: "<<cmdlength<<"length :"<<length;
        ret = NetEncodePacket(node_id,(u32*)key,cmdsend,&length,ucEncrypt_type);
        if(ret == HUOHE_FAIL){
            gw_off_sucess=2;
            LOG(ERROR)<<GW_LOG<<"["<<_gw_cmd<<"]  指令 加密失败";
            return -1;
        } else
        {

            cmdlength=length;

            LOG(INFO)<<GW_LOG<<"["<<_gw_cmd<<"] 加密后的数据长度 : "<<cmdlength;

        }


    } else if(cmd == "0x1007")
    {
#if 1
        _gw_cmd="0x1007";
        if (cmd4002.lock_num ==0)
        {
            LOG(INFO)<<GW_LOG<<"["<<_gw_cmd<<"]此网关下接入前无下挂门锁，无需上报门锁离线";
        }
        u8 tmp1007[1024];
        memset(&tmp1007,0x00,sizeof(tmp1007));
        u16 len1007=0;
        int i_len=0;
        NODE_LOCK_NET_STATUS_INFO cmd1007;
        cmd1007.lock_num=cmd4002.lock_num;

        tmp1007[0]=cmd1007.lock_num;
        len1007=len1007+1;
        int lock_num=c2i(cmd1007.lock_num);
        for (int i = 0; i <lock_num ; ++i)
        {
            cmd1007.status[i].lock_id=cmd4002.lock_info[i].lock_id;
            cmd1007.status[i].status=254;
           // cmd1007.status[i].report_time=GetTime();
            memcpy(tmp1007+1+i_len,(u8*)&cmd1007.status[i],sizeof(cmd1007.status[i]));
            i_len=i_len+sizeof(cmd1007.status[i]);
        }
        len1007=len1007+i_len;

        int serialnum=stoi(MyRand(4).data());

        u16 length=0;
        length=len1007;
        short int cmd1=0x1007;
        memset(cmdsend,0,1024);
        cmdsend[0] = length & 0xFF;
        cmdsend[1] = length >> 8;

        cmdsend[2] = cmd1 & 0xFF;
        cmdsend[3] = cmd1 >> 8;

        cmdsend[4] = serialnum & 0xFF;
        cmdsend[5] = (serialnum >> 8) & 0xFF;
        cmdsend[6] = (serialnum >> 16) & 0xFF;
        cmdsend[7] = (serialnum >> 24) & 0xFF;

        memcpy(cmdsend+8,(u8*)&cmd1007,length);
        length=length+8;
        cmdlength=length;
        u8  ret;
        u8 ucEncrypt_type=1;

       // LOG(INFO)<<GW_LOG<<"["<<_gw_cmd<<"] 加密数据开始..... cmdlength: "<<cmdlength<<"length :"<<length;
        ret = NetEncodePacket(node_id,(u32*)key,cmdsend,&length,ucEncrypt_type);
        if(ret == HUOHE_FAIL){
            LOG(ERROR)<<GW_LOG<<"["<<_gw_cmd<<"] 指令 加密失败";
            return -1;
        } else
        {

            cmdlength=length;

            LOG(INFO)<<GW_LOG<<"["<<_gw_cmd<<"] 加密后的数据长度 : "<<cmdlength;

        }
       // LOG(INFO)<<GW_LOG<<"["<<_gw_cmd<<"] 设置发送数据完成....";


#endif
    } else if(cmd == "0x1008")
    {
        NODE_NODE_NEW_KEY_RAND_INFO cmd1008;
        memset(&cmd1008,0x00,sizeof(NODE_NODE_NEW_KEY_RAND_INFO));
        cmd1008.status=0;

        unsigned short int s_len=sizeof(NODE_NODE_NEW_KEY_RAND_INFO);
        unsigned short int s_cmd=0x1008;
        char ucEncrypt_type=1;

        if(enCodeSendData((unsigned char *)&cmd1008,s_len,s_cmd,ucEncrypt_type)<0)
        {
            LOG(INFO)<<GW_LOG<<"["<<_gw_cmd<<"] 网关更新密钥申请随机数请求加密失败";
            return -1;
        }

    }
    else if (cmd == "0x1016")
    {
        NODE_NODE_NEW_KEY_INFO cmd1016;
        memset(&cmd1016,0x00,sizeof(NODE_NODE_NEW_KEY_INFO));
        char ucEncrypt_type=1;
        u16 length=sizeof(u32);
        u8 old_key_rand_data[1024]={'\0'};
        memcpy(old_gw_public_key,gw_public_key,DH_KEY_LENGTH);
        memcpy(old_gw_private_key,gw_private_key,DH_KEY_LENGTH);
        memcpy(old_key,key,DH_KEY_LENGTH);

        DH_KEY new_public_key;
        DH_KEY new_private_key;
        u32 tmp_rand_data=rand_data;

        int ret = NetEncodePacket(node_id,(u32*)key,(u8 *)tmp_rand_data,&length,ucEncrypt_type);
        cmd1016.new_key_rand_data=tmp_rand_data;


        DH_generate_key_pair((u8 *)new_public_key, new_private_key); //计算通信密钥
        DH_KEY tmpkey;

        DH_generate_key_secret(key,new_public_key,(u8*)svr_public_key);
        memcpy(tmpkey,key,DH_KEY_LENGTH);

        ret = NetEncodePacket(node_id,(u32*)old_key,(u8 *)tmpkey,&length,ucEncrypt_type);

        cmd1016.key_len=DH_KEY_LENGTH;
        memcpy(cmd1016.old_key_new_key,tmpkey,DH_KEY_LENGTH);

        tmp_rand_data=rand_data;
        ret = NetEncodePacket(node_id,(u32*)key,(u8 *)tmp_rand_data,&length,ucEncrypt_type);

        cmd1016.new_key_rand_data=tmp_rand_data;


        unsigned short int s_len=sizeof(NODE_NODE_NEW_KEY_INFO);
        unsigned short int s_cmd=0x1016;
       // char ucEncrypt_type=1;

        if(enCodeSendData((unsigned char *)&cmd1016,s_len,s_cmd,ucEncrypt_type)<0)
        {
            LOG(INFO)<<GW_LOG<<"["<<_gw_cmd<<"] 网关更新密钥申请随机数请求加密失败";
            return -1;
        }


    }
    else if (cmd == "0x100A")
    {

        _gw_cmd="0x100A";
        NODE_NODE_WORK_PARAMETER_INFO cmd100A;
        memset(&cmd100A,0x00,sizeof(NODE_NODE_WORK_PARAMETER_INFO));
        cmd100A.status=0;
        cmd100A.work_channel=0x97;
        cmd100A.start_slice=0x30;
        cmd100A.end_slice=0x99;
        cmd100A.hard_ver=2110;
        cmd100A.soft_ver=1234;

        u8 tmp100A[1024];
        memset(&tmp100A,0x00,sizeof(tmp100A));
        u16 len100A=sizeof(NODE_NTP_CALI_TIME_INFO);
        memcpy(tmp100A,(u8*)&cmd100A,len100A);

        int serialnum=stoi(MyRand(4).data());

        u16 length=0;
        length=len100A;
        short int cmd1=0x100A;
        memset(cmdsend,0,1024);
        cmdsend[0] = length & 0xFF;
        cmdsend[1] = length >> 8;

        cmdsend[2] = cmd1 & 0xFF;
        cmdsend[3] = cmd1 >> 8;

        cmdsend[4] = serialnum & 0xFF;
        cmdsend[5] = (serialnum >> 8) & 0xFF;
        cmdsend[6] = (serialnum >> 16) & 0xFF;
        cmdsend[7] = (serialnum >> 24) & 0xFF;

        memcpy(cmdsend+8,(u8*)&cmd100A,length);
        length=length+8;
        cmdlength=length;
        u8  ret;
        u8 ucEncrypt_type=1;

        //LOG(INFO)<<GW_LOG<<"["<<_gw_cmd<<"] 加密数据开始..... cmdlength: "<<cmdlength<<"length :"<<length;
        ret = NetEncodePacket(node_id,(u32*)key,cmdsend,&length,ucEncrypt_type);
        if(ret == HUOHE_FAIL){
            gw_off_sucess=2;
            LOG(ERROR)<<GW_LOG<<"["<<_gw_cmd<<"]  指令 加密失败";
            return -1;
        } else
        {

            cmdlength=length;

            LOG(INFO)<<GW_LOG<<"["<<_gw_cmd<<"] 加密后的数据长度 : "<<cmdlength;

        }
        //LOG(INFO)<<GW_LOG<<"["<<_gw_cmd<<"] 设置发送数据完成....";

    }
    else if (cmd == "0x1003")
    {
        LOG(INFO)<<GW_LOG<<"["<<_gw_cmd<<"] 上报开门时间";
        NODE_OPEN_DOOR_TIME cmd1003;

        //自己的数据
        cmd1003.lock_num=1;
        string test_lock_id="254.101.1.1";


        for (int i = 0; i < cmd1003.lock_num; ++i) {
            cmd1003.time[i].lock_id=HostIpToNet(test_lock_id);
            //测试数据
            cmd1003.time[i].rec_num=3;
            for (int j = 0; j <cmd1003.time[i].rec_num ; ++j)
            {
                cmd1003.time[i].open_rec[j].open_type=6;
                cmd1003.time[i].open_rec[j].index=9;
                cmd1003.time[i].open_rec[j].open_time=124+j;

            }
        }

        unsigned short int s_len=sizeof(NODE_OPEN_DOOR_TIME);
        unsigned short int s_cmd=0x1003;
        char ucEncrypt_type=1;

        if(enCodeSendData((unsigned char *)&cmd1003,s_len,s_cmd,ucEncrypt_type)<0)
        {
            LOG(INFO)<<GW_LOG<<"["<<_gw_cmd<<"] 上报开门时间加密失败";
            return -1;
        }

    }
    else if (cmd == "0x1006")
    {
        LOG(INFO)<<GW_LOG<<"["<<_gw_cmd<<"] 网关请求服务器查询门锁密码";
        NODE_QUERY_LOCK_PWD_INFO cmd1006;
        //测试数据
        string test_lock_id="245.101.1.1";
        cmd1006.lock_id=HostIpToNet(test_lock_id);
        cmd1006.pwd_num=255;
        memcpy(cmd1006.pwd_type,"1",1);

        unsigned short int s_len=sizeof(NODE_QUERY_LOCK_PWD_INFO);
        unsigned short int s_cmd=0x1006;
        char ucEncrypt_type=1;

        if(enCodeSendData((unsigned char *)&cmd1006,s_len,s_cmd,ucEncrypt_type)<0)
        {
            LOG(INFO)<<GW_LOG<<"["<<_gw_cmd<<"] 网关请求服务器查询门锁密码加密失败";
            return -1;
        }
    }
    else if (cmd == "0x100B")
    {
        LOG(INFO)<<GW_LOG<<"["<<_gw_cmd<<"] 网关向服务器查询门锁配置信息";
        NODE_QUERY_CONFIG_INFO cmd100B;
        //测试数据
        cmd100B.lock_num=1;
        string test_lock_id="254.101.1.1";
        for (int i = 0; i < cmd100B.lock_num; ++i) {
            cmd100B.lock_id[i]=HostIpToNet(test_lock_id);
        }


        unsigned short int s_len=sizeof(NODE_QUERY_CONFIG_INFO);
        unsigned short int s_cmd=0x100B;
        char ucEncrypt_type=1;

        if(enCodeSendData((unsigned char *)&cmd100B,s_len,s_cmd,ucEncrypt_type)<0)
        {
            LOG(INFO)<<GW_LOG<<"["<<_gw_cmd<<"] 网关请求服务器查询门锁密码加密失败";
            return -1;
        }

    }
    else if (cmd == "0x100D")
    {
        LOG(INFO)<<GW_LOG<<"["<<_gw_cmd<<"] 网关向服务器汇报门锁重置结果开始";
        NODE_SYS_RST_LOCK_RESULT_INFO cmd100D;
        cmd100D.status=0;
        cmd100D.serial_num=atoi(MyRand(4).c_str());
        string test_lock_id="254.100.1.1";
        cmd100D.lock_id=HostIpToNet(test_lock_id);

        unsigned short int s_len=sizeof(NODE_SYS_RST_LOCK_RESULT_INFO);
        unsigned short int s_cmd=0x100D;
        char ucEncrypt_type=1;

        if(enCodeSendData((unsigned char *)&cmd100D,s_len,s_cmd,ucEncrypt_type)<0)
        {
            LOG(INFO)<<GW_LOG<<"["<<_gw_cmd<<"] 网关请求服务器查询门锁密码加密失败";
            return -1;
        }

    }
    else if (cmd == "0x100E")
    {
        LOG(INFO)<<GW_LOG<<"["<<_gw_cmd<<"] 网关请求服务器，门锁加入系统开始";

    }
    else if (cmd == "0x100F")
    {
        LOG(INFO)<<GW_LOG<<"["<<_gw_cmd<<"] 网关向服务器汇报门锁信号强度请求";
        NODE_RSSI_DATA_INFO cmd100F;
        cmd100F.lock_num=1;
        string test_lock_id="254.101.1.1";
        for (int i = 0; i <cmd100F.lock_num ; ++i) {
            cmd100F.rssi_data[i].lock_id=HostIpToNet(test_lock_id);
            cmd100F.rssi_data[i].cap_time=atoi(MyRand(4).c_str());
            cmd100F.rssi_data[i].Rssi=3;
        }

        unsigned short int s_len=sizeof(NODE_RSSI_DATA_INFO);
        unsigned short int s_cmd=0x100F;
        char ucEncrypt_type=0;

        if(enCodeSendData((unsigned char *)&cmd100F,s_len,s_cmd,ucEncrypt_type)<0)
        {
            LOG(INFO)<<GW_LOG<<"["<<_gw_cmd<<"] 网关请求服务器查询门锁密码加密失败";
            return -1;
        }


    }
    else if (cmd == "0x1011")
    {
        LOG(INFO)<<GW_LOG<<"["<<_gw_cmd<<"] 网关向服务器汇报门锁工作信道请求";
        NODE_LOCK_WORK_CHANNEL_INFO cmd1011;
        cmd1011.lock_num=1;
        string test_lock_id="254.101.1.1";
        for (int i = 0; i <cmd1011.lock_num ; ++i) {
            cmd1011.work_channel[i].lock_id=HostIpToNet(test_lock_id);
            cmd1011.work_channel[i].work_channel=20;
            cmd1011.work_channel[i].start_slice=1;
            cmd1011.work_channel[i].end_slice=255;
        }

        unsigned short int s_len=sizeof(NODE_RSSI_DATA_INFO);
        unsigned short int s_cmd=0x1011;
        char ucEncrypt_type=1;

        if(enCodeSendData((unsigned char *)&cmd1011,s_len,s_cmd,ucEncrypt_type)<0)
        {
            LOG(INFO)<<GW_LOG<<"["<<_gw_cmd<<"] 网关请求服务器查询门锁密码加密失败";
            return -1;
        }

    }
    else if (cmd == "0x1012")
    {
        LOG(INFO)<<GW_LOG<<"["<<_gw_cmd<<"] 网关向服务器汇报门锁嵌入式软件升级结果请求";
        NODE_LOCK_UPDATE_RESULT_INFO cmd1012;
        cmd1012.lock_num=1;
        string test_lock_id="254.101.1.1";
        for (int i = 0; i <cmd1012.lock_num ; ++i) {
            cmd1012.update_result[i].status=0;
            cmd1012.update_result[i].lock_id=HostIpToNet(test_lock_id);
        }

        unsigned short int s_len=sizeof(NODE_RSSI_DATA_INFO);
        unsigned short int s_cmd=0x1012;
        char ucEncrypt_type=1;

        if(enCodeSendData((unsigned char *)&cmd1012,s_len,s_cmd,ucEncrypt_type)<0)
        {
            LOG(INFO)<<GW_LOG<<"["<<_gw_cmd<<"] 网关请求服务器查询门锁密码加密失败";
            return -1;
        }

    }
    else if (cmd == "0x1013")
    {
        LOG(INFO)<<GW_LOG<<"["<<_gw_cmd<<"] 网关向服务器汇报网关嵌入式软件升级结果 网关在收到服务器下发的升级指令和数据后，开始升级，升级成功后，必须通知服务器，网关升级成功,请求";

        NODE_NODE_UPDATE_RESULT_INFO cmd1013;
        cmd1013.node_id=node_id;
        cmd1013.status=0;

        unsigned short int s_len=sizeof(NODE_RSSI_DATA_INFO);
        unsigned short int s_cmd=0x1013;
        char ucEncrypt_type=1;

        if(enCodeSendData((unsigned char *)&cmd1013,s_len,s_cmd,ucEncrypt_type)<0)
        {
            LOG(INFO)<<GW_LOG<<"["<<_gw_cmd<<"] 网关请求服务器查询门锁密码加密失败";
            return -1;
        }


    }
    else if (cmd == "0x1014")
    {
        LOG(INFO)<<GW_LOG<<"["<<_gw_cmd<<"] 关向服务器汇报门锁随机生成的128位密钥请求";



    }
    else if (cmd == "0x1015")
    {
        LOG(INFO)<<GW_LOG<<"["<<_gw_cmd<<"] 网关向服务器汇报删除门锁算法或一次性密码结果请求";
        NODE_DEL_LOCK_ALGORIM_PWD_RESULT_INFO cmd1015;
        //测试固定数值,后续修改
        string test_lock_id="254.101.1.1";
        cmd1015.lock_id=HostIpToNet(test_lock_id);
        cmd1015.serial_num=del_serial_no;
        cmd1015.pwd_num=1;

        for (int i = 0; i <cmd1015.pwd_num ; ++i) {
            cmd1015.pwd_status[i].status=0;
            cmd1015.pwd_status[i].Algorim_otp=0;
            cmd1015.pwd_status[i].pwd_type=1;
        }

        unsigned short int s_len=sizeof(NODE_RSSI_DATA_INFO);
        unsigned short int s_cmd=0x1015;
        char ucEncrypt_type=1;

        if(enCodeSendData((unsigned char *)&cmd1015,s_len,s_cmd,ucEncrypt_type)<0)
        {
            LOG(INFO)<<GW_LOG<<"["<<_gw_cmd<<"] 网关请求服务器查询门锁密码加密失败";
            return -1;
        }


    }
    else if (cmd == "0x1017")
    {
        LOG(INFO)<<GW_LOG<<"["<<_gw_cmd<<"] 网关向列表服务器请求可用服务器列表请求可传入要排除的服务器列表，如果没有可list_num为0。最多不超过5个，切返回数量不超过5个,请求";
        NODE_QUERY_SERVER_LIST_INFO cmd1017;
        cmd1017.list_num=0;

        //默认链接的服务器列表，在此处无用

        unsigned short int s_len=sizeof(NODE_RSSI_DATA_INFO);
        unsigned short int s_cmd=0x1017;
        char ucEncrypt_type=1;

        if(enCodeSendData((unsigned char *)&cmd1017,s_len,s_cmd,ucEncrypt_type)<0)
        {
            LOG(INFO)<<GW_LOG<<"["<<_gw_cmd<<"] 网关请求服务器查询门锁密码加密失败";
            return -1;
        }
    }
    else if (cmd == "0x1010")
    {
        LOG(INFO)<<GW_LOG<<"["<<_gw_cmd<<"] 5.2.23 网关向服务器上报GPRS网络信号强度(该指令目前为A830TG独有)(此指令不加密)";
        CMD_NODE_GPRS_RSSI_INFO cmd1010;
        cmd1010.cap_time=GetTime();
        cmd1010.rssi_level=0;


        unsigned short int s_len=sizeof(NODE_RSSI_DATA_INFO);
        unsigned short int s_cmd=0x1010;
        char ucEncrypt_type=0;

        if(enCodeSendData((unsigned char *)&cmd1010,s_len,s_cmd,ucEncrypt_type)<0)
        {
            LOG(INFO)<<GW_LOG<<"["<<_gw_cmd<<"] 网关请求服务器查询门锁密码加密失败";
            return -1;
        }


    }
    else if (cmd == "0x101A")
    {
        LOG(INFO)<<GW_LOG<<"["<<_gw_cmd<<"] 5.2.24 网关向服务器上报SIM卡的ICCID号(该指令目前为A830TG独有)";
        CMD_NODE_ICCID_INFO cmd101A;
        cmd101A.datalen=9;
        memcpy(cmd101A.iccid,"123456789",9);


        unsigned short int s_len=sizeof(NODE_RSSI_DATA_INFO);
        unsigned short int s_cmd=0x101A;
        char ucEncrypt_type=0;

        if(enCodeSendData((unsigned char *)&cmd101A,s_len,s_cmd,ucEncrypt_type)<0)
        {
            LOG(INFO)<<GW_LOG<<"["<<_gw_cmd<<"] 网关请求服务器查询门锁密码加密失败";
            return -1;
        }

    }
    else if (cmd == "0x1019")
    {
        LOG(INFO)<<GW_LOG<<"["<<_gw_cmd<<"] 5.2.25 网关向服务器上报GPRS模块的固件版本号(该指令目前为A830TG独有)";
        CMD_NODE_GPRS_VERS_INFO cmd1019;
        cmd1019.datalen=7;
        memcpy(cmd1019.gprs_version,"9.9.9.9",7);

        unsigned short int s_len=sizeof(NODE_RSSI_DATA_INFO);
        unsigned short int s_cmd=0x1019;
        char ucEncrypt_type=0;

        if(enCodeSendData((unsigned char *)&cmd1019,s_len,s_cmd,ucEncrypt_type)<0)
        {
            LOG(INFO)<<GW_LOG<<"["<<_gw_cmd<<"] 网关请求服务器查询门锁密码加密失败";
            return -1;
        }


    }

            else {
        LOG(WARNING)<<" 指令配置错误 ,门锁目前不支持该指令 ："<<cmd;
    }
   // _gw_data.erase(cmd);
    return 0;


}


int Gw_Task_Process::ParseRcvMsg()
{

    // 数据解密

    string cmd;

    u32 keyword;

     char print[2]={'\0'};
    string s_print="";
    for (int i = 0; i < 16; ++i) {
        sprintf(print,"%02x",key[i]);
        s_print=s_print+print;
    }

    LOG(INFO)<<GW_LOG<<"NetDecodePacket key ["<<s_print<<"]";

    u8 ret = NetDecodePacket(node_id,(u32*)key,ucData,&ucDataLen);
    if (ret == HUOHE_SUCCEED){
        LOG(INFO)<< GW_LOG <<"解密服务器数据解包成功....... ";
    } else{
        LOG(ERROR)<< GW_LOG <<" 解密服务器数据解包失败........";
        if (gw_off_sucess !=3)
                gw_off_sucess=2;

        return -1;
    }


    NODE2SVR_FRAME_STRUCT *rcvMsg1 = (NODE2SVR_FRAME_STRUCT *)ucData;

    LOG(INFO)<< GW_LOG <<"cmd :"<<rcvMsg1->cmd_data;
   // LOG(INFO)<< GW_LOG <<" LEN :"<<rcvMsg1->data_len;
    //LOG(INFO)<< GW_LOG <<"data :"<<rcvMsg1->data;

    cmd="0x" + DecIntToHexStr(rcvMsg1->cmd_data);

    print[2]={'\0'};
    s_print="";
    for (int i = 0; i < ucDataLen; ++i) {
        sprintf(print,"%02x",ucData[i]);
        s_print=s_print+print;
    }
    LOG(INFO)<<GW_LOG<< "fd : "<<listenfd <<" cmd :"<< cmd <<" 解密后的数据 : "<<s_print;

    if(cmd == "0x4000")
    {
        u32 status;

       // LOG(INFO)<< GW_LOG <<" 心跳应答包，不予处理 !!"<<status;
        SVR_ECHO_HELLO_INFO *cmd4000=NULL;
        memset(&cmd4000,0x00,sizeof(SVR_ECHO_HELLO_INFO));
        cmd4000 = (SVR_ECHO_HELLO_INFO *)rcvMsg1->data;

        if(cmd4000->status == 0){
            gw_off_sucess=3 ;//数据已经取完,可以执行门锁的操作，若无门锁操作，则接收，发送心跳
            hurt_send_off=0;//
            LOG(INFO)<< GW_LOG <<" 心跳数据正确......";
            return 0;
        }
        else if (cmd4000->status == 1){
            LOG(ERROR)<< GW_LOG <<" hello 数据出错 !!!!!!!";
            if (gw_off_sucess !=3)
                gw_off_sucess=2;
            return -1;
        } else{
            LOG(WARNING)<< GW_LOG <<" 心跳应答状态未明确 ,status :"<<status;
            return -2;
        }


    }
    else if(cmd == "0x4001")
    {

       // LOG(INFO )<< GW_LOG <<" 网关申请接入应答解包成功 ";
        SVR_ECHO_NODE_JOININ_INFO *rcv4001=NULL;
        rcv4001 = (SVR_ECHO_NODE_JOININ_INFO *)rcvMsg1->data;
        if (rcv4001->status == 0){
            LOG(INFO)<< GW_LOG <<" N-HAP服务器同意网关 ["<<_gw_id<<"] 接入成功";
        } else if (rcv4001->status == 1){
            LOG(INFO)<< GW_LOG <<" N-HAP服务器拒绝网关 [ "<<_gw_id<<"] 接入失败";
            return rcv4001->status;
        } else if (rcv4001->status == 2){
            LOG(INFO)<< GW_LOG <<" N-HAP服务器忙网关 [ "<<_gw_id<<"] 接入失败";
            return -rcv4001->status;
        } else if (rcv4001->status ==3){
            LOG(INFO)<< GW_LOG <<" N-HAP服务器强制删除网关 [ "<<_gw_id<<"] 接入失败";
            return rcv4001->status;
        } else{
            LOG(INFO)<<GW_LOG << " N-HAP服务器应答状态为明,网关 [ "<<_gw_id<<"] 接入失败";
            return rcv4001->status;
        }

        auth_data=rcv4001->auth_data;
        check_node_random_data=rcv4001->check_node_random_data;
        memcpy(svr_public_key,rcv4001->svr_public,16);

        /*
        char path[256]={'\0'};
        char *h=getenv("HOME");
        sprintf(path,"%s%s",h,PWD_DIR);
        struct stat buf;
        int ret1 =   stat(path,&buf);
        if(ret1 != 0)
         */


        LOG(INFO)<<GW_LOG<<" 密码的数量count: "<<keyCount;
        //DH_generate_key_secret(key,gw_private_key,(u8*)svr_public_key);

#if 1

        /*
        string path = getdir()+"DB/gwDatabase.db";

        char sql[2048]={'\0'};
        int ret = sqlite3_open(path.c_str(),&db);
        if(ret < 0)
        {
            LOG(ERROR)<<" 创建gwDatabase.db数据库失败!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!1";
            return -1;
        }
        */
        ONELine:
        if(keyCount ==0)
        {/*
            ofstream fd;
            fd.open(path,ios::out|ios::binary);
            LOG(INFO)<<" --------------------------保存密钥";
            */
            //计算通信密钥
            DH_generate_key_secret(key,gw_private_key,(u8*)svr_public_key);
            /*
            //fd<<key;
            fd.write((char *)key,16);
            LOG(INFO)<<GW_LOG<<" 写入网关通信密钥。。";
            fd.close();
            */
            char *insert="insert into gw_id_key(gw_id,u32_id,key,status) values('%s',%d,'%s',%d);";
            char sql[1024]={'\0'};
            sprintf(sql,insert,_gw_id.c_str(),(u32)HostIpToNet(_gw_id),key,1);
            InsertDB(db,sql);
            LOG(INFO)<<GW_LOG<<" 写入网关通信密钥完成......... ";

        } else
        {
            /*
            ifstream fd;
            fd.open(path,ios::in|ios::binary);
            fd.read((char *)key,16);
            LOG(INFO)<<"--------------------------密钥一存在";
            fd.close();
             */
            char *select="select key  from gw_id_key where gw_id='%s' and status=1;";
            char msql[256]={'\0'};

            sprintf(msql,select,_gw_id.c_str());

            int ret = sqlite3_get_table(db,msql,&azReuslt,&nrow,&ncolumn,&zErrMsg);
            if(ret != SQLITE_OK)
            {
                LOG(INFO)<<GW_LOG<<"查询密钥信息失败";
                sqlite3_free(zErrMsg);
                keyCount=0;
                goto ONELine;
            }
            memcpy(key,azReuslt[1],16);
            sqlite3_free_table(azReuslt);
        }
        //sqlite3_close(db);
#endif

        //计算check_auth_data
        GenAuthKey(node_id,(u32*)key,auth_data,&check_auth_data,2);


        if(gw_off_sucess !=3)
            gw_off_sucess=1;

    }
    else if(cmd == "0x4002")
    {
        //cmd4002=(SVR_ECHO_NOTIFY_VALID_INFO *)rcvMsg1->data;
        memcpy(&cmd4002,((SVR_ECHO_NOTIFY_VALID_INFO *)rcvMsg1->data),sizeof(SVR_ECHO_NOTIFY_VALID_INFO));
        if (cmd4002.status == 0){
            LOG(INFO)<<GW_LOG<<"["<<rcvMsg1->cmd_data<<"]初始化查询成功";
        } else if (cmd4002.status == 1){
            LOG(INFO)<<GW_LOG<<"["<<rcvMsg1->cmd_data<<"]初始化查询应答状态[ "<<cmd4002.status<<" ] 重新申请接入";
            if(gw_off_sucess !=3)
                gw_off_sucess=2;
            return -1;
        }

        if (gw_off_sucess !=3)
            gw_off_sucess=1;

    }
    else if(cmd == "0x4003")
    {

    } else if(cmd == "0x4004")
    {

        LOG(INFO)<<GW_LOG<<"["<<cmd<<"] 指令应答开始.....";
        SVR_ECHO_LOCK_INFO_INFO cmd4004;
        memset(&cmd4004,0x00,sizeof(SVR_ECHO_LOCK_INFO_INFO));
        memcpy(&cmd4004,rcvMsg1->data,sizeof(SVR_ECHO_LOCK_INFO_INFO));
        if(cmd4004.status != 0)
        {
            LOG(INFO)<<GW_LOG<<"["<<cmd<<"] 上报门锁信息应答失败了";
        }
        LOG(INFO)<<GW_LOG<<"["<<cmd<<"] 上报门锁信息应答成功 ";

    } else if(cmd == "0x4005")
    {
        LOG(INFO)<<GW_LOG<<"["<<cmd<<"]校准时间应答开始.....";
        if (gw_off_sucess !=3)
            gw_off_sucess=1;
    }else if(cmd == "0x4006")
    {

    }
    else if(cmd == "0x4007")
    {

        //_gw_cmd="0x4007";
        LOG(INFO)<<GW_LOG<<"["<<cmd<<"]网关汇报门锁状态应答......";
        SVR_ECHO_LOCK_NET_STATUS_INFO cmd4007;
        memset(&cmd4007,0x00,sizeof(SVR_ECHO_LOCK_NET_STATUS_INFO));
        memcpy(&cmd4007,rcvMsg1->data,sizeof(SVR_ECHO_LOCK_NET_STATUS_INFO));

        if(cmd4007.status !=0)
        {
            LOG(INFO)<<GW_LOG<<"["<<cmd<<"]网关汇报门锁状态应答状态失败";
            return cmd4007.status;
        }
        LOG(INFO)<<GW_LOG<<"["<<cmd<<"]网关汇报门锁状态应答状态成功";
        if (lockOnLineFlag == 1)
        {
            LOG(INFO)<<GW_LOG<<"["<<_gw_cmd<<"]----------mmmmmm----------网关汇报门锁状态应答信号";
            ParseLockData((char *)rcvMsg1,cmd);
        } else{
            LOG(INFO)<<GW_LOG<<"["<<_gw_cmd<<"]-----------kkkkkkkkk---------网关汇报门锁状态应答信号";
            gw_off_sucess=1;
        }

    }
    else if(cmd == "0x4008")
    {
        LOG(INFO)<<LOG(INFO)<<GW_LOG<<"["<<_gw_cmd<<"] 网关密钥更新申请随机数应答开始";
        SVR_ECHO_NODE_NEW_KEY_RAND_INFO cmd4008;
        memset(&cmd4008,0x00,sizeof(SVR_ECHO_NODE_NEW_KEY_RAND_INFO));
        if(cmd4008.status == 0)
        {
            LOG(INFO)<<LOG(INFO)<<GW_LOG<<"["<<_gw_cmd<<"] 网关密钥更新申请随机数成功";
            rand_data=cmd4008.rand_data;
        }
        else
        {
            LOG(INFO)<<LOG(INFO)<<GW_LOG<<"["<<_gw_cmd<<"] 网关密钥更新申请随机数失败";
            return -1;
        }
    }
    else if(cmd == "0x1016")
    {
        LOG(INFO)<<GW_LOG<<"["<<_gw_cmd<<"] 网关密钥更新应答开始";
        SVR_ECHO_NODE_NEW_KEY_INFO cmd1016;
        memcpy(&cmd1016,(SVR_ECHO_NODE_NEW_KEY_INFO *)rcvMsg1->data,sizeof(SVR_ECHO_NODE_NEW_KEY_INFO));
        if (cmd1016.status != 0)
        {
            LOG(INFO)<<GW_LOG<<"["<<_gw_cmd<<"] 网关密钥更新应答失败";
            return -1;
        }
        LOG(INFO)<<GW_LOG<<"["<<_gw_cmd<<"] 网关密钥更新应答成功";
    }
    else if(cmd == "0x400A")
    {

        LOG(INFO)<<GW_LOG<<"["<<_gw_cmd<<"]网关向服务器汇报网关参数应答开始......";
        //gw_off_sucess=3;

        //next_cmd="0x1000";
        //setGwCmd(next_cmd);
        SVR_ECHO_NODE_WORK_PARAMETER_INFO cmd400A;
        memset(&cmd400A,0x00,sizeof(SVR_ECHO_NODE_WORK_PARAMETER_INFO));
        memcpy(&cmd400A,(SVR_ECHO_NODE_WORK_PARAMETER_INFO *)rcvMsg1->data,sizeof(SVR_ECHO_NODE_WORK_PARAMETER_INFO));
        if (cmd400A.status != 0)
        {
            LOG(INFO)<<GW_LOG<<"["<<_gw_cmd<<"] 网关向服务器汇报网关参数应答失败";
            return cmd400A.status;
        }
        LOG(INFO)<<GW_LOG<<"["<<_gw_cmd<<"] 汇网关向服务器汇报网关参数应答成功";

    }
    else if(cmd == "0x4003")
    {
        LOG(INFO)<<GW_LOG<<"["<<_gw_cmd<<"] 汇报门锁开门时间应答开始";
        SVR_ECHO_OPEN_DOOR_TIME_INFO cmd4003;
        memcpy(&cmd4003,(SVR_ECHO_OPEN_DOOR_TIME_INFO *)rcvMsg1->data,sizeof(SVR_ECHO_OPEN_DOOR_TIME_INFO));
        if (cmd4003.status != 0)
        {
            LOG(INFO)<<GW_LOG<<"["<<_gw_cmd<<"] 汇报门锁开门时间应答失败";
            return cmd4003.status;
        }
        LOG(INFO)<<GW_LOG<<"["<<_gw_cmd<<"] 汇报门锁开门时间应答成功";
    }
    else if(cmd == "0x4006")
    {
        LOG(INFO)<<GW_LOG<<"["<<_gw_cmd<<"] 网关申请查询门锁密码应答";
        SVR_ECHO_QUERY_LOCK_PWD_INFO cmd4006;
        memcpy(&cmd4006,(SVR_ECHO_QUERY_LOCK_PWD_INFO *)rcvMsg1->data,sizeof(SVR_ECHO_QUERY_LOCK_PWD_INFO));
        if (cmd4006.status != 0)
        {
            LOG(INFO)<<GW_LOG<<"["<<_gw_cmd<<"] 网关申请查询门锁密码应答失败";
            return cmd4006.status;
        }

        LOG(INFO)<<GW_LOG<<"["<<_gw_cmd<<"] 网关申请查询门锁密码应答成功";
        //是否需要把后续数据拿出来，取决于后续门锁是否需要，保留

    }
    else if(cmd == "0x4009")
    {
        LOG(INFO)<<GW_LOG<<"["<<_gw_cmd<<"] 服务器应答网关汇报密码设置结果应答开始";
        SVR_ECHO_SET_PWD_RESULT_INFO cmd4009;
        memcpy(&cmd4009,(SVR_ECHO_SET_PWD_RESULT_INFO*)rcvMsg1->data,sizeof(SVR_ECHO_SET_PWD_RESULT_INFO));
        if(cmd4009.status !=0)
        {
            LOG(INFO)<<GW_LOG<<"["<<_gw_cmd<<"] 服务器应答网关汇报密码设置结果应答失败";
            return  cmd4009.status;
        }
        LOG(INFO)<<GW_LOG<<"["<<_gw_cmd<<"] 服务器应答网关汇报密码设置结果应答成功";
    }
    else if(cmd == "0x400B")
    {
        LOG(INFO)<<GW_LOG<<"["<<_gw_cmd<<"] 服务器应答网关门锁的配置信息开始";
        SVR_ECHO_QUERY_CONFIG_INFO cmd400B;
        memcpy(&cmd400B,(SVR_ECHO_QUERY_CONFIG_INFO *)rcvMsg1->data,sizeof(SVR_ECHO_QUERY_CONFIG_INFO));
        if (cmd400B.status != 0)
        {
            LOG(INFO)<<GW_LOG<<"["<<_gw_cmd<<"] 服务器应答网关门锁的配置信息失败";
            return cmd400B.status;
        }
        //是否需要把后续数据拿出来，取决于后续门锁是否需要，保留
    }
    else if(cmd == "0x400D")
    {
        LOG(INFO)<<GW_LOG<<"["<<_gw_cmd<<"] 服务器应答重置门锁结果应答开始";
        SVR_ECHO_SYS_RST_LOCK_RESULT_INFO cmd400D;
        memcpy(&cmd400D,(SVR_ECHO_SYS_RST_LOCK_RESULT_INFO *)rcvMsg1->data,sizeof(SVR_ECHO_SYS_RST_LOCK_RESULT_INFO));
        if (cmd400D.status != 0)
        {
            LOG(INFO)<<GW_LOG<<"["<<_gw_cmd<<"] 服务器应答重置门锁结果应答开始失败";
            return cmd400D.status;
        }
    }
    else if(cmd == "0x400E")
    {

        LOG(INFO)<<GW_LOG<<"["<<_gw_cmd<<"] 服务器应答网关请求增加门锁应答开始";
        /*
        SVR_ECHO_ADD_LOCK_INFO cmd400E;
        memcpy(&cmd400E,(SVR_ECHO_ADD_LOCK_INFO *)rcvMsg1->data,sizeof(SVR_ECHO_ADD_LOCK_INFO));
        LOG(INFO)<<GW_LOG<<"["<<_gw_cmd<<"] 服务器应答网关请求增加,status : "<<cmd400E.status;
        char tmp[2]={'\0'};
        sprintf(tmp,"%02x",cmd400E.Add_lock_ack[0].status);
        LOG(INFO)<<GW_LOG<<"["<<_gw_cmd<<"] 服务器应答网关请求是否同意接入,status : "<<atoi(tmp);

        if (cmd400E.status != 0)
        {
            LOG(INFO)<<GW_LOG<<"["<<_gw_cmd<<"] 服务器应答网关请求增加门锁失败";
            return cmd400E.status;
        }

        */
        //后续需要根据门锁数据结构将数据解析到门锁数据结构中

        ParseLockData((char *)rcvMsg1,cmd);

    }
    else if(cmd == "0x400F")
    {
        LOG(INFO)<<GW_LOG<<"["<<_gw_cmd<<"] 网关向服务器汇报门锁信号强度应答开始";
        SVR_ECHO_RSSI_DATA_INFO cmd400F;
        memcpy(&cmd400F,(SVR_ECHO_RSSI_DATA_INFO *)rcvMsg1->data,sizeof(SVR_ECHO_RSSI_DATA_INFO));
        if(cmd400F.status != 0)
        {
            LOG(INFO)<<GW_LOG<<"["<<_gw_cmd<<"] 网关向服务器汇报门锁信号强度应答失败";
            return cmd400F.status;
        }
    }
    else if(cmd == "0x4011")
    {
        LOG(INFO)<<GW_LOG<<"["<<_gw_cmd<<"] 网关向服务器汇报门锁工作信道应答开始";

        SVR_ECHO_LOCK_WORK_CHANNEL_INFO cmd4011;
        memcpy(&cmd4011,(SVR_ECHO_LOCK_WORK_CHANNEL_INFO *)rcvMsg1->data,sizeof(SVR_ECHO_LOCK_WORK_CHANNEL_INFO));
        if (cmd4011.status != 0)
        {
            LOG(INFO)<<GW_LOG<<"["<<_gw_cmd<<"] 网关向服务器汇报门锁工作信道应答失败";
            return cmd4011.status;
        }
    }
    else if(cmd == "0x4012")
    {
        LOG(INFO)<<GW_LOG<<"["<<_gw_cmd<<"] 网关向服务器汇报门锁嵌入式软件升级结果应答开始";
        SVR_ECHO_LOCK_UPDATE_RESULT_INFO cmd4012;
        memcpy(&cmd4012,(SVR_ECHO_LOCK_UPDATE_RESULT_INFO *)rcvMsg1->data,sizeof(SVR_ECHO_LOCK_UPDATE_RESULT_INFO));
        if(cmd4012.status != 0)
        {
            LOG(INFO)<<GW_LOG<<"["<<_gw_cmd<<"] 网关向服务器汇报门锁嵌入式软件升级结果应答失败";
            return cmd4012.status;
        }

    }
    else if(cmd == "0x4013")
    {
        LOG(INFO)<<GW_LOG<<"["<<_gw_cmd<<"] 网关向服务器汇报网关嵌入式软件升级结果 网关在收到服务器下发的升级指令和数据后，开始升级，升级成功后，必须通知服务器，网关升级成功,应答开始";
        SVR_ECHO_NODE_UPDATE_RESULT_INFO cmd4013;
        memcpy(&cmd4013,(SVR_ECHO_NODE_UPDATE_RESULT_INFO *)rcvMsg1->data,sizeof(SVR_ECHO_NODE_UPDATE_RESULT_INFO));
        if (cmd4013.status != 0)
        {
            LOG(INFO)<<GW_LOG<<"["<<_gw_cmd<<"] 网关向服务器汇报网关嵌入式软件升级结果 网关在收到服务器下发的升级指令和数据后，开始升级，升级成功后，必须通知服务器，网关升级成功,应答失败";
            return cmd4013.status;
        }
    }
    else if(cmd == "0x4014")
    {
        LOG(INFO)<<GW_LOG<<"["<<_gw_cmd<<"] 关向服务器汇报门锁随机生成的128位密钥应答开始";
        SVR_ECHO_LOCK_KEY_INFO cmd4014;
        memcpy(&cmd4014,(SVR_ECHO_LOCK_KEY_INFO*)rcvMsg1->data,sizeof(SVR_ECHO_LOCK_KEY_INFO));
        if (cmd4014.status != 0)
        {
            LOG(INFO)<<GW_LOG<<"["<<_gw_cmd<<"] 关向服务器汇报门锁随机生成的128位密钥应答失败";
            return cmd4014.status;
        } else{
            LOG(INFO)<<GW_LOG<<"["<<_gw_cmd<<"] 关向服务器汇报门锁随机生成的128位密钥应答成功";
        }

    }
    else if(cmd == "0x400C")
    {
        LOG(INFO)<<GW_LOG<<"["<<_gw_cmd<<"] 网关向服务器汇报删除门锁普通密码结果应答";

        SVR_ECHO_DEL_LOCK_PWD_RESULT_INFO cmd400C;
        memcpy(&cmd400C,(SVR_ECHO_DEL_LOCK_PWD_RESULT_INFO *)rcvMsg1->data,sizeof(SVR_ECHO_DEL_LOCK_PWD_RESULT_INFO));
        if (cmd400C.status != 0)
        {
            LOG(INFO)<<GW_LOG<<"["<<_gw_cmd<<"] 网关向服务器汇报删除门锁普通密码结果应答失败";
            return cmd400C.status;
        }
    }
    else if(cmd == "0x4015")
    {
        LOG(INFO)<<GW_LOG<<"["<<_gw_cmd<<"] 网关向服务器汇报删除门锁算法或一次性密码结果应答开始";
        SVR_ECHO_DEL_LOCK_ALGORIM_PWD_RESULT_INFO cmd4015;
        memcpy(&cmd4015,(SVR_ECHO_DEL_LOCK_ALGORIM_PWD_RESULT_INFO *)rcvMsg1->data,sizeof(SVR_ECHO_DEL_LOCK_ALGORIM_PWD_RESULT_INFO));
        if(cmd4015.status != 0)
        {
            LOG(INFO)<<GW_LOG<<"["<<_gw_cmd<<"] 网关向服务器汇报删除门锁算法或一次性密码结果应答失败";
            return cmd4015.status;
        }
    }
    else if(cmd == "0x4017")
    {
        LOG(INFO)<<GW_LOG<<"["<<_gw_cmd<<"] 网关向列表服务器请求可用服务器列表请求可传入要排除的服务器列表，如果没有可list_num为0。最多不超过5个，切返回数量不超过5个应答开始";
        SVR_ECHO_QUERY_SERVER_LIST_INFO cmd4017;
        memcpy(&cmd4017,(SVR_ECHO_QUERY_SERVER_LIST_INFO *)rcvMsg1->data,sizeof(SVR_ECHO_QUERY_SERVER_LIST_INFO));
        if (cmd4017.status != 0)
        {
            LOG(INFO)<<GW_LOG<<"["<<_gw_cmd<<"] 网关向列表服务器请求可用服务器列表请求可传入要排除的服务器列表，如果没有可list_num为0。最多不超过5个，切返回数量不超过5个应答失败";
            return cmd4017.status;
        }

    }
    else if(cmd == "0x4010")
    {
        LOG(INFO)<<GW_LOG<<"["<<_gw_cmd<<"] 5.2.23 网关向服务器上报GPRS网络信号强度(该指令目前为A830TG独有)(此指令不加密) ,请求";
        SVR_RPY_NODE_GPRS_RSSI_INFO cmd4010;
        memcpy(&cmd4010,(SVR_RPY_NODE_GPRS_RSSI_INFO *)rcvMsg1->data,sizeof(SVR_RPY_NODE_GPRS_RSSI_INFO));
        if(cmd4010.status != 0)
        {
            LOG(INFO)<<GW_LOG<<"["<<_gw_cmd<<"] 5.2.23 网关向服务器上报GPRS网络信号强度(该指令目前为A830TG独有)(此指令不加密) ,失败";
            return cmd4010.status;
        }
    }
    else if(cmd == "0x401A")
    {
        LOG(INFO)<<GW_LOG<<"["<<_gw_cmd<<"] 5.2.24 网关向服务器上报SIM卡的ICCID号(该指令目前为A830TG独有) ,请求";
        SVR_RPY_NODE_ICCID_INFO cmd401A;
        memcpy(&cmd401A,(SVR_RPY_NODE_ICCID_INFO *)rcvMsg1->data,sizeof(SVR_RPY_NODE_ICCID_INFO));
        if(cmd401A.status != 0)
        {
            LOG(INFO)<<GW_LOG<<"["<<_gw_cmd<<"] .2.24 网关向服务器上报SIM卡的ICCID号(该指令目前为A830TG独有) ,失败";
            return cmd401A.status;
        }
    }
    else if(cmd == "0x4019")
    {
        LOG(INFO)<<GW_LOG<<"["<<_gw_cmd<<"] 5.2.25 网关向服务器上报GPRS模块的固件版本号(该指令目前为A830TG独有) ,请求";
        SVR_RPY_GPRS_VERS_INFO cmd4019;
        memcpy(&cmd4019,(SVR_RPY_GPRS_VERS_INFO *)rcvMsg1->data,sizeof(SVR_RPY_GPRS_VERS_INFO));
        if(cmd4019.status != 0)
        {
            LOG(INFO)<<GW_LOG<<"["<<_gw_cmd<<"] 5.2.25 网关向服务器上报GPRS模块的固件版本号(该指令目前为A830TG独有) ,失败";
            return cmd4019.status;
        }
    }


    else if(cmd == "0x3000") /* 服务器向网关下发数据 */
    {
        _gw_cmd="0x3000";
        LOG(INFO)<<GW_LOG<<"["<<cmd<<"] 服务器请求网关设置门锁器密码开始........";
        /*
        SVR_SET_LOCK_PWD_INFO cmd3000;
        memcpy(&cmd3000,(SVR_SET_LOCK_PWD_INFO *)rcvMsg1->data,sizeof(SVR_SET_LOCK_PWD_INFO));

        LOG(INFO)<< GW_LOG<< " 网关的门锁编号 :" << cmd3000.lock_id;
        memset(DownQuestCmdData,0x00,sizeof(DownQuestCmdData));
        memcpy(DownQuestCmdData,rcvMsg1->data,sizeof(SVR_SET_LOCK_PWD_INFO));

        DownQuestCmd=string("0x2000");
        */
        //memset(DownQuestCmdData,0x00,sizeof(DownQuestCmdData));
       // memcpy(DownQuestCmdData,rcvMsg1->data,sizeof(SVR_SET_LOCK_PWD_INFO));

        RequestRcvSvr("0x2000",0); //立即应答服务器数据受到成功
        ParseLockData((char *)rcvMsg1,cmd);//发送给门锁数据处理

    }else if(cmd == "0x3003")
    {
        LOG(INFO)<<GW_LOG<<"["<<cmd<<"] 服务器请求网关解除门锁绑定";

        SVR_DEL_LOCK_INFO cmd3003;
        memcpy(&cmd3003,(SVR_DEL_LOCK_INFO *)rcvMsg1->data,sizeof(SVR_DEL_LOCK_INFO));
        LOG(INFO)<<GW_LOG<<"["<<cmd<<"]  门锁数量"<< cmd3003.lock_num;
        memset(DownQuestCmdData,0x00,sizeof(DownQuestCmdData));
        memcpy(DownQuestCmdData,rcvMsg1->data,sizeof(SVR_DEL_LOCK_INFO));

        //DownQuestCmd=string("0x2003");

        //memset(DownQuestCmdData,0x00,sizeof(DownQuestCmdData));
        //memcpy(DownQuestCmdData,rcvMsg1->data,sizeof(SVR_DEL_LOCK_INFO));

        RequestRcvSvr("0x2003",cmd3003.lock_id);
        ParseLockData((char *)rcvMsg1,cmd);

    }else if(cmd == "0x3004")
    {
        LOG(INFO)<<GW_LOG<<"["<<cmd<<"]设置网关门锁通信时隙";

        memset(DownQuestCmdData,0x00,sizeof(DownQuestCmdData));
        memcpy(DownQuestCmdData,rcvMsg1->data,sizeof(SVR_SET_TIME_SLICE_INFO));
        ParseLockData((char *)rcvMsg1,cmd);

    }else if(cmd == "0x3014")
    {
        LOG(INFO)<<GW_LOG<<"["<<cmd<<"]查询网关门锁通信时隙";

    } else if(cmd == "0x3005")
    {
        LOG(INFO)<<GW_LOG<<"["<<cmd<<"] 服务器设置网关工作频点";

    } else if(cmd == "0x3015")
    {
        LOG(INFO)<<GW_LOG<<"["<<cmd<<"] 查询网关的工作频点值 ";

    }else if(cmd == "0x3006")
    {
        LOG(INFO)<<GW_LOG<<"["<<cmd<<"]  设置网关访问服务器地址 ";

    }else if(cmd == "0x3016")
    {
        LOG(INFO)<<GW_LOG<<"["<<cmd<<"] 查询网关访问的服务器地址 ";
    }else if(cmd == "0x3007")
    {
        LOG(INFO)<<GW_LOG<<"["<<cmd<<"] 服务器下发删除网关门锁密码";
        //memset(DownQuestCmdData,0x00,sizeof(DownQuestCmdData));
       // memcpy(DownQuestCmdData,rcvMsg1->data,sizeof(SVR_DEL_LOCK_PWD_INFO));

        RequestRcvSvr("0x2007",0);
        ParseLockData((char *)rcvMsg1,cmd);

    }else if(cmd == "0x3008")
    {
        LOG(INFO)<<GW_LOG<<"["<<cmd<<"] 服务器下发复位门锁";

        memset(DownQuestCmdData,0x00,sizeof(DownQuestCmdData));
        memcpy(DownQuestCmdData,rcvMsg1->data,sizeof(SVR_SYS_RST_LOCK_INFO));
        ParseLockData((char *)rcvMsg1,cmd);

    }else if(cmd == "0x3009")
    {
        LOG(INFO)<<GW_LOG<<"["<<cmd<<"] 服务器通知网关固件升级";

    }else if(cmd =="0x300D")
    {
        LOG(INFO)<<GW_LOG<<"["<<cmd<<"] 服务器通知网关查询门锁数据";

        memset(DownQuestCmdData,0x00,sizeof(DownQuestCmdData));
        memcpy(DownQuestCmdData,rcvMsg1->data,sizeof(CMD_SVR_QUERY_LOCK_INFO));
        ParseLockData((char *)rcvMsg1,cmd);
    }else if(cmd == "0x300E")
    {

        LOG(INFO)<<GW_LOG<<"["<<cmd<<"] 服务器通知网关重启门锁 ";

        memset(DownQuestCmdData,0x00,sizeof(DownQuestCmdData));
        memcpy(DownQuestCmdData,rcvMsg1->data,sizeof(CMD_SVR_RESTART_LOCK_INFO));
        ParseLockData((char *)rcvMsg1,cmd);

    }else if(cmd =="0x3010")
    {
        LOG(INFO)<<GW_LOG<<"["<<cmd<<"] 服务器请求网关门锁开门指令";
        memset(DownQuestCmdData,0x00,sizeof(DownQuestCmdData));
        memcpy(DownQuestCmdData,rcvMsg1->data,sizeof(SVR_OPEN_DOOR_INFO));
        ParseLockData((char *)rcvMsg1,cmd);

    }else if(cmd == "0x3011")
    {
        LOG(INFO)<<GW_LOG<<"["<<cmd<<"] 服务器请求网关门删除门锁算法或一次性密码";

        memset(DownQuestCmdData,0x00,sizeof(DownQuestCmdData));
        memcpy(DownQuestCmdData,rcvMsg1->data,sizeof(SVR_SET_DEL_LOCK_ALGORIM_PWD_INFO));
        ParseLockData((char *)rcvMsg1,cmd);
    }
    else{
        LOG(INFO)<< GW_LOG <<" 应答指令不存在 ...!!!! cmd :"<<cmd;
    }

    _gw_data.erase(_gw_cmd);
    return 0;

}

/*
 * 应答网关下发指令
 */
int Gw_Task_Process::DownQuest(string &cmd,string &l_ID)
{
    if(cmd  == "0x3000")
    {
        /*
        NODE_ECHO_SET_PWD_INFO cmd2000;
        cmd2000.status=0;

        u8 tmp2000[1024]={0};
        u16 len2000=sizeof(NODE_ECHO_SET_PWD_INFO);
        memcpy(tmp2000,(u8*)&cmd2000,len2000);
        */

        unsigned short int s_cmd=0x2000;
        char ucEncrypt_type=1;

        memset(cmdsend,0,1024);

        int length=l_ID.size();
        int serialnum=atoi(MyRand(4).c_str());
        cmdsend[0] = length & 0xFF;
        cmdsend[1] = length >> 8;

        cmdsend[2] = s_cmd & 0xFF;
        cmdsend[3] = s_cmd >> 8;

        cmdsend[4] = serialnum & 0xFF;
        cmdsend[5] = (serialnum >> 8) & 0xFF;
        cmdsend[6] = (serialnum >> 16) & 0xFF;
        cmdsend[7] = (serialnum >> 24) & 0xFF;

        length=length+8;
        cmdlength=length;

        memcpy(cmdsend+8,l_ID.c_str(),l_ID.size());
        char ret= NetEncodePacket(node_id,(u32 *) key,cmdsend,&cmdlength,ucEncrypt_type);
        if (ret == HUOHE_FAIL)
        {
            LOG(INFO) << GW_LOG << "[" << _gw_cmd << "] 指令 加密失败";
            return -1;
        }


    } else if(cmd == "0x30030")
    {
        /*
        SVR_DEL_LOCK_INFO cmd3003;
        NODE_ECHO_DEL_LOCK_INFO cmd2003;
        memcpy(&cmd3003,(SVR_DEL_LOCK_INFO *)(DownQuestCmdData),sizeof(SVR_DEL_LOCK_INFO));

        cmd2003.lock_num=cmd3003.lock_num;
        int llock_num=cmd3003.lock_num-'A'+10;

        for (int i = 0; i <llock_num ; ++i) {
            cmd2003.del_lock[i].status=0;
            cmd2003.del_lock[i].lock_id=cmd3003.lock_id[i];

        }

        u8 tmp2003[1024]={0};
        u16 len2003=sizeof(NODE_ECHO_DEL_LOCK_INFO);

        memcpy(tmp2003,(u8*)&cmd2003,len2003);
         */
        unsigned short int s_cmd=0x2003;
        char ucEncrypt_type=1;
        memset(cmdsend,0,1024);

        int length=l_ID.size();
        int serialnum=atoi(MyRand(4).c_str());
        cmdsend[0] = length & 0xFF;
        cmdsend[1] = length >> 8;

        cmdsend[2] = s_cmd & 0xFF;
        cmdsend[3] = s_cmd >> 8;

        cmdsend[4] = serialnum & 0xFF;
        cmdsend[5] = (serialnum >> 8) & 0xFF;
        cmdsend[6] = (serialnum >> 16) & 0xFF;
        cmdsend[7] = (serialnum >> 24) & 0xFF;

        length=length+8;
        cmdlength=length;
        memcpy(cmdsend+8,l_ID.c_str(),l_ID.size());

        char ret= NetEncodePacket(node_id,(u32 *) key,cmdsend,&cmdlength,ucEncrypt_type);
        if (ret == HUOHE_FAIL)
        {
            LOG(INFO) << GW_LOG << "[" << _gw_cmd << "] 指令 加密失败";
            return -1;
        }
    }
    else if (cmd == "0x3004") //设置网关与门锁通信时隙
    {
        LOG(INFO)<<GW_LOG<< " [ "<<cmd<< " ] "<<"设置网关与门锁通信时隙开始 ";
        NODE_ECHO_SET_TIME_SLICE_INFO cmd2004;
        cmd2004.status=0;

        u8 tmp2004[1024]={0};
        u16 len2004=sizeof(NODE_ECHO_SET_TIME_SLICE_INFO);
        memcpy(tmp2004,(u8*)&cmd2004,len2004);
        unsigned short int s_cmd=0x2004;
        char ucEncrypt_type=1;
        memset(cmdsend,0,1024);

        int length=l_ID.size();
        int serialnum=atoi(MyRand(4).c_str());
        cmdsend[0] = length & 0xFF;
        cmdsend[1] = length >> 8;

        cmdsend[2] = s_cmd & 0xFF;
        cmdsend[3] = s_cmd >> 8;

        cmdsend[4] = serialnum & 0xFF;
        cmdsend[5] = (serialnum >> 8) & 0xFF;
        cmdsend[6] = (serialnum >> 16) & 0xFF;
        cmdsend[7] = (serialnum >> 24) & 0xFF;

        length=length+8;
        cmdlength=length;
        memcpy(cmdsend+8,l_ID.c_str(),l_ID.size());

        char ret= NetEncodePacket(node_id,(u32 *) key,cmdsend,&cmdlength,ucEncrypt_type);
        if (ret == HUOHE_FAIL)
        {
            LOG(INFO) << GW_LOG << "[" << _gw_cmd << "] 指令 加密失败";
            return -1;
        }

    } else if (cmd == "0x3014")
    {
        LOG(INFO)<<GW_LOG<< " [ "<<cmd<< " ] "<<" 查询网关门锁工作时隙开始";
        NODE_ECHO_QUERY_TIME_SLICE_INFO cmd2014;
        cmd2014.status=0;
        cmd2014.end_slice=0xFF;
        cmd2014.start_slice=0x00;
        u8 tmp2014[1024]={0};
        u16 len2014=sizeof(NODE_ECHO_QUERY_TIME_SLICE_INFO);
        memcpy(tmp2014,(u8*)&cmd2014,len2014);
        unsigned short int s_cmd=0x2014;
        char ucEncrypt_type=1;
        memset(cmdsend,0,1024);

        int length=l_ID.size();
        int serialnum=atoi(MyRand(4).c_str());
        cmdsend[0] = length & 0xFF;
        cmdsend[1] = length >> 8;

        cmdsend[2] = s_cmd & 0xFF;
        cmdsend[3] = s_cmd >> 8;

        cmdsend[4] = serialnum & 0xFF;
        cmdsend[5] = (serialnum >> 8) & 0xFF;
        cmdsend[6] = (serialnum >> 16) & 0xFF;
        cmdsend[7] = (serialnum >> 24) & 0xFF;

        length=length+8;
        cmdlength=length;
        memcpy(cmdsend+8,l_ID.c_str(),l_ID.size());

        char ret= NetEncodePacket(node_id,(u32 *) key,cmdsend,&cmdlength,ucEncrypt_type);
        if (ret == HUOHE_FAIL)
        {
            LOG(INFO) << GW_LOG << "[" << _gw_cmd << "] 指令 加密失败";
            return -1;
        }

    } else if(cmd == "0x3005")
    {
        LOG(INFO)<<GW_LOG<< " [ "<<cmd<< " ] "<<" 服务器设置网关的工作信道 0x2005 ";
        NODE_ECHO_SET_NODE_WORK_CHANNEL_INFO cmd2005;
        cmd2005.status=0;
        u8 tmp2005[1024]={0};
        u16 len2005=sizeof(NODE_ECHO_SET_NODE_WORK_CHANNEL_INFO);
        memcpy(tmp2005,(u8*)&cmd2005,len2005);
        unsigned short int s_cmd=0x2005;
        char ucEncrypt_type=1;
        memset(cmdsend,0,1024);

        int length=l_ID.size();
        int serialnum=atoi(MyRand(4).c_str());
        cmdsend[0] = length & 0xFF;
        cmdsend[1] = length >> 8;

        cmdsend[2] = s_cmd & 0xFF;
        cmdsend[3] = s_cmd >> 8;

        cmdsend[4] = serialnum & 0xFF;
        cmdsend[5] = (serialnum >> 8) & 0xFF;
        cmdsend[6] = (serialnum >> 16) & 0xFF;
        cmdsend[7] = (serialnum >> 24) & 0xFF;

        length=length+8;
        cmdlength=length;
        memcpy(cmdsend+8,l_ID.c_str(),l_ID.size());

        char ret= NetEncodePacket(node_id,(u32 *) key,cmdsend,&cmdlength,ucEncrypt_type);
        if (ret == HUOHE_FAIL)
        {
            LOG(INFO) << GW_LOG << "[" << _gw_cmd << "] 指令 加密失败";
            return -1;
        }

    }
    else if(cmd == "0x3015")
    {
        LOG(INFO)<<GW_LOG<< " [ "<<cmd<< " ] "<<"查询网关工作频点值 0x2015";
        NODE_ECHO_QUERY_NODE_WORK_CHANNEL_INFO cmd2015;
        cmd2015.status=0;
        cmd2015.work_channel=0xEF;


        u8 tmp2015[1024]={0};
        u16 len2015=sizeof(NODE_ECHO_QUERY_NODE_WORK_CHANNEL_INFO);
        memcpy(tmp2015,(u8*)&cmd2015,len2015);
        unsigned short int s_cmd=0x2015;
        char ucEncrypt_type=1;
        memset(cmdsend,0,1024);

        int length=l_ID.size();
        int serialnum=atoi(MyRand(4).c_str());
        cmdsend[0] = length & 0xFF;
        cmdsend[1] = length >> 8;

        cmdsend[2] = s_cmd & 0xFF;
        cmdsend[3] = s_cmd >> 8;

        cmdsend[4] = serialnum & 0xFF;
        cmdsend[5] = (serialnum >> 8) & 0xFF;
        cmdsend[6] = (serialnum >> 16) & 0xFF;
        cmdsend[7] = (serialnum >> 24) & 0xFF;

        length=length+8;
        cmdlength=length;
        memcpy(cmdsend+8,l_ID.c_str(),l_ID.size());

        char ret= NetEncodePacket(node_id,(u32 *) key,cmdsend,&cmdlength,ucEncrypt_type);
        if (ret == HUOHE_FAIL)
        {
            LOG(INFO) << GW_LOG << "[" << _gw_cmd << "] 指令 加密失败";
            return -1;
        }

    }
    else if( cmd == "0x3006")
    {
        LOG(INFO)<<GW_LOG<< " [ "<<cmd<< " ] "<<"设置网关访问服务器地址 0x2006";
        NODE_ECHO_SET_SERVER_ADDRESS_INFO cmd2006;
        cmd2006.status=0;

        u8 tmp2006[1024]={0};
        u16 len2006=sizeof(NODE_ECHO_SET_SERVER_ADDRESS_INFO);
        memcpy(tmp2006,(u8*)&cmd2006,len2006);
        unsigned short int s_cmd=0x2006;
        char ucEncrypt_type=1;
        memset(cmdsend,0,1024);

        int length=l_ID.size();
        int serialnum=atoi(MyRand(4).c_str());
        cmdsend[0] = length & 0xFF;
        cmdsend[1] = length >> 8;

        cmdsend[2] = s_cmd & 0xFF;
        cmdsend[3] = s_cmd >> 8;

        cmdsend[4] = serialnum & 0xFF;
        cmdsend[5] = (serialnum >> 8) & 0xFF;
        cmdsend[6] = (serialnum >> 16) & 0xFF;
        cmdsend[7] = (serialnum >> 24) & 0xFF;

        length=length+8;
        cmdlength=length;
        memcpy(cmdsend+8,l_ID.c_str(),l_ID.size());

        char ret= NetEncodePacket(node_id,(u32 *) key,cmdsend,&cmdlength,ucEncrypt_type);
        if (ret == HUOHE_FAIL)
        {
            LOG(INFO) << GW_LOG << "[" << _gw_cmd << "] 指令 加密失败";
            return -1;
        }
    }else if (cmd == "0x3016")
    {
        LOG(INFO)<<GW_LOG<< " [ "<<cmd<< " ] "<<"查询网关访问的服务器地址 0x2016";
        NODE_ECHO_QUERY_SERVER_ADDRESS_INFO cmd2016;
        cmd2016.status=0;

        u8 tmp2016[1024]={0};
        u16 len2016=sizeof(NODE_ECHO_SET_SERVER_ADDRESS_INFO);
        memcpy(tmp2016,(u8*)&cmd2016,len2016);
        unsigned short int s_cmd=0x2016;
        char ucEncrypt_type=1;
        memset(cmdsend,0,1024);

        int length=l_ID.size();
        int serialnum=atoi(MyRand(4).c_str());
        cmdsend[0] = length & 0xFF;
        cmdsend[1] = length >> 8;

        cmdsend[2] = s_cmd & 0xFF;
        cmdsend[3] = s_cmd >> 8;

        cmdsend[4] = serialnum & 0xFF;
        cmdsend[5] = (serialnum >> 8) & 0xFF;
        cmdsend[6] = (serialnum >> 16) & 0xFF;
        cmdsend[7] = (serialnum >> 24) & 0xFF;

        length=length+8;
        cmdlength=length;
        memcpy(cmdsend+8,l_ID.c_str(),l_ID.size());

        char ret= NetEncodePacket(node_id,(u32 *) key,cmdsend,&cmdlength,ucEncrypt_type);
        if (ret == HUOHE_FAIL)
        {
            LOG(INFO) << GW_LOG << "[" << _gw_cmd << "] 指令 加密失败";
            return -1;
        }
    } else if(cmd == "0x3008")
    {
        LOG(INFO)<<GW_LOG<< " [ "<<cmd<< " ] "<<"服务器下发网关重置门锁复位";
        NODE_ECHO_SYS_RST_LOCK_INFO cmd2008;
        cmd2008.status=0;

        u8 tmp2008[1024]={0};
        u16 len2008=sizeof(NODE_ECHO_SET_SERVER_ADDRESS_INFO);
        memcpy(tmp2008,(u8*)&cmd2008,len2008);
        unsigned short int s_cmd=0x2008;
        char ucEncrypt_type=1;
        memset(cmdsend,0,1024);

        int length=l_ID.size();
        int serialnum=atoi(MyRand(4).c_str());
        cmdsend[0] = length & 0xFF;
        cmdsend[1] = length >> 8;

        cmdsend[2] = s_cmd & 0xFF;
        cmdsend[3] = s_cmd >> 8;

        cmdsend[4] = serialnum & 0xFF;
        cmdsend[5] = (serialnum >> 8) & 0xFF;
        cmdsend[6] = (serialnum >> 16) & 0xFF;
        cmdsend[7] = (serialnum >> 24) & 0xFF;

        length=length+8;
        cmdlength=length;
        memcpy(cmdsend+8,l_ID.c_str(),l_ID.size());

        char ret= NetEncodePacket(node_id,(u32 *) key,cmdsend,&cmdlength,ucEncrypt_type);
        if (ret == HUOHE_FAIL)
        {
            LOG(INFO) << GW_LOG << "[" << _gw_cmd << "] 指令 加密失败";
            return -1;
        }

    }
    else if(cmd == "0x3007")
    {
        NODE_ECHO_DEL_LOCK_PWD_INFO cmd2007;
        cmd2007.status=0;
        u8 tmp2009[1024]={0};
        u16 len2009=sizeof(NODE_ECHO_DEL_LOCK_PWD_INFO);
        memcpy(tmp2009,(u8*)&cmd2007,len2009);
        unsigned short int s_cmd=0x2007;
        char ucEncrypt_type=1;
        memset(cmdsend,0,1024);

        int length=l_ID.size();
        int serialnum=atoi(MyRand(4).c_str());
        cmdsend[0] = length & 0xFF;
        cmdsend[1] = length >> 8;

        cmdsend[2] = s_cmd & 0xFF;
        cmdsend[3] = s_cmd >> 8;

        cmdsend[4] = serialnum & 0xFF;
        cmdsend[5] = (serialnum >> 8) & 0xFF;
        cmdsend[6] = (serialnum >> 16) & 0xFF;
        cmdsend[7] = (serialnum >> 24) & 0xFF;

        length=length+8;
        cmdlength=length;
        memcpy(cmdsend+8,l_ID.c_str(),l_ID.size());

        char ret= NetEncodePacket(node_id,(u32 *) key,cmdsend,&cmdlength,ucEncrypt_type);
        if (ret == HUOHE_FAIL)
        {
            LOG(INFO) << GW_LOG << "[" << _gw_cmd << "] 指令 加密失败";
            return -1;
        }
    }

    else if(cmd == "0x3009")
    {
        NODE_ECHO_DEVICE_UPDATE_ACK cmd2009;
        cmd2009.status=0;

        u8 tmp2009[1024]={0};
        u16 len2009=sizeof(NODE_ECHO_SET_SERVER_ADDRESS_INFO);
        memcpy(tmp2009,(u8*)&cmd2009,len2009);
        unsigned short int s_cmd=0x2009;
        char ucEncrypt_type=1;
        memset(cmdsend,0,1024);

        int length=l_ID.size();
        int serialnum=atoi(MyRand(4).c_str());
        cmdsend[0] = length & 0xFF;
        cmdsend[1] = length >> 8;

        cmdsend[2] = s_cmd & 0xFF;
        cmdsend[3] = s_cmd >> 8;

        cmdsend[4] = serialnum & 0xFF;
        cmdsend[5] = (serialnum >> 8) & 0xFF;
        cmdsend[6] = (serialnum >> 16) & 0xFF;
        cmdsend[7] = (serialnum >> 24) & 0xFF;

        length=length+8;
        cmdlength=length;
        memcpy(cmdsend+8,l_ID.c_str(),l_ID.size());

        char ret= NetEncodePacket(node_id,(u32 *) key,cmdsend,&cmdlength,ucEncrypt_type);
        if (ret == HUOHE_FAIL)
        {
            LOG(INFO) << GW_LOG << "[" << _gw_cmd << "] 指令 加密失败";
            return -1;
        }
    } else if(cmd == "0x300D") {
        CMD_SVR_QUERY_LOCK_INFO cmd300D;
        NODE_ECHO_QUERY_LOCK_INFO cmd200D;

        //memcpy(&cmd300D,(CMD_SVR_QUERY_LOCK_INFO *)DownQuestCmdData,sizeof(CMD_SVR_QUERY_LOCK_INFO));
        //string mylockid = "254.101.1.1";
        //cmd200D.lock_id=HostIpToNet(mylockid);
        cmd200D.lock_id = cmd300D.lock_id;
        cmd200D.status = 0;
        cmd200D.ack_type = cmd300D.query_type;
        //查询数据

        if (cmd200D.ack_type == 0x00) {
            pwd pwd1;
            pwd1.pwd_type = 0;
            pwd1.pwd_en = 6;
            pwd1.pwd_en = 0;
            pwd1.RFID_pwd = 0;
            //门锁密钥加密
            //加密后的数据
            string lock_encode_data = "passwddata";
            memcpy(pwd1.pwd, lock_encode_data.c_str(), lock_encode_data.size());
            memcpy(cmd200D.ack_data, (char *) &pwd1, sizeof(pwd1));
        } else if (cmd200D.ack_type == 0x01) {
            memcpy(cmd200D.ack_data, "0", 1);
        } else if (cmd200D.ack_type == 0x02) {
            memcpy(cmd200D.ack_data, "0", 1);
        } else if (cmd200D.ack_type == 0x1d) ///0x01~0x1d
        {
            memcpy(cmd200D.ack_data, "30", 2);
        } else if (cmd200D.ack_type == 0x30) {
            memcpy(cmd200D.ack_data, "9.9.9.9", 7);
        } else if (cmd200D.ack_type == 0x31) {
            memcpy(cmd200D.ack_data, "8.8.8.8", 7);
        } else if (cmd200D.ack_type == 0x32) {
            Lock_time l32;
            l32.lock_time = 0x1212;
            l32.ms_time = 0x21;
            memcpy(cmd200D.ack_data, (char *) &l32, sizeof(l32));
        } else if (cmd200D.ack_type == 0x33) {
            Work_Channel work_channel;
            work_channel.channel_data = 0xEF;
            work_channel.start_slice = 0x00;
            work_channel.end_slice = 0xFF;
            memcpy(cmd200D.ack_data, (char *) &work_channel, sizeof(work_channel));
        } else if (cmd200D.ack_type == 0x40)
        {
            Lock_Pwr_Charge lock_pwr_charge;
            lock_pwr_charge.pwr_data=0xa;
            lock_pwr_charge.pwr_cap_time=0x1313;
            memcpy(cmd200D.ack_data, (char *)&lock_pwr_charge,sizeof(lock_pwr_charge));
        }else if (cmd200D.ack_type == 0x41)
        {
            memcpy(cmd200D.ack_data,"1",1);
        }
        else if (cmd200D.ack_type == 0x42)
        {
            memcpy(cmd200D.ack_data,"0",1);
        }
        else if (cmd200D.ack_type == 0x44)
        {
            memcpy(cmd200D.ack_data,"2",1);
        }

        u8 tmp200D[1024]={0};
        u16 len200D=sizeof(NODE_ECHO_QUERY_LOCK_INFO);
        memcpy(tmp200D,(u8*)&cmd200D,len200D);
        unsigned short int s_cmd=0x200D;
        char ucEncrypt_type=1;
        if(int ret =enCodeSendData(tmp200D,len200D,s_cmd,ucEncrypt_type)<0)
        {
            LOG(INFO)<< GW_LOG<<" [ "<<cmd<<  " ]"<<" 瓶装应答数据失败 : ret :"<<ret;
            return ret;
        }

    }
    else if(cmd == "0x300E")
    {
        LOG(INFO)<< GW_LOG<<" [ "<<cmd<<  " ]"<<" 服务器下发网关重启门锁";
        CMD_SVR_RESTART_LOCK_INFO cmd300E;
        NODE_ECHO_RESTART_LOCK_INFO cmd200E;
        memcpy(&cmd300E,(CMD_SVR_RESTART_LOCK_INFO*)DownQuestCmdData,sizeof(CMD_SVR_RESTART_LOCK_INFO));
        cmd200E.lock_id=cmd300E.lock_id;
        cmd200E.status=0;

        u8 tmp200E[1024]={0};
        u16 len200E=sizeof(NODE_ECHO_RESTART_LOCK_INFO);
        memcpy(tmp200E,(u8*)&cmd200E,len200E);
        unsigned short int s_cmd=0x200E;
        char ucEncrypt_type=1;
        if(int ret =enCodeSendData(tmp200E,len200E,s_cmd,ucEncrypt_type)<0)
        {
            LOG(INFO)<< GW_LOG<<" [ "<<cmd<<  " ]"<<" 瓶装应答数据失败 : ret :"<<ret;
            return ret;
        }
    } else if (cmd == "0x3010")
    {
        SVR_OPEN_DOOR_INFO cmd3010;
        NODE_ECHO_OPEN_DOOR_INFO cmd2010;
        memcpy(&cmd3010,(SVR_OPEN_DOOR_INFO *)DownQuestCmdData,sizeof(SVR_OPEN_DOOR_INFO));
        cmd2010.lock_id=cmd3010.lock_id;
        cmd2010.status=0;

        u8 tmp2010[1024]={0};
        u16 len2010=sizeof(NODE_ECHO_OPEN_DOOR_INFO);
        memcpy(tmp2010,(u8*)&cmd2010,len2010);
        unsigned short int s_cmd=0x2010;
        char ucEncrypt_type=1;
        if(int ret =enCodeSendData(tmp2010,len2010,s_cmd,ucEncrypt_type)<0)
        {
            LOG(INFO)<< GW_LOG<<" [ "<<cmd<<  " ]"<<" 瓶装应答数据失败 : ret :"<<ret;
            return ret;
        }
    }else if(cmd == "0x3011")
    {
        NODE_ECHO_DEL_LOCK_ALGORIM_PWD_INFO cmd2011;
        cmd2011.status=0;

        u8 tmp2011[1024]={0};
        u16 len2011=sizeof(NODE_ECHO_DEL_LOCK_ALGORIM_PWD_INFO);
        memcpy(tmp2011,(u8*)&cmd2011,len2011);
        unsigned short int s_cmd=0x2011;
        char ucEncrypt_type=1;
        if(int ret =enCodeSendData(tmp2011,len2011,s_cmd,ucEncrypt_type)<0)
        {
            LOG(INFO)<< GW_LOG<<" [ "<<cmd<<  " ]"<<" 瓶装应答数据失败 : ret :"<<ret;
            return ret;
        }

    }

    else if(cmd == "0x400E")
    {
        LOG(INFO)<<GW_LOG<<" 指令["<<cmd<<"] 服务器应答请求增加门锁";

    }
    else
    {
        LOG(INFO)<< GW_LOG<<" [ "<<cmd<<  " ]"<<"此指令不存在无法应答";
        return -999;
    }

    memset(DownQuestCmdData,0x00,sizeof(DownQuestCmdData));
    return 0;

}

void Gw_Task_Process::write_callback(ev::io &m_io, int revents) {
    /*
     * 获取网关请求数据，数据为按次序进行发送
     */
    hurt_send_off=0;
    lock_data_off=0;
    gwRequestNhapFlag=0;
    memset(ucData,0x00,sizeof(ucData));
    timeout_flag=0;
    int ret;

    LOG(INFO)<<GW_LOG<<"read_flag : "<<read_flag<<"gw_off_sucess : "<<gw_off_sucess<<"gwRequestNhapFlag: "<<gwRequestNhapFlag;
    if (read_flag != 2)
    {
        if (gw_off_sucess == 0)
        {
            getGwTaskData();
        } else if (gw_off_sucess == 1 )
        {
            //正常接入
            getGwTaskData();
        } else if (gw_off_sucess == 2)
        {

            //接入异常重新接入
            LOG(WARNING) << GW_LOG << " [" << _gw_cmd << "] -----------接入异常再次接入-------------------";
            //再次发起接入
            hurt_send_off=2;
            //write_io.stop();
            second_conn();
            return;
        } else if (gw_off_sucess == 3 ) {
            /*
             * 网关配置数据发送完成，并且发送了心跳正常返回gw_off_sucess=3，表示可以执行门锁的操作
             */

            if (gwRequestNhapFlag == 0)
            {


                MYLOCK_NODE_FRAME mylockNodeFrame;
                memset(&mylockNodeFrame, 0x00, sizeof(MYLOCK_NODE_FRAME));


                ret = getTaskQueueData(mylockNodeFrame);
                if (ret < 0)
                {
                    LOG(INFO) << GW_LOG << "无任何数据需要发送，触发读事件开始";
                    //lock_data_off=1;
                    hurt_send_off = 1;

                    /*
                    //心跳定时器
                    hurt_time.stop();
                    hurt_time.set<Gw_Task_Process, &Gw_Task_Process::hurt_callbaclk>(this);
                    hurt_time.start(10, 0);
                    */
                    write_io.stop();
                    read_io.set<Gw_Task_Process, &Gw_Task_Process::read_callbaclk>(this);
                    read_io.start(listenfd, EV_READ);





                    return;
                } else {
                    hurt_time.repeat=10;
                    hurt_send_off=0;
                    LOG(INFO) << GW_LOG << " hantao----转发门锁数据开始";
                    //门锁数据处理
                    ret=-1;
                    ret = ForwardLockMsg(mylockNodeFrame);
                    if (ret < 0) {
                        LOG(INFO) << GW_LOG << "hantao----网关转发门锁信息失败------";
                    }
                    LOG(INFO)<<GW_LOG<<"hantao---------获取上送门锁信息完成-------"<<"lock_data_off : "<<lock_data_off;
                }

            }
        }
    }

    if (lock_data_off !=1)
    {
        char print[4] = {'\0'};
        string s_print = "";
        for (int i = 0; i < cmdlength; ++i) {
            // printf("%02x",cmdsend[i]);
            sprintf(print, "%02x", cmdsend[i]);
            s_print = s_print + print;
        }
        LOG(INFO) << GW_LOG << " 指令 : " << _gw_cmd << " data : " << s_print;


        int s_len1 = -1;
        s_len1 = send(listenfd, cmdsend, cmdlength, MSG_NOSIGNAL);//测试
        if (s_len1 > 0) {
            LOG(INFO) << GW_LOG << " 发送数据成功,长度 ：" << s_len1 << " FD :" << listenfd;
        } else if (s_len1 < 0) {

            LOG(ERROR) << GW_LOG << " 指令 ： " << _gw_cmd << "  fd : "<<listenfd <<" 发送数据失败.... ,errno : " << errno << " errmsg : "
                       << strerror(errno);
            second_conn();
            return;
        }
    }

    LOG(INFO)<<GW_LOG<<" 开始接受数据..........";
    //LOG(INFO)<<GW_LOG<< " RECV DATA start ："<<rcvbuffer << " timeout_flag :"<<timeout_flag;

    read_flag=0;
    write_io.stop();
    read_io.set<Gw_Task_Process, &Gw_Task_Process::read_callbaclk>(this);
    read_io.start(listenfd,EV_READ);


    if(_gw_cmd =="0x1001")
    {

    } else if(_gw_cmd == "0x1002"){

    }
        else if(_gw_cmd=="0x1005")
    {

    } else if(_gw_cmd=="0x1007")
    {

    }
    else if(_gw_cmd=="0x100A")
    {

    }
    else if(_gw_cmd == "0x2000")
    {
        gw_off_sucess =3;
        timeout_nun=3;
    }
    else{
        gwRequestNhapFlag=0;
        if(timeout_nun !=3)
        {
            fdout.set<Gw_Task_Process,&Gw_Task_Process::fdout_callbaclk>(this);
            fdout.start(10,0);

            timeout_flag=1;
        }

    }


    if(gw_off_sucess ==3&&timeout_nun==3)
    {
        hurt_send_off=1;
        /*20200316
        hurt_time.set<Gw_Task_Process,&Gw_Task_Process::hurt_callbaclk>(this);
        hurt_time.start(10,0);
         */
    }

    return;
}

void Gw_Task_Process::fdout_callbaclk(ev::timer &w, int revents)
{
    if (ucData[0]=='\0'&&timeout_flag==1)
    {
        if (timeout_nun == 3)
        {
            LOG(ERROR)<<GW_LOG<<"---------------再次发送数据已达3次,关闭连接，重新发起接入.........................."<<endl;
            //second_conn();
            //return;
        }

        //LOG(ERROR)<<GW_LOG<<"---------------再次发送数据.........................."<<endl;
        read_flag=2;
        hurt_send_off=0;
        timeout_nun++;
        read_io.stop();
        write_io.set<Gw_Task_Process,&Gw_Task_Process::write_callback>(this);
        write_io.start(listenfd,EV_WRITE);
    }
    //fdout.stop();
}


void Gw_Task_Process::nextConn_callbaclk(ev::timer &w, int revents) {

   // LOG(ERROR)<<GW_LOG<<" START WAITING SECOND CONNECT SERVICE ";

    //LOG(INFO) << GW_LOG <<"  开始创建套节 ....";
    int ret=-1;
    con:
    ret = CreateSocket();
    if (ret < 0) {
        LOG(ERROR) << GW_LOG << "创建套节奏失败 ";
        goto con;
    }
    //LOG(INFO)<<GW_LOG<< "创建套接字成功 fd: "<<listenfd;
    ret = Conn();
    if (ret < 0) {
        LOG(ERROR) << GW_LOG <<" 建立链接失败 ";
        goto con;
    }
    //LOG(INFO)<<GW_LOG <<"建立链接成功 fd : "<<listenfd;


    //write_io.stop();
    //read_io.stop();
    ev::io reapio;
   // write_io.set<Gw_Task_Process, &Gw_Task_Process::write_callback>(this);
    //write_io.start(listenfd,EV_WRITE);
    reapio.set<Gw_Task_Process, &Gw_Task_Process::write_callback>(this);
    reapio.start(listenfd,EV_WRITE);
    return;
}

void Gw_Task_Process::read_callbaclk(ev::io &m_io, int revents)
{

    int ret=-1;
    hurt_send_off=0;
    timeout_flag=0;
    timeout_nun=0;
    gwRequestNhapFlag=0;
    memset(ucData,0x00,MAXLEN);

    //hurt_time.stop();20200316

    fdout.stop();

    //LOG(INFO )<<GW_LOG<<" start recv --------- fd :"<<listenfd;

    loop1:
    //LOG(INFO)<<GW_LOG <<"  开始接收数据 fd :"<< listenfd;
    ret=recv(listenfd,ucData,MAXLEN,0);
    if(ret > 0)
    {
        read_flag=1;
        //测试打印数据

        char print[2]={'\0'};
        string s_print="";
        for (int i = 0; i < ret; ++i) {
            sprintf(print,"%02x",ucData[i]);
            s_print=s_print+print;
        }
        LOG(INFO)<<GW_LOG<< "fd : "<<listenfd <<" ret :"<<ret <<" recv data : "<<s_print;

       // LOG(INFO)<<GW_LOG<<" ----------------------recv message :"<<buffer <<"ret :" << ret<<" rcv :"<<listenfd;
    }
    else if(ret ==0)
    {
        read_flag=2;
        LOG(ERROR)<<GW_LOG<< " 指令 : " << _gw_cmd <<" 接受数据失败 errno:["<<errno<<"]"<<" errMsg: "<< strerror(errno) <<" fd :"<<listenfd;
        second_conn();
        return;
    }
    else
    {
        if(errno == EINTR || errno == EWOULDBLOCK || errno == EAGAIN)
        {
            read_flag=2;
            LOG(ERROR)<<GW_LOG<< " 指令 : " << _gw_cmd <<"继续接收..........";
            goto loop1;
        }
        else
        {

            LOG(ERROR)<<GW_LOG<<" 指令 : " << _gw_cmd <<" 接受数据失败ret : ["<< ret <<"] errno:["<<errno<<"]" << " errmsg : " << strerror(errno)<< "fd :"<<listenfd;

            second_conn();
            //read_flag=2;
            return;

        }
    }



    /*
     * 解密
     */

    if (read_flag ==1)
    {
        //LOG(INFO)<< GW_LOG <<" 解包数据开始............................";
        //u8 NetDecodePacket(u32 node_id, u32 *keyword, u8 *ucData, u16 *ucData_len);
        ucDataLen=ret;
        if(ParseRcvMsg()<0)
        {

            char print[2]={'\0'};
            string s_print="";
            for (int i = 0; i < ucDataLen; ++i) {
                sprintf(print,"%02x",ucData[i]);
                s_print=s_print+print;
            }
            LOG(ERROR)<<GW_LOG<< "fd : "<<listenfd <<" ret :"<<ret <<" recv decond data : "<<s_print;
            LOG(ERROR)<<GW_LOG<<"应答数据或者状态异常，根据上一条错误信息判断";
        }
        read_io.stop();
        write_io.set<Gw_Task_Process, &Gw_Task_Process::write_callback>(this);
        write_io.start(listenfd,EV_WRITE);

    } else if (read_flag == 2)
    {
        LOG(INFO)<< GW_LOG <<" 超时 或者 未读到数据,继续发送心跳包...";
        read_io.stop();
        write_io.set<Gw_Task_Process, &Gw_Task_Process::write_callback>(this);
        write_io.start(listenfd,EV_WRITE);
    }
    //timeout_flag=1;
    //hurt_send_off=1;
    return;
}


void Gw_Task_Process::hurt_callbaclk(ev::timer &w, int revents)
{
        if(gw_off_sucess == 3&&hurt_send_off == 1)
        //if(gw_off_sucess == 3)
        {
        LOG(INFO )<<GW_LOG<<"----------------网关心跳 开始 10S------------------";
        SvrHurt();
        /*
        char print[4] = {0};
        string s_print = "";
        for (int i = 0; i < cmdlength; ++i) {
            // printf("%02x",cmdsend[i]);
            sprintf(print, "%02x", cmdsend[i]);
            s_print = s_print + print;
        }
        LOG(INFO) << GW_LOG << " 指令 : " << _gw_cmd << " data : " << s_print;
        */

        //write_io.stop();
        //read_io.stop();
        read_flag=2;

        write_io.set<Gw_Task_Process,&Gw_Task_Process::hwrite_callback>(this);
        write_io.start(listenfd,EV_WRITE);

/*
            write_io.set<Gw_Task_Process,&Gw_Task_Process::write_callback>(this);
            write_io.start(listenfd,EV_WRITE);
      */

    } else if (hurt_send_off == 2)
    {
        LOG(INFO )<<GW_LOG<<"----------------网关心跳 hurt_send_off 开始 10S------------------";

        // hurt_time.stop();
    }
    //hurt_time.stop();
    return;
}

void Gw_Task_Process::hwrite_callback(ev::io &m_io, int revents)
{
    int s_len1 = -1;
    s_len1 = send(listenfd, cmdsend, cmdlength, MSG_NOSIGNAL);//测试
    if (s_len1 > 0) {
        LOG(INFO) << GW_LOG << " 发送数据成功,长度 ：" << s_len1 << " FD :" << listenfd;
    } else if (s_len1 < 0) {

        //timeout_flag = 2;
        LOG(ERROR) << GW_LOG << " hantao 心跳 指令 ： " << _gw_cmd <<" FD" <<listenfd <<" 发送数据失败.... ,errno : " << errno << " errmsg : "
                   << strerror(errno);
        second_conn();
        return;
    }

    write_io.stop();
    read_io.set<Gw_Task_Process,&Gw_Task_Process::read_callbaclk>(this);
    read_io.start(listenfd,EV_READ);


    if (_gw_cmd!="0x1001")
    {
        fdout.set<Gw_Task_Process,&Gw_Task_Process::fdout_callbaclk>(this);
        fdout.start(10,0);
        timeout_flag=1;
    }
}

int Gw_Task_Process::setGwTaskData(queue<DATA> &gwdata)
{
    if (gwdata.empty()){
        LOG(ERROR)<<GW_LOG<<"hantao 创建网关时发现网关数据错误，数据不存在";
        return -1;
    }
    *gwData=gwdata;
    /*
    queue<DATA> *q=new  queue<DATA>;
    *q=gwdata;
    gwdata=*q;

    delete(q);
     */
    return 0;
}

void Gw_Task_Process::gw_callback(ev::timer &w, int revents)
{

    if(gwData->empty())
    {
       // LOG(INFO)<<GW_LOG<<"无任何数据或者操作已经执行完成 ";
        //_timer.stop();
        return;
    } else
    {


        DATA AC=gwData->front();
        string mycmd=AC.action;
        string cmdMsg=AC.data;
        _timeInterval=atoi(AC.timeInterval.c_str());


        if (mycmd == "gwoff")
        {


                setLinkFirst();//是否第一次接入服务器
                if (getSendData(cmdMsg) <0)
                {
                    LOG(ERROR)<<GW_LOG<<"hantao 接入服务器指令数据解析失败, 终止接入";
                    return ;
                } else
                {
                    LOG(INFO) << GW_LOG <<"  开始创建套节 ....";
                    int ret;
                    con:
                    ret = CreateSocket();
                    if (ret < 0) {
                        LOG(ERROR) << GW_LOG << "创建套节奏失败 ";
                        sleep(3);
                        goto con;
                    }
                    LOG(INFO)<<GW_LOG<< "创建套接字成功 fd: "<<listenfd;
                    ret = Conn();
                    if (ret < 0) {
                        LOG(ERROR) << GW_LOG <<" 建立链接失败 ";
                        //close(listenfd);
                        sleep(5);
                        goto con;
                    }
                    LOG(INFO)<<GW_LOG <<" ip :"<< n_hap_Ip<<"port : "<<n_hap_Port<<"建立链接成功 fd : "<<listenfd;

                    write_io.set<Gw_Task_Process, &Gw_Task_Process::write_callback>(this);
                    write_io.start(listenfd,EV_WRITE);

                    correntTimer.set<Gw_Task_Process,&Gw_Task_Process::correntTime_callback>(this);
                    correntTimer.start(10,60);

                    hurt_time.set<Gw_Task_Process,&Gw_Task_Process::hurt_callbaclk>(this);
                    hurt_time.start(9,10);
                }

        } else if (mycmd == "GWON")
        {
             //   LOG(INFO) << GW_LOG << " 操作 [" << mycmd << "] 开始执行";
        } else
        {
                LOG(INFO) << GW_LOG <<" 操作未实现，请完善代码.........!!!!!!";

        }
        gwData->pop();
       // _timer.stop();

         //_timer.repeat = _timeInterval;
        //_timer.stop();
        _timer.set<Gw_Task_Process, &Gw_Task_Process::gw_callback>(this);
        _timer.start();


    }

}

void Gw_Task_Process::second_clear() {

    close(listenfd);
    read_io.stop();
    write_io.stop();
    fdout.stop();
    //hurt_time.stop();
    //_timer.stop();
    //next_timer.stop();

    listenfd=-1;
    memset(&gw_private_key,0x00,sizeof(gw_private_key));
    memset(&gw_public_key,0x00,sizeof(gw_public_key));
    memset(&old_gw_private_key,0x00,sizeof(old_gw_private_key));
    memset(&old_gw_public_key,0x00,sizeof(old_gw_public_key));
    memset(&old_key,0x00,sizeof(old_key));
    memset(&cmdsend,0x00,sizeof(cmdsend));
    memset(&key,0x00,sizeof(key));
    memset(&gw_keyword,0x00,sizeof(gw_keyword));
    memset(&svr_public_key,0x00,sizeof(svr_public_key));
    memset(&DownQuestCmdData,0x00,sizeof(DownQuestCmdData));
    memset(&cmd4002,0x00,sizeof(cmd4002));
    memset(&ucData,0x00,sizeof(ucData));
    ucDataLen=0;

    //hurt_send_off=2;
    hurt_send_off=0;
    if(!_gw_data.empty())
        _gw_data.clear();
    _gw_data = _gw_data_repeat;


    read_flag=0;
    //gw_off_sucess=1;
    gw_off_sucess=0;
    listenfd=0;
   // timeout_flag=3;
     timeout_flag=0;

    timeout_nun=0;
    gwRequestNhapFlag=0;

}

void Gw_Task_Process::second_conn() {

    second_clear();
    int ret=-1;
    con:
    ret = CreateSocket();
    if (ret < 0) {
        LOG(ERROR) << GW_LOG << "创建套节奏失败 ";
        goto con;
    }
    //LOG(INFO)<<GW_LOG<< "创建套接字成功 fd: "<<listenfd;
    ret = Conn();
    if (ret < 0) {
        LOG(ERROR) << GW_LOG <<" 建立链接失败 ";
        goto con;
    }
    LOG(INFO)<<GW_LOG <<"重新建立链接成功 fd : "<<listenfd;

    write_io.set<Gw_Task_Process, &Gw_Task_Process::write_callback>(this);
    write_io.start(listenfd,EV_WRITE);
    return;

}

int Gw_Task_Process::Gw_Task_Process_start()
{
    string path = getdir()+"DB/gwDatabase.db";


    int rc = sqlite3_open(path.c_str(),&db);
    if(rc < 0)
    {
        LOG(ERROR)<<" 创建gwDatabase.db数据库失败!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!1";
        return -1;
    }
    else
    {
        LOG(INFO)<<"打开gwDatabase.db数据库成功";
    }

    switch (sListModule){
        case 0:
            _timer.set<Gw_Task_Process,&Gw_Task_Process::gw_callback>(this);
            _timer.start();
            break;
        case 1:
            LOG(INFO)<<GW_LOG<<"模拟测试serverlist开始";
            getSerListConfig();
            sListStart();
            break;
        case 2:
            LOG(INFO)<<GW_LOG<<"模拟测试serverlist+网关开始";
            getSerListConfig();
            sListStart();
            _timer.set<Gw_Task_Process,&Gw_Task_Process::gw_callback>(this);
            _timer.start(0,0);
            break;
        case 3:
            LOG(INFO)<<GW_LOG<<"模拟测试serverlist+网关+门锁开始";
            getSerListConfig();
            sListStart();
            _timer.set<Gw_Task_Process,&Gw_Task_Process::gw_callback>(this);
            _timer.start(0,0);
            lockStartTimer.set<Gw_Task_Process,&Gw_Task_Process::lockStartCallBack>(this);
            lockStartTimer.start(2,1);
            break;
        case 4:
            LOG(INFO)<<GW_LOG<<"模拟测试网关+门锁开始->>>>>>>>>>>>>>>>>>";
            _timer.set<Gw_Task_Process,&Gw_Task_Process::gw_callback>(this);
            _timer.start(0,0);
            lockStartTimer.set<Gw_Task_Process,&Gw_Task_Process::lockStartCallBack>(this);
            lockStartTimer.start(2,1);
            break;
        default:
            break;
    }

    return 0;
}

void Gw_Task_Process::getSerListConfig()
{

    string confdir = getdir()+"etc/config/GJ_config.ini";
    string tmpPort = getConfig(confdir, string("TEST_SERVERLIST_PORT"));
    ServerListPort = atoi(tmpPort.c_str());
    n_hap_Port=ServerListPort;
    ServerListIp = getConfig(confdir, string("TEST_SERVERLSIT_IP"));
    n_hap_Ip=ServerListIp;

    ServerListEdition=getConfig(confdir,string("TEST_SERVERLIST_EDITION"));

}

void Gw_Task_Process::sListLoopTimer(ev::timer &w, int revents) {
    if (sListPackge()<0)
    {
        LOG(ERROR)<<GW_LOG<<"获取发送数据失败 errno==4444";
        return;
    }

    startTime=getCurrentTime();
    if (CreateSocket() < 0) {
        LOG(ERROR) << "IP[" << n_hap_Ip << " ] " << "PORT[ " << n_hap_Port << " ] 创建soacket套接字失败 errno==1111";
        return;
    }
    if (Conn() < 0) {
        LOG(ERROR) << "IP[" << n_hap_Ip << " ] " << "PORT[ " << n_hap_Port << " ] 连接服务器失败 errno==2222";
        return;
    }

    sListW.set<Gw_Task_Process,&Gw_Task_Process::sListW_callback>(this);
    sListW.start(listenfd,EV_WRITE);

}
void Gw_Task_Process::sListW_callback(ev::io &m_io, int revents)
{

//    LOG(INFO)<<GW_LOG<<"start send msg :";

    int ret = send(listenfd,cmdsend,cmdlength,MSG_NOSIGNAL);
    if (ret < 0)
    {
        LOG(ERROR)<<GW_LOG<<"发送数据失败,errno==5555,ret: "<<ret<<"strerrno: "<< errno<<"errmsg: "<<strerror(errno);
        string tmpMsg="发送数据失败: ";
        //char err[16]={'\0'};
        //sprintf(err,"errno: %s",errno);
        //tmpMsg+=err;
        tmpMsg+=strerror(errno);
        sListLoopConn(1,tmpMsg);
        return;
    }
    /*
    char print[4] = {'\0'};
    string s_print = "";
    for (int i = 0; i < cmdlength; ++i) {
        // printf("%02x",cmdsend[i]);
        sprintf(print, "%02x", cmdsend[i]);
        s_print = s_print + print;
    }
    LOG(INFO) << GW_LOG << "ret :"<<ret<<" send serverlist data : " << s_print;
    */

    sListW.stop();
    sListR.set<Gw_Task_Process,&Gw_Task_Process::sListR_callback>(this);
    sListR.start(listenfd,EV_READ);

    //sListO.set<Gw_Task_Process,&Gw_Task_Process::sListO_callback>(this);
   // sListO.start(10,0);
    return;

}
void Gw_Task_Process::sListR_callback(ev::io &m_io, int revents)
{
    RECV:
    int ret = recv(listenfd,ucData,MAXLEN,MSG_NOSIGNAL);
    if(ret ==0)
    {
        LOG(INFO)<<GW_LOG<<"接收噢数据失败,ret : "<< ret <<"errno: "<<errno<<"errMsg: "<<strerror(errno);
        string tmpMsg="接受数据失败: ";
       // char err[16]={'\0'};
       // sprintf(err,"errno: %s",errno);
        //tmpMsg+=err;
        tmpMsg+=strerror(errno);
        sListLoopConn(1,tmpMsg);
        return;
    } else if(ret <0)
    {
        if(errno == EINTR || errno == EWOULDBLOCK || errno == EAGAIN)
        {

            goto RECV;
        } else{
            LOG(ERROR)<<GW_LOG<<"接受serverlsit数据失败 ,errno: "<<errno<<strerror(errno);
            string tmpMsg="接受数据失败: ";
           // char err[16]={'\0'};
           // sprintf(err,"errno: %s",errno);
           //` tmpMsg+=err;
            tmpMsg+=strerror(errno);
            sListLoopConn(1,tmpMsg);
            return;
        }
    }

    /*
    char print[4] = {'\0'};
    string s_print = "";
    for (int i = 0; i < ret; ++i) {
        // printf("%02x",cmdsend[i]);
        sprintf(print, "%02x", ucData[i]);
        s_print = s_print + print;
    }
    LOG(INFO) << GW_LOG << " recv serverlist data : " << s_print;
    */
    //endTime=getCurrentTime()-startTime;
    //LOG(INFO)<<GW_LOG<<"接送数据成功,start-end :"<<endTime/1000;
    ucDataLen=ret;
    if(sListParsePackge()<0)
    {
        LOG(ERROR)<<GW_LOG<<"解析serverlist 应答数据失败";
    }
}

void Gw_Task_Process::sListO_callback(ev::timer &w, int revents)
{
    sListLoopConn(1,"");
}
int Gw_Task_Process::sListPackge()
{


        NODE_QUERY_SERVER_LIST_INFO cmdSevrList;
        memset(&cmdSevrList,0,sizeof(NODE_QUERY_SERVER_LIST_INFO));

        memset(ucData,0x00,sizeof(ucData));
        memset(cmdsend,0x00,sizeof(cmdsend));
        cmdlength=0;
       cmdSevrList.list_num=0x00; //strtol("0",NULL,16);

        //默认链接的服务器列表，在此处无用

        unsigned short int s_cmd;
        if(ServerListEdition == "V1.0")
           s_cmd =0x1017;
        else
            s_cmd=0x101b;
        char ucEncrypt_type=0;

        unsigned short int s_len=1;

        /*
        char tmp[2]={'\0'};
        sprintf(tmp,"%02x",cmdSevrList.list_num);
        LOG(INFO)<<" FUC : "<<tmp;
         */
        if(enCodeSendData((unsigned char *)&cmdSevrList,s_len,s_cmd,ucEncrypt_type)<0)
        {
            LOG(INFO)<<GW_LOG<<"["<<_gw_cmd<<"] 组装发送serverlsit请求数据失败 errno==3333";
            return -1;
        }

    /*
    char print[2]={'\0'};
    string s_print="";
    for (int i = 0; i < cmdlength; ++i) {
        sprintf(print,"%02x",cmdsend[i]);
        s_print=s_print+print;
    }
    LOG(INFO)<<GW_LOG<< "fd : "<<listenfd <<" ret :"<<cmdlength <<"  data : "<<s_print;
    */
}
int Gw_Task_Process::sListParsePackge()
{
    // 数据解密

    string cmd;
    u32 keyword;

    /*
    char print[2]={'\0'};
    string s_print="";
    for (int i = 0; i < ucDataLen; ++i) {
        sprintf(print,"%02x",ucData[i]);
        s_print=s_print+print;
    }
    LOG(INFO)<<GW_LOG<< "fd : "<<listenfd <<" ret :"<<ucDataLen <<"  data : "<<s_print;


    char print1[2]={'\0'};
    string s_print1="";
    for (int i = 0; i < 16; ++i) {
        sprintf(print1,"%02x",key[i]);
        s_print1=s_print1+print1;
    }
    LOG(INFO)<<GW_LOG<< "fd : "<<listenfd <<"  key : "<<s_print1;
    */



    u8 ret = NetDecodePacket(node_id,(u32*)key,ucData,&ucDataLen);
    if (ret == HUOHE_SUCCEED){
        LOG(INFO)<< GW_LOG <<"解密服务器数据解包成功....... ";
    } else{
        LOG(ERROR)<< GW_LOG <<" 解密服务器数据解包失败........";
        string tmpMsg="解密服务器数据解包失败: "+ret;
        sListLoopConn(1,tmpMsg);
        return -1;
    }

    NODE2SVR_FRAME_STRUCT *rcvMsg1 = (NODE2SVR_FRAME_STRUCT *)ucData;
    cmd="0x" + DecIntToHexStr(rcvMsg1->cmd_data);

    SVR_ECHO_QUERY_SERVER_LIST_INFO cmd4017;
    memset(&cmd4017,0x00,sizeof(SVR_ECHO_QUERY_SERVER_LIST_INFO));
    memcpy(&cmd4017,rcvMsg1->data,sizeof(SVR_ECHO_QUERY_SERVER_LIST_INFO));

    char tmp[2]={'\0'};
    sprintf(tmp,"%02x",cmd4017.list_num);
    int list_num=strtol(tmp,NULL,16);
//    LOG(INFO)<<GW_LOG<<"serverlist 应答状态 status ["<<cmd4017.status<<"] "<<"数量 :"<<list_num;

    char addr_list[1024];
    memset(addr_list,0x00,sizeof(addr_list));
    memcpy(addr_list,rcvMsg1->data+5,rcvMsg1->data_len-5);
    if(cmd4017.status!=0)
    {

        string tmpMsg="[接受数据状态不等0]";
        tmpMsg+=addr_list;
        sListLoopConn(1,tmpMsg);
        return -1;
    }
    sListLoopConn(0,addr_list);


    int tmplen=0;
    for (int j = 0; j < list_num; ++j) {
        char tmp[2]={'\0'};
        sprintf(tmp,"%02x",addr_list[tmplen]);
        int addr_len=strtol(tmp,NULL,16);
//        LOG(INFO)<<"V2.0版本 :  "<<addr_len;
        char addr[32]={'\0'};
        memcpy(addr,addr_list+1+tmplen,addr_len);
        tmplen+=addr_len+1;
        queue<string>q;
        q=split_1(addr,":");
        if(cmd=="0x4017"&&ServerListEdition=="V1.0")
        {
            LOG(INFO)<<GW_LOG<<"V1.0版本(0-serverlistIp,1-IDSIp,2-nhapIp,3or4-保留) serverlist[ "<<j<<" ] 应答的服务端ip:port ["<<addr<<" ]";
        } else
        {
            LOG(INFO)<<GW_LOG<<"V2.0版本(0-serverlistIp,1-IDSIp,2-nhapIp,3or4-保留) serverlist[ "<<j<<" ] 应答的服务端ip:port ["<<addr<<" ]";
            if(j==0)
            {
                rcvServerlistIp=q.front();
                q.pop();
                rcvServerlistPort=atoi(q.front().c_str());
            }
            else if(j==1)
            {
                rcvIdsIp=q.front();
                q.pop();
                rcvIdsPort=atoi(q.front().c_str());
            } else if(j==2)
            {
                rcvNhapIp=q.front();
                q.pop();
               rcvNhapPort =atoi(q.front().c_str());
            }
        }

    }

    return 0;
}

void Gw_Task_Process::sListLoopConn(int flag,string msg)
{
    sListMsgLog(flag,msg);
    close(listenfd);
    sListR.stop();
    memset(ucData,0x00,sizeof(ucData));
    memset(cmdsend,0x00,sizeof(cmdsend));
    cmdlength=0;
    sListTime.set<Gw_Task_Process,&Gw_Task_Process::sListLoopTimer>(this);
    sListTime.start(0,0);
}

void Gw_Task_Process::sListStart() {
    memset(ucData,0x00,sizeof(ucData));
    memset(cmdsend,0x00,sizeof(cmdsend));
    cmdlength=0;
    sListTime.set<Gw_Task_Process,&Gw_Task_Process::sListLoopTimer>(this);
    sListTime.start(0,0);
}
void Gw_Task_Process::sListMsgLog(int flag, string msg)
{
    ++sListRunCount;
    endTime=getCurrentTime()-startTime;
    if(flag == 0)
    {
        LOG(INFO)<<GW_LOG<<"版本: "<<ServerListEdition<<" 处理耗费时间为,start-end :"<<endTime/1000<<" 执行次数："<<sListRunCount<<" rcv_sucess Msg: "<<msg;
    } else{
        LOG(ERROR)<<GW_LOG<<"版本: "<<ServerListEdition<<" 处理耗费时间为,start-end :"<<endTime/1000<<" 执行次数："<<sListRunCount<<" rcv_fialed Msg: "<<msg;
    }
}

void Gw_Task_Process::lockStartCallBack(ev::timer &w, int revents)
{
    if (lockDv.empty())
    {
        LOG(INFO)<<GW_LOG<<" 网关下无门锁!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!";
        lockStartTimer.stop();
        return;
    }
    if (gw_off_sucess == 3)
    {

        map<string,string>::iterator lockDiv=lockDv.begin();
        LOG(INFO) <<" 设备下的门锁类别种类: "<<lockDv.size();

        for (;lockDiv!=lockDv.end();++lockDiv)
        {
            string lockDivName=lockDiv->first;
            int dvCount=atoi(lockDiv->second.c_str());
            setLockFilePaht(l_file,lockDivName);
            getLockDvAction();
            if(LOCK_DATA.empty())
            {
                LOG(ERROR)<<GW_LOG<<"网关需要的门锁数据不存在";
                continue;
            }
            createLock(dvCount);

        }

        lockStartTimer.stop();
    }
}

void Gw_Task_Process::createLock(int &dvCount)
{

    Lock_Task_Process *lockTaskProcess[dvCount];
    for (int i = 0; i < dvCount; ++i)
    {
        lockTaskProcess[i] =new Lock_Task_Process;
        string id1=id[idCount++];
        u32  tmp= HostIpToNet(id1);
        u16 tmp1=tmp;
        LOG(INFO)<<GW_LOG<<" LOCK 16 ID ： "<<tmp1;
        LOG(INFO)<<GW_LOG<<" LOCK 32 ID ： "<<tmp;

        u32ID.insert(pair<u16 ,u32 >(tmp1,tmp));
        LOG(INFO)<<GW_LOG<< " lock id : "<<id1;

        lockTaskProcess[i]->setGwLockId(id1,_gw_id);
        lockTaskProcess[i]->setLockData(LOCK_DATA);
        lockTaskProcess[i]->setQueueData(&taskData,&taskWriteData);
        lockTaskProcess[i]->Lock_Task_Porcess_start();


    }
}
void Gw_Task_Process::setLockDvData(map<string, string> &lockDv,string &l_file,vector<string>&id)
{
    this->lockDv=lockDv;
    this->l_file=l_file;
    this->id=id;
}

int Gw_Task_Process::getTaskQueueData(MYLOCK_NODE_FRAME &mylockNodeFram) {
//    LOG(INFO)<<GW_LOG<<"--------------------------POP : "<<taskData.size();

    if (taskData.empty())
        return -1;
    if(gw_off_sucess ==3)
    {
        //hurt_time.stop();
        mylockNodeFram=taskData.front();
        taskData.pop();
        gwRequestNhapFlag=1;
    } else
        return -1;

    LOG(INFO)<<GW_LOG<<"hantao 获取门锁数据成功.....................";
    return 0;
}
int Gw_Task_Process::ForwardLockMsg(MYLOCK_NODE_FRAME &mylockNodeFram)
{
    if(mylockNodeFram.data_type==0x40)
    {
        _gw_cmd="0x100E";

        LOG(INFO)<<GW_LOG<<"["<<_gw_cmd<<"] 网关请求服务器，门锁加入系统开始";
        NODE_ADD_LOCK_INFO cmd100E;
        Join_Req lockCmd40;

        memset(&cmd100E,0x00,sizeof(NODE_ADD_LOCK_INFO));
        memset(&lockCmd40,0x00,sizeof(Join_Req));


        u8  ret;

        char print[2]={'\0'};
        string s_print="";
        for (int i = 0; i < sizeof(Join_Req); ++i) {
            sprintf(print,"%02x",mylockNodeFram.Data[i]);
            s_print=s_print+print;
        }
        LOG(INFO)<<GW_LOG<< "fd : "<<listenfd <<" sizeof(Join_Req) :"<<sizeof(Join_Req) <<" NetEncodePacket before data : "<<s_print;


        char tmp[2]={'\0'};
        sprintf(tmp,"%02x",mylockNodeFram.data_len);
        int data_len=strtol(tmp,NULL,16);

        memcpy((char *)&lockCmd40,mylockNodeFram.Data,sizeof(Join_Req));

        cmd100E.lock_num=1;


        cmd100E.lock_id=lockCmd40.lock_id;
        LOG(INFO)<<GW_LOG<<"lockCmd40.lock_id :"<<lockCmd40.lock_id;
        cmd100E.joinin_flag=lockCmd40.joinin_flag;
        LOG(INFO)<<GW_LOG<<"lockCmd40.joinin_flag :"<<lockCmd40.joinin_flag;
        cmd100E.hard_ver=lockCmd40.hard_ver;
        LOG(INFO)<<GW_LOG<<"lockCmd40.hard_ver: "<<lockCmd40.hard_ver;
        cmd100E.soft_ver=lockCmd40.soft_ver;
        LOG(INFO)<<GW_LOG<<"lockCmd40.soft_ver: "<<lockCmd40.soft_ver;

        cmd100E.lock_type=lockCmd40.lock_type;
        LOG(INFO)<<GW_LOG<<"lockCmd40.lock_type: "<<lockCmd40.lock_type;

        cmd100E.lock_random_data=lockCmd40.lock_random_data;
        LOG(INFO)<<GW_LOG<<"lockCmd40.lock_random_data ："<<lockCmd40.lock_random_data;
        cmd100E.id_lock_random_data=lockCmd40.id_lock_random_data;
        LOG(INFO)<<GW_LOG<<"lockCmd40.id_lock_random_data :"<<lockCmd40.id_lock_random_data;

        int s_len=sizeof(NODE_ADD_LOCK_INFO);//1+(4+1+1+1+1+4+4);

        LOG(INFO)<<GW_LOG<<"s_len : "<<s_len;
        char ucEncrypt_type=1;
        short int cmd1=0x100E;
        memset(cmdsend,0,1024);
        int length=s_len;
        int serialnum=atoi(MyRand(4).c_str());

        cmdsend[0] = length & 0xFF;
        cmdsend[1] = length >> 8;

        cmdsend[2] = cmd1 & 0xFF;
        cmdsend[3] = cmd1 >> 8;

        cmdsend[4] = serialnum & 0xFF;
        cmdsend[5] = (serialnum >> 8) & 0xFF;
        cmdsend[6] = (serialnum >> 16) & 0xFF;
        cmdsend[7] = (serialnum >> 24) & 0xFF;

        memcpy(cmdsend+8,(u8*)&cmd100E,length);

        length=length+8;
        LOG(INFO)<<GW_LOG<<"["<<_gw_cmd<<"] 加密前的数据长度 ："<<length;
        cmdlength=length;
        //u8 NetEncodePacket(u32 node_id, u32 *keyword, u8 *ucData, u16 *ucData_len, u8 ucEncrypt_type);

        print[2]={'\0'};
        s_print="";
        for (int i = 0; i < 16; ++i) {
            sprintf(print,"%02x",key[i]);
            s_print=s_print+print;
        }
        LOG(INFO)<<GW_LOG<< "fd : "<<listenfd <<" ret :"<<ret <<" NetEncodePacket before data : "<<s_print;

         print[2]={'\0'};
         s_print="";
        for (int i = 0; i < cmdlength; ++i) {
            sprintf(print,"%02x",cmdsend[i]);
            s_print=s_print+print;
        }
        LOG(INFO)<<GW_LOG<< "fd : "<<listenfd <<" ret :"<<ret <<" NetEncodePacket before data : "<<s_print;

        ret = NetEncodePacket(node_id,(u32*)key,cmdsend,&cmdlength,ucEncrypt_type);
        if(ret == HUOHE_FAIL){
            LOG(ERROR)<<GW_LOG<<"["<<_gw_cmd<<"] 指令 加密失败";
            return -1;
        } else
        {
            LOG(INFO)<<GW_LOG<<"["<<_gw_cmd<<"] 加密后的数据长度 : "<<cmdlength;
            char print[2]={'\0'};
            string s_print="";
            for (int i = 0; i < cmdlength; ++i) {
                sprintf(print,"%02x",cmdsend[i]);
                s_print=s_print+print;
            }
            LOG(INFO)<<GW_LOG<< "fd : "<<listenfd <<" ret :"<<ret <<" NetEncodePacket data : "<<s_print;
        }

    }
    else if(mylockNodeFram.data_type==0x1E)
    {
        Lock_Info lockCmd1E;
        memset(&lockCmd1E,0x00,sizeof(Lock_Info));
        char tmp[2]={'\0'};
        sprintf(tmp,"%02x",mylockNodeFram.data_len);
        int data_len=strtol(tmp,NULL,16);
        memcpy((char *)&lockCmd1E,mylockNodeFram.Data,data_len);

        if(lockCmd1E.info_type == 0)
        {
            _gw_cmd="0x1007";
            lockOnLineFlag=1;
            NODE_LOCK_NET_STATUS_INFO cmd1007;
            Lock_Info cmd1E;

            memset(&cmd1007,0x00,sizeof(NODE_LOCK_NET_STATUS_INFO));
            memset(&cmd1E,0x00,sizeof(Lock_Info));
            char tmp[2]={'\0'};
            sprintf(tmp,"%02x",mylockNodeFram.data_len);
            int data_len=atoi(tmp);

            LOG(INFO)<<GW_LOG<<" 指令 data_len :"<<data_len;
            memcpy(&cmd1E,(u8 *)mylockNodeFram.Data,sizeof(Lock_Key));


            map<u16,u32>::iterator it=u32ID.find(mylockNodeFram.src_id);
            if(it == u32ID.end())
            {
                LOG(INFO)<<GW_LOG<<"门锁ID未找到 : "<<mylockNodeFram.src_id;
                return -2;
            }
            cmd1007lockID=it->second;
            cmd1007.lock_num=1;
            cmd1007.status[0].lock_id=it->second;
            cmd1007.status[0].report_time=getCurrentTime();
            cmd1007.status[0].status=0;

            unsigned short int s_len=10;
            char ucEncrypt_type=1;
            short int cmd1=0x1007;
            memset(cmdsend,0x00,1024);
            int length=s_len;
            int serialnum=atoi(MyRand(4).c_str());

            cmdsend[0] = length & 0xFF;
            cmdsend[1] = length >> 8;

            cmdsend[2] = cmd1 & 0xFF;
            cmdsend[3] = cmd1 >> 8;

            cmdsend[4] = serialnum & 0xFF;
            cmdsend[5] = (serialnum >> 8) & 0xFF;
            cmdsend[6] = (serialnum >> 16) & 0xFF;
            cmdsend[7] = (serialnum >> 24) & 0xFF;

            memcpy(cmdsend+8,(u8*)&cmd1007,length);
            length=length+8;
            LOG(INFO)<<GW_LOG<<"["<<_gw_cmd<<"] 加密前的数据长度 ："<<length;
            cmdlength=length;
            u8  ret;


            char print[2]={'\0'};
            string s_print="";
            for (int i = 0; i < cmdlength; ++i) {
                sprintf(print,"%02x",cmdsend[i]);
                s_print=s_print+print;
            }
            LOG(INFO)<<GW_LOG<< "fd : "<<listenfd <<" NetEncodePacket before data : "<<s_print;



            ret = NetEncodePacket(node_id,(u32 *)key,cmdsend,&cmdlength,ucEncrypt_type);
            if(ret == HUOHE_FAIL){
                LOG(ERROR)<<GW_LOG<<"["<<_gw_cmd<<"] -----------------------------------------指令 加密失败";
                return -1;
            }

            return 0;
        }

        LOG(INFO)<<GW_LOG<<"lockCmd1E.info_type :  "<<lockCmd1E.info_type;
        if(lockCmd1E.info_type == 4)
            LOG(INFO)<<GW_LOG<<"+++++++++++++++++++++++++++++++++++++++++++++++++++网关上报门锁电量";
        _gw_cmd="0x1004";
        NODE_LOCK_INFO cmd1004;
        memset(&cmd1004,0x00,sizeof(NODE_LOCK_INFO));

        cmd1004.lock_num=1;
        int info_len=0;
        for (int i = 0; i <cmd1004.lock_num ; ++i)
        {
            cmd1004.lock_list[i].lock_id=mylockNodeFram.src_id;
            cmd1004.lock_list[i].rec_num=1;
            for (int j = 0; j <cmd1004.lock_list[i].rec_num ; ++j)
            {
                tmp[2]={'\0'};
                sprintf(tmp,"%02x",lockCmd1E.info_len);
                info_len=strtol(tmp,NULL,16);

                cmd1004.lock_list[i].lock_info[j].info_len=lockCmd1E.info_len;
                memcpy(cmd1004.lock_list[i].lock_info[j].info,lockCmd1E.info,info_len);
                cmd1004.lock_list[i].lock_info[j].info_type=lockCmd1E.info_type;

            }
        }

        unsigned short int s_len=1+(2+1+(1+1+info_len));
        unsigned short int s_cmd=0x1004;
        char ucEncrypt_type=1;

        if(enCodeSendData((unsigned char *)&cmd1004,s_len,s_cmd,ucEncrypt_type)<0)
        {
            LOG(INFO)<<GW_LOG<<"["<<_gw_cmd<<"] 网关请求服务器查询门锁密码加密失败";
            return -1;
        }

    } else if(mylockNodeFram.data_type==0x48)
    {
        _gw_cmd="0x1014";



        NODE_LOCK_KEY_INFO cmd1014;
        Lock_Key lockKey;
        memset(&cmd1014,0x00,sizeof(NODE_LOCK_KEY_INFO));
        memset(&lockKey,0x00,sizeof(Lock_Key));

        char tmp[2]={'\0'};
        sprintf(tmp,"%02x",mylockNodeFram.data_len);
        int data_len=atoi(tmp);

        LOG(INFO)<<GW_LOG<<" 指令 data_len :"<<data_len;
        memcpy(&lockKey,(u8 *)mylockNodeFram.Data,sizeof(Lock_Key));


        map<u16,u32>::iterator it=u32ID.find(mylockNodeFram.src_id);
        if(it == u32ID.end())
        {
            LOG(INFO)<<GW_LOG<<"门锁ID未找到 : "<<mylockNodeFram.src_id;
            return -2;
        }
        cmd1014.lock_id=it->second;


        LOG(INFO)<<GW_LOG<<"mylockNodeFram.src_id : "<<mylockNodeFram.src_id;

        sprintf(tmp,"%02x",lockKey.lock_key_len);
        int lock_key_len=atoi(tmp);
        memcpy(cmd1014.lock_key,lockKey.lock_key,16);
        LOG(INFO)<<GW_LOG<<" 指令 lock_key_len :"<<lock_key_len;

        tmp[2]={'\0'};
        string string1="";
        for (int j = 0; j <16 ; ++j) {
            sprintf(tmp,"%02x",lockKey.lock_key[j]);
            string1=string1+tmp;
        }LOG(INFO)<<GW_LOG<<" lock_key ["<<string1<<"]";

        cmd1014.lock_key_len=lockKey.lock_key_len;


        cmd1014.check_auth_data=lockKey.check_auth_data;
        LOG(INFO)<<GW_LOG<<"lockKey.check_auth_data : "<<lockKey.check_auth_data;



        unsigned short int s_len=sizeof(NODE_LOCK_KEY_INFO);//1+(4+1+1+1+1+4+4);
        char ucEncrypt_type=1;
        short int cmd1=0x1014;
        memset(cmdsend,0x00,1024);
        int length=s_len;
        int serialnum=atoi(MyRand(4).c_str());

        cmdsend[0] = length & 0xFF;
        cmdsend[1] = length >> 8;

        cmdsend[2] = cmd1 & 0xFF;
        cmdsend[3] = cmd1 >> 8;

        cmdsend[4] = serialnum & 0xFF;
        cmdsend[5] = (serialnum >> 8) & 0xFF;
        cmdsend[6] = (serialnum >> 16) & 0xFF;
        cmdsend[7] = (serialnum >> 24) & 0xFF;

        memcpy(cmdsend+8,(u8*)&cmd1014,length);
        length=length+8;
        LOG(INFO)<<GW_LOG<<"["<<_gw_cmd<<"] 加密前的数据长度 ："<<length;
        cmdlength=length;
        u8  ret;


        char print[2]={'\0'};
        string s_print="";
        for (int i = 0; i < cmdlength; ++i) {
            sprintf(print,"%02x",cmdsend[i]);
            s_print=s_print+print;
        }
        LOG(INFO)<<GW_LOG<< "fd : "<<listenfd <<" NetEncodePacket before data : "<<s_print;



        ret = NetEncodePacket(node_id,(u32 *)key,cmdsend,&cmdlength,ucEncrypt_type);
        if(ret == HUOHE_FAIL){
            LOG(ERROR)<<GW_LOG<<"["<<_gw_cmd<<"] -----------------------------------------指令 加密失败";
            return -1;
        }

        else
        {
            LOG(INFO)<<GW_LOG<<"["<<_gw_cmd<<"] 加密后的数据长度 : "<<cmdlength;
            char print[2]={'\0'};
            string s_print="";
            for (int i = 0; i < cmdlength; ++i) {
                sprintf(print,"%02x",cmdsend[i]);
                s_print=s_print+print;
            }
            LOG(INFO)<<GW_LOG<< "fd : "<<listenfd <<" NetEncodePacket data : "<<s_print;
        }


    }
    else if(mylockNodeFram.data_type==0x31)
    {
        Upload_LockRssi cmd31;
        memset(&cmd31,0x00,sizeof(Upload_LockRssi));
        memcpy(&cmd31,mylockNodeFram.Data,1);

        NODE_RSSI_DATA_INFO cmd100F;
        memset(&cmd100F,0x00,sizeof(NODE_RSSI_DATA_INFO));
        cmd100F.lock_num=1;

        map<u16,u32>::iterator it=u32ID.find(mylockNodeFram.src_id);
        if(it == u32ID.end())
        {
            LOG(INFO)<<GW_LOG<<"门锁ID未找到 : "<<mylockNodeFram.src_id;
            return -2;
        }

        cmd100F.rssi_data[0].lock_id=it->second;
        cmd100F.rssi_data[0].cap_time=getCurrentTime();
        cmd100F.rssi_data[0].Rssi=cmd31.rssi_level;

        unsigned short int s_len=1+4+4+1;
        char ucEncrypt_type=0;
        short int cmd1=0x100F;
        _gw_cmd="0x100F";
        memset(cmdsend,0x00,1024);
        int length=s_len;
        int serialnum=atoi(MyRand(4).c_str());

        cmdsend[0] = length & 0xFF;
        cmdsend[1] = length >> 8;

        cmdsend[2] = cmd1 & 0xFF;
        cmdsend[3] = cmd1 >> 8;

        cmdsend[4] = serialnum & 0xFF;
        cmdsend[5] = (serialnum >> 8) & 0xFF;
        cmdsend[6] = (serialnum >> 16) & 0xFF;
        cmdsend[7] = (serialnum >> 24) & 0xFF;

        memcpy(cmdsend+8,(u8*)&cmd100F,length);
        length=length+8;
        LOG(INFO)<<GW_LOG<<"["<<_gw_cmd<<"] 加密前的数据长度 ："<<length;
        cmdlength=length;
        u8  ret;


        char print[2]={'\0'};
        string s_print="";
        for (int i = 0; i < cmdlength; ++i) {
            sprintf(print,"%02x",cmdsend[i]);
            s_print=s_print+print;
        }
        LOG(INFO)<<GW_LOG<< "fd : "<<listenfd <<" NetEncodePacket before data : "<<s_print;



        ret = NetEncodePacket(node_id,(u32 *)key,cmdsend,&cmdlength,ucEncrypt_type);
        if(ret == HUOHE_FAIL){
            LOG(ERROR)<<GW_LOG<<"["<<_gw_cmd<<"] -----------------------------------------指令 加密失败";
            return -1;
        }

    }
    else if(mylockNodeFram.data_type == 0x30)
    {
        char ucEncrypt_type=0;

        if(pwd_op_flag == 0||pwd_op_flag ==2)//添加or修改
        {
            _gw_cmd="0x1009";
            NODE_SET_PWD_RESULT_INFO cmd1009;
            SetPwd_Result cmd30;
            memset(&cmd30,0x00,sizeof(SetPwd_Result));
            memset(&cmd1009,0x00,sizeof(NODE_SET_PWD_RESULT_INFO));
            memcpy(&cmd30,(SetPwd_Result *)mylockNodeFram.Data,sizeof(SetPwd_Result));

            cmd1009.serial_num=delPwdSerino;

            map<u16,u32>::iterator it=u32ID.find(mylockNodeFram.src_id);
            if(it == u32ID.end())
            {
                LOG(INFO)<<GW_LOG<<"门锁ID未找到 : "<<mylockNodeFram.src_id;
                return -2;
            }

            cmd1009.lock_id=it->second;
            cmd1009.pwd_num=pwd_num;
            cmd1009.pwd_type=pwd_type;
            cmd1009.pwd_status=cmd30.pwd_status;

            unsigned short int s_len=sizeof(NODE_SET_PWD_RESULT_INFO);//1+(4+1+1+1+1+4+4);
            ucEncrypt_type=1;
            short int cmd1=0x1009;
            memset(cmdsend,0x00,1024);
            int length=s_len;
            int serialnum= atoi(MyRand(4).c_str());

            cmdsend[0] = length & 0xFF;
            cmdsend[1] = length >> 8;

            cmdsend[2] = cmd1 & 0xFF;
            cmdsend[3] = cmd1 >> 8;

            cmdsend[4] = serialnum & 0xFF;
            cmdsend[5] = (serialnum >> 8) & 0xFF;
            cmdsend[6] = (serialnum >> 16) & 0xFF;
            cmdsend[7] = (serialnum >> 24) & 0xFF;

            memcpy(cmdsend+8,(u8*)&cmd1009,length);
            length=length+8;
            LOG(INFO)<<GW_LOG<<"["<<_gw_cmd<<"] 加密前的数据长度 ："<<length;
            cmdlength=length;

        }
        else if(pwd_op_flag == 1)
        {
            _gw_cmd="0x100C";
            NODE_DEL_LOCK_PWD_RESULT_INFO cmd100C;
            SetPwd_Result cmd30;
            memset(&cmd30,0x00,sizeof(SetPwd_Result));
            memset(&cmd100C,0x00,sizeof(NODE_DEL_LOCK_PWD_RESULT_INFO));

            memcpy(&cmd30,mylockNodeFram.Data,1);

            cmd100C.lock_id=cmd3007.lock_id;
            cmd100C.pwd_type=cmd3007.pwd_type[0];
            cmd100C.del_all_status=0;
            cmd100C.pwd_num=cmd3007.pwd_num;
            cmd100C.serial_num=delPwdSerino;

            cmd100C.status=cmd30.pwd_status;

            unsigned short int s_len=sizeof(NODE_DEL_LOCK_PWD_RESULT_INFO);//1+(4+1+1+1+1+4+4);
            ucEncrypt_type=1;
            short int cmd1=0x100C;
            memset(cmdsend,0x00,1024);
            int length=s_len;
            int serialnum=atoi(MyRand(4).c_str());

            cmdsend[0] = length & 0xFF;
            cmdsend[1] = length >> 8;

            cmdsend[2] = cmd1 & 0xFF;
            cmdsend[3] = cmd1 >> 8;

            cmdsend[4] = serialnum & 0xFF;
            cmdsend[5] = (serialnum >> 8) & 0xFF;
            cmdsend[6] = (serialnum >> 16) & 0xFF;
            cmdsend[7] = (serialnum >> 24) & 0xFF;

            memcpy(cmdsend+8,(u8*)&cmd100C,length);
            length=length+8;
            LOG(INFO)<<GW_LOG<<"["<<_gw_cmd<<"] 加密前的数据长度 ："<<length;
            cmdlength=length;

        }



        u8  ret;
        char print[2]={'\0'};
        string s_print="";
        for (int i = 0; i < cmdlength; ++i) {
            sprintf(print,"%02x",cmdsend[i]);
            s_print=s_print+print;
        }
        LOG(INFO)<<GW_LOG<< "fd : "<<listenfd <<" NetEncodePacket before data : "<<s_print;



        ret = NetEncodePacket(node_id,(u32 *)key,cmdsend,&cmdlength,ucEncrypt_type);
        if(ret == HUOHE_FAIL){
            LOG(ERROR)<<GW_LOG<<"["<<_gw_cmd<<"] -----------------------------------------指令 加密失败";
            return -1;
        }

        else
        {
            LOG(INFO)<<GW_LOG<<"["<<_gw_cmd<<"] 加密后的数据长度 : "<<cmdlength;
            char print[2]={'\0'};
            string s_print="";
            for (int i = 0; i < cmdlength; ++i) {
                sprintf(print,"%02x",cmdsend[i]);
                s_print=s_print+print;
            }
            LOG(INFO)<<GW_LOG<< "fd : "<<listenfd <<" NetEncodePacket data : "<<s_print;
        }


    }
    return 0;
}

void Gw_Task_Process::PushLockData(MYLOCK_NODE_FRAME &mylockNodeFram,u32 idkey)
{
    LOG(INFO)<<GW_LOG<< "门锁数据的队列深度为..............................................: "<<taskWriteData.size();

    if(taskWriteData.size()>0)
    {
        LOG(INFO)<<GW_LOG<< "门锁数据的队列深度为.................. 此门锁队列中有数据还未处理............................: "<<taskWriteData.size();
        //sleep(10);
        taskWriteData.erase(idkey);
    }

    taskWriteData.insert(pair<u32 ,MYLOCK_NODE_FRAME>(idkey,mylockNodeFram));

    map<u32 ,MYLOCK_NODE_FRAME>::iterator iterator1=taskWriteData.find(idkey);
    MYLOCK_NODE_FRAME mylockNodeFrame;
    memcpy(&mylockNodeFrame,(MYLOCK_NODE_FRAME *)&iterator1->second,sizeof(MYLOCK_NODE_FRAME));
    char pp[2]={'\0'};
    sprintf(pp,"%02x",mylockNodeFrame.data_type);
    LOG(INFO)<<GW_LOG<<" mylockNodeFrame.data_type : "<<pp;
    pp[2]={'\0'};
    sprintf(pp,"02x",mylockNodeFrame.data_len);

    LOG(INFO)<<GW_LOG<<" mylockNodeFrame.data_len : "<<pp;

    char ppp[28]={'\0'};
    string ss="";
    for (int i = 0; i <32 ; ++i) {
        sprintf(pp,"%02x",mylockNodeFrame.Data[i]);
        ss=ss+pp;
    }
    sprintf(ppp,"%s",mylockNodeFrame.Data);
    LOG(INFO)<<GW_LOG << "mylockNodeFrame.Data : " << ss;
    LOG(INFO)<<GW_LOG<< " mylockNodeFrame.dst_id : " << mylockNodeFrame.dst_id;

}

void Gw_Task_Process::ParseLockData(char *rcvLockData,string cmd)
{
   // gwRequestNhapFlag=1;
    string l_ID="";
    MYLOCK_NODE_FRAME request;
    memset(&request,0x00,sizeof(MYLOCK_NODE_FRAME));

    NODE2SVR_FRAME_STRUCT *rq=(NODE2SVR_FRAME_STRUCT *)rcvLockData;
    if(cmd == "0x400E")
    {
        char print[2]={'\0'};
        string s_print="";
        for (int i = 0; i < sizeof(SVR_ECHO_ADD_LOCK_INFO); ++i) {
            sprintf(print,"%02x",rq->data[i]);
            s_print=s_print+print;
        }
        LOG(INFO)<<GW_LOG<< "fd : "<<listenfd <<" len :"<<sizeof(SVR_ECHO_ADD_LOCK_INFO) <<" 发送给门锁的数据 : "<<s_print;


        SVR_ECHO_ADD_LOCK_INFO cmd400E;
        memset(&cmd400E,0x00,sizeof(SVR_ECHO_ADD_LOCK_INFO));
        memcpy((char *)&cmd400E,rq->data,sizeof(SVR_ECHO_ADD_LOCK_INFO));

        if (cmd400E.status!=0)
        {
            LOG(INFO)<<GW_LOG<<"门锁申请加入数据出错,status ["<<cmd400E.status<<"]";
            return;

        }

        request.data_type=0x42;
       // for (int i = 0; i <1 ; ++i)
        {
            request.dst_id=(cmd400E.lock_id);
            request.crc8=rq->crc32;
            request.src_id=node_id;

            LOG(INFO)<<GW_LOG<<"cmd400E.Add_lock_ack[i].lock_id : "<<cmd400E.lock_id;
            Inform_Joinin cmd42;
            memset(&cmd42,0x00,sizeof(Inform_Joinin));
            cmd42.status=cmd400E.status;

            cmd42.auth_data=cmd400E.auth_data;
            LOG(INFO)<<GW_LOG<<"cmd400E.Add_lock_ack[i].auth_data : "<<cmd400E.auth_data;

            cmd42.check_lock_random_data=cmd400E.check_lock_random_data;
            LOG(INFO)<<GW_LOG<<"cmd400E.Add_lock_ack[i].check_lock_random_data : "<<cmd400E.check_lock_random_data;
            cmd42.lock_channel=cmd400E.work_channel;
            cmd42.trans_node_key=cmd400E.check_lock_random_data;
            request.data_len=sizeof(Inform_Joinin);
            memcpy(request.Data,(u8*)&cmd42,sizeof(Inform_Joinin));

            PushLockData(request,cmd400E.lock_id);
        }
    }
    else if(cmd == "0x300D")
    {
        LOG(INFO)<<GW_LOG<<"服务器查询门锁密码给网关数据开始";
        CMD_SVR_QUERY_LOCK_INFO cmd300D;
        Query_Lock_Info queryLockInfo;

        memset(&cmd300D,0x00,sizeof(NODE_ECHO_QUERY_LOCK));
        memcpy((char *)&cmd300D,rq->data,sizeof(NODE_ECHO_QUERY_LOCK_INFO));
        request.dst_id=cmd300D.lock_id;
        request.data_type=0x22;
        request.Data[0]=cmd300D.query_type;
        request.data_len=1;
        request.src_id=node_id;
        request.crc8=rq->crc32;
        request.data_label=0;
        PushLockData(request,cmd300D.lock_id);
        char tmp[32]={'\0'};
        sprintf(tmp,"%d",cmd300D.lock_id);
        l_ID=tmp;

    } else if(cmd == "0x3000")
    {
        SVR_SET_LOCK_PWD_INFO cmd3000;
        memset(&cmd3000,0x00,sizeof(SVR_SET_LOCK_PWD_INFO));
        memcpy((u8 *)&cmd3000,rq->data,sizeof(SVR_SET_LOCK_PWD_INFO));
        request.data_label=0;
        request.crc8=rq->crc32;
        request.src_id=node_id;
        request.dst_id=cmd3000.lock_id;
        request.data_type=0x12;

        pwd_en=cmd3000.pwd_en;
        pwd_op_flag=cmd3000.pwd_op_flag;
        delPwdSerino=rq->serial_num;
        pwd_num=cmd3000.pwd_num;
        pwd_type=cmd3000.pwd_type;
        pwd_op_flag=cmd3000.pwd_op_flag;
       // for (int i = 0; i <cmd3000.pwd_num ; ++i)
        {
            SETPWD_info cmd12;
            memset(&cmd12,0x00,sizeof(SETPWD_info));
            cmd12.pwd_type=cmd3000.pwd_type;
            cmd12.pwd_start_time=cmd3000.start_time;
            cmd12.pwd_end_time=cmd3000.end_time;
            cmd12.pwd_len=cmd3000.pwd_len;
            memcpy(cmd12.pwd,cmd3000.pwd,cmd3000.pwd_len);
            memcpy(request.Data,(u8 *)&cmd12,sizeof(SETPWD_info));
            PushLockData(request,cmd3000.lock_id);
        }
        char tmp[32]={'\0'};
        sprintf(tmp,"%d",cmd3000.lock_id);
        l_ID=tmp;
    }
    else if(cmd == "0x3007")
    {

        Del_PWD_info cmd34;
        memset(&cmd34,0x00,sizeof(Del_PWD_info));
        memset(&cmd3007,0x00,sizeof(SVR_DEL_LOCK_PWD_INFO));
        memcpy((char *)&cmd3007,rq->data,sizeof(SVR_DEL_LOCK_PWD_INFO));
        delPwdSerino = rq->serial_num;
        pwd_op_flag=1;
        request.data_type=0x34;
        request.data_label=0;
        request.crc8=rq->crc32;
        request.src_id=node_id;
        request.dst_id=cmd3007.lock_id;

        cmd34.lock_id=cmd3007.lock_id;
        cmd34.pwd_cnt=cmd3007.pwd_num;
        memcpy(&cmd34.pwd_type,cmd3007.pwd_type,strlen((char *)cmd3007.pwd_type));

        request.data_len=sizeof(Del_PWD_info);
        memcpy(&request.Data,(char *)&cmd34,sizeof(Del_PWD_info));//0-表示全部删除,大于0从大于0编号以后的密码全部删除
        PushLockData(request,cmd3007.lock_id);
        char tmp[32]={'\0'};
        sprintf(tmp,"%d",cmd3007.lock_id);
        l_ID=tmp;

    } else if(cmd == "0x3008")
    {
        SVR_SYS_RST_LOCK_INFO cmd3008;
        memset(&cmd3008,0x00,sizeof(SVR_SYS_RST_LOCK_INFO));
        memcpy((u8 *)&cmd3008,rq->data,sizeof(SVR_SYS_RST_LOCK_INFO));

        request.data_type=0x3A;
        request.data_label=0;
        request.crc8=rq->crc32;
        request.src_id=node_id;
        request.dst_id=cmd3008.lock_id;

         Sys_RST_Lock_struct sysRstLockStruct;
        memset(&sysRstLockStruct,0x00,sizeof(Sys_RST_Lock_struct));
        sysRstLockStruct.lock_id=cmd3008.lock_id;
        memcpy(sysRstLockStruct.rst_data,(char *)cmd3008.rst_data,4);
        memcpy(sysRstLockStruct.rst_data_check,(char *)cmd3008.rst_data_check,4);
        request.data_len=sizeof(Sys_RST_Lock_struct);
        memcpy(request.Data,(char *)&sysRstLockStruct,sizeof(Sys_RST_Lock_struct));
        PushLockData(request,cmd3008.lock_id);
        char tmp[32]={'\0'};
        sprintf(tmp,"%d",cmd3008.lock_id);
        l_ID=tmp;
    }
    else if(cmd == "0x300E")
    {
        CMD_SVR_RESTART_LOCK_INFO cmd300E;
        memset(&cmd300E,0x00,sizeof(CMD_SVR_RESTART_LOCK_INFO));
        memcpy((char *)&cmd300E,rq->data,sizeof(CMD_SVR_RESTART_LOCK_INFO));

        request.data_type=0x3C;
        request.data_label=0;
        request.crc8=rq->crc32;
        request.src_id=node_id;
        request.dst_id=cmd300E.lock_id;

        Sys_Restart_Lock sysRestartLock;
        memset(&sysRestartLock,0x00,sizeof(Sys_Restart_Lock));
        sysRestartLock.lock_id=cmd300E.lock_id;
        request.data_len=4;
        memcpy(request.Data,(char *)&sysRestartLock,4);
        PushLockData(request,cmd300E.lock_id);
        char buf[64]={'\0'};
        sprintf(buf,"%d%d",cmd300E.lock_id,0);
        l_ID+=buf;

    }
    else if(cmd == "0x3010")
    {
        SVR_OPEN_DOOR_INFO cmd3010;
        memset(&cmd3010,0x00,sizeof(SVR_OPEN_DOOR_INFO));
        memcpy((char *)&cmd3010,rq->data,sizeof(SVR_OPEN_DOOR_INFO));
        request.data_type=0x36;
        request.data_label=0;
        request.crc8=rq->crc32;
        request.src_id=node_id;
        request.dst_id=cmd3010.lock_id;
        Open_door_info openDoorInfo;
        memset(&openDoorInfo,0x00,sizeof(Open_door_info));
        openDoorInfo.open_door_type=cmd3010.Open_door_info.open_door_type;
        openDoorInfo.rand_data=cmd3010.Open_door_info.rand_data;
        openDoorInfo.check_rand_data=cmd3010.Open_door_info.check_rand_data;

        memcpy(request.Data,(char *)&openDoorInfo,sizeof(Open_door_info));
        request.data_len=sizeof(Open_door_info);
        PushLockData(request,cmd3010.lock_id);
        char buf[64]={'\0'};
        sprintf(buf,"%d%d",cmd3010.lock_id,0);
        l_ID+=buf;
    } else if(cmd == "0x3011")
    {
        SVR_SET_DEL_LOCK_ALGORIM_PWD_INFO cmd3011;
        memset(&cmd3011,0x00,sizeof(SVR_SET_DEL_LOCK_ALGORIM_PWD_INFO));
        memcpy((char *)&cmd3011,rq->data,sizeof(SVR_SET_DEL_LOCK_ALGORIM_PWD_INFO));
        request.data_type=0x32;
        request.data_label=0;
        request.crc8=rq->crc32;
        request.src_id=node_id;
        request.dst_id=cmd3011.lock_id;

        DEL_ALGORITHM_PWD_info cmd32;
        memset(&cmd32,0x00,sizeof(DEL_ALGORITHM_PWD_info));

        cmd32.Algorim_otp=cmd3011.pwd.Algorim_otp;
        cmd32.pwd_len=cmd3011.pwd.pwd_len;
        memcpy(cmd32.pwd,cmd3011.pwd.pwd,cmd3011.pwd.pwd_len);

        request.data_len=sizeof(DEL_ALGORITHM_PWD_info);
        memcpy(request.Data,(char *)&cmd32,sizeof(DEL_ALGORITHM_PWD_info));
        PushLockData(request,cmd3011.lock_id);

        char buf[64]={'\0'};
        sprintf(buf,"%d%d",cmd3011.lock_id,0);
        l_ID+=buf;
    } else if (cmd == "0x4007")
    {
        map<u16 ,u32 >::iterator it=u32ID.begin();
        if (u32ID.empty())
            return;

        request.data_type=0x02;
        request.data_label=0;
        request.crc8=rq->crc32;
        request.src_id=node_id;
        request.data_len=1;
        request.Data[0]=0;
        /*
        for (;it!=u32ID.end();++it) {
            request.dst_id=it->second;
            PushLockData(request,it->second);
        }
         */
        request.dst_id=cmd1007lockID;
        PushLockData(request,cmd1007lockID);
    }
    else if( cmd == "0x3003")
    {
        LOG(INFO)<<GW_LOG<<" ------------------>网关下发重启门锁指令";
        Sys_Restart_Lock cmd3C;
        SVR_DEL_LOCK_INFO cmd3003;
        memset(&cmd3C,0x00,sizeof(Sys_Restart_Lock));
        memset(&cmd3003,0x00,sizeof(SVR_DEL_LOCK_INFO));

        memcpy(&cmd3003,rq->data,sizeof(SVR_DEL_LOCK_INFO));

        cmd3C.lock_id=cmd3003.lock_id;

        request.data_type=0x3C;
        LOG(INFO)<<GW_LOG<<" ------------------>网关下发重启门锁指令 : "<<request.data_type << "cmd3C.lock_id :  "<<cmd3C.lock_id;
        request.data_label=0;
        request.crc8=rq->crc32;
        request.src_id=node_id;
        request.dst_id=cmd3003.lock_id;

        LOG(INFO)<<GW_LOG<<" ------------------>request.dst_id: " <<request.dst_id;
        request.data_len=4;
        LOG(INFO)<<GW_LOG<<" ------------------>网关下发重启门锁指令 : "<< sizeof(Sys_Restart_Lock);
        memcpy(request.Data,(u8 *)&cmd3C,sizeof(Sys_Restart_Lock));
        LOG(INFO)<<GW_LOG<<" ------------------> request.Data : "<<request.Data;
        PushLockData(request,cmd3003.lock_id);

    }
    else
    {
        LOG(INFO)<<GW_LOG<<"网关指令 ： "<<cmd<<"不存在, or lock cmd ";
        gwRequestNhapFlag=0;
        return;
    }
    DownQuest(cmd,l_ID);
    gwRequestNhapFlag=1;
    return;

}

int Gw_Task_Process::RequestRcvSvr(string nowCMD,u32 lockID)

{
    short int cmd1=0;
    unsigned short int s_len=0;
    char ucEncrypt_type=0;
    memset(cmdsend,0x00,1024);
    if(nowCMD == "0x2000")
    {
        _gw_cmd="0x2000";
        NODE_ECHO_SET_PWD_INFO cmd2000;
        cmd2000.status=0;
        cmd1=0x2000;
        s_len=1;
        ucEncrypt_type=1;
        memcpy(cmdsend+8,(u8*)&cmd2000,s_len);
    } else if(nowCMD == "0x2007")
    {
        _gw_cmd="0x2007";
        NODE_ECHO_DEL_LOCK_PWD_INFO cmd2007;
        cmd2007.status=0;
        cmd1=0x2007;
        s_len=1;
        ucEncrypt_type=1;
        memcpy(cmdsend+8,(u8*)&cmd2007,s_len);
    } else if(nowCMD == "0x2003")
    {
        _gw_cmd="0x2003";
        NODE_ECHO_DEL_LOCK_INFO cmd2003;
        memset(&cmd2003,0x00,sizeof(NODE_ECHO_DEL_LOCK_INFO));
        cmd2003.lock_id=lockID;
        cmd2003.status=0;
        cmd1=0x2003;
        s_len=sizeof(NODE_ECHO_DEL_LOCK_INFO);
        ucEncrypt_type=1;
        memcpy(cmdsend+8,(u8*)&cmd2003,sizeof(NODE_ECHO_DEL_LOCK_INFO));


    }


    int length=s_len;
    int serialnum=atoi(MyRand(4).c_str());

    cmdsend[0] = length & 0xFF;
    cmdsend[1] = length >> 8;

    cmdsend[2] = cmd1 & 0xFF;
    cmdsend[3] = cmd1 >> 8;

    cmdsend[4] = serialnum & 0xFF;
    cmdsend[5] = (serialnum >> 8) & 0xFF;
    cmdsend[6] = (serialnum >> 16) & 0xFF;
    cmdsend[7] = (serialnum >> 24) & 0xFF;

    length=length+8;
    LOG(INFO)<<GW_LOG<<"["<<_gw_cmd<<"] 加密前的数据长度 ："<<length;
    cmdlength=length;
    u8  ret;

    /*
    char print[2]={'\0'};
    string s_print="";
    for (int i = 0; i < cmdlength; ++i) {
        sprintf(print,"%02x",cmdsend[i]);
        s_print=s_print+print;
    }
    LOG(INFO)<<GW_LOG<< "fd : "<<listenfd <<" NetEncodePacket before data : "<<s_print;
    */
    ret = NetEncodePacket(node_id,(u32 *)key,cmdsend,&cmdlength,ucEncrypt_type);
    if(ret == HUOHE_FAIL){
        LOG(ERROR)<<GW_LOG<<"["<<_gw_cmd<<"] -----------------------------------------指令 加密失败";
        return -1;
    }
    LOG(INFO)<<GW_LOG<<"["<<_gw_cmd<<"]加密立即应答服务器报文成功....................";

    read_io.stop();
    write_io.set<Gw_Task_Process,&Gw_Task_Process::write_callback>(this);
    write_io.start(listenfd,EV_WRITE);


}


void Gw_Task_Process::correntTime_callback(ev::timer &w, int revents)
{
    if(gw_off_sucess != 3)
        return;

    /*
    if (hurt_send_off == 1)
    {
        correntTimer.set<Gw_Task_Process,&Gw_Task_Process::correntTime_callback>(this);
        correntTimer.start(0,1);
    }

    hurt_send_off=2;
     */
    _gw_cmd="0x1005";
    NODE_NTP_CALI_TIME_INFO cmd1005;
    memset(&cmd1005,0x00,sizeof(NODE_NTP_CALI_TIME_INFO));
    cmd1005.ms_time=0;
    cmd1005.time=0;
    u8 tmp1005[1024];
    memset(&tmp1005,0x00,sizeof(tmp1005));
    u16 len1005=sizeof(NODE_NTP_CALI_TIME_INFO);
    memcpy(tmp1005,(u8*)&cmd1005,len1005);

    int serialnum=stoi(MyRand(4).data());

    u16 length;
    length=len1005;
    short int cmd1=0x1005;
    memset(cmdsend,0,1024);
    cmdsend[0] = length & 0xFF;
    cmdsend[1] = length >> 8;

    cmdsend[2] = cmd1 & 0xFF;
    cmdsend[3] = cmd1 >> 8;

    cmdsend[4] = serialnum & 0xFF;
    cmdsend[5] = (serialnum >> 8) & 0xFF;
    cmdsend[6] = (serialnum >> 16) & 0xFF;
    cmdsend[7] = (serialnum >> 24) & 0xFF;

    memcpy(cmdsend+8,(u8*)&cmd1005,length);
    length=length+8;
    cmdlength=length;
    u8  ret;
    u8 ucEncrypt_type=1;

    //LOG(INFO)<<GW_LOG<<"["<<_gw_cmd<<"] 加密数据开始..... cmdlength: "<<cmdlength<<"length :"<<length;
    ret = NetEncodePacket(node_id,(u32*)key,cmdsend,&length,ucEncrypt_type);
    if(ret == HUOHE_FAIL){
        gw_off_sucess=2;
        LOG(ERROR)<<GW_LOG<<"["<<_gw_cmd<<"]  指令 加密失败";
        return ;
    } else
    {

        cmdlength=length;

        LOG(INFO)<<GW_LOG<<"["<<_gw_cmd<<"] 加密后的数据长度 : "<<cmdlength;

    }

    read_flag=2;
    //hurt_time.stop();
    write_io.set<Gw_Task_Process,&Gw_Task_Process::write_callback>(this);
    write_io.start(listenfd,EV_WRITE);
}