//
// Created by hantao on 18-12-15.
//

#ifndef GJ_TESTPLATFORM_PARSEJSONFILESCENARIO_H
#define GJ_TESTPLATFORM_PARSEJSONFILESCENARIO_H

#include "include/pub.h"
//#include "common/config.h"
class Scenario{

private:
    string _comment;
    string scenarioName;//设备描述
    string GatewayIDRange;//网关范围
    string LockIDRange;//门锁范围

    string scenarioNameFile;
    int devTotalNum;


public:
    Scenario();

    ~Scenario();

    void setFilePathGwOrLock(string filepath);

    int getScenarioName(string &m_GatewayIDRange,string &m_LockIDRange,map<string,int > &scenNum);
};


#endif //GJ_TESTPLATFORM_PARSEJSONFILESCENARIO_H
