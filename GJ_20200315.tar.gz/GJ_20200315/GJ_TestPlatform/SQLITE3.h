//
// Created by hantao on 19-4-25.
//

#ifndef GJ_TESTPLATFORM_SQLITE3_H
#define GJ_TESTPLATFORM_SQLITE3_H

#include "include/pub.h"

namespace SQLITE3{


    int callback_open(void *NotUsed,int argc,char **argv,char **azColName);

    int callback_insert(void *NotUsed,int argc,char **argv,char **azColName);

    int callback_del(void *NotUsed,int argc,char **argv,char **azColName);
    int OpenDB(sqlite3 *db);
    int CreateDBTable(sqlite3 *db,char *sql);
    int InsertDB(sqlite3 *db,char *sql);
    int DeleteDB(sqlite3 *db);
    void CloseDB(sqlite3 *db);


    int InitDB(sqlite3 *db);
    int InitTable(sqlite3 *db);
}
#endif //GJ_TESTPLATFORM_SQLITE3_H
