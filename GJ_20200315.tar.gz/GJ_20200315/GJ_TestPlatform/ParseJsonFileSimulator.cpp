//
// Created by hantao on 18-12-15.
//
#include "ParseJsonFileSimulator.h"

TotalFile::TotalFile(string file)
{

        simulatorName=file;
        getJsonFileName();
}
TotalFile::~TotalFile()
{

}

void TotalFile::getJsonFileName()
{

        string string1;
        int ret = getSimulatorParam(simulatorName,string1);
        if (ret < 0){
            LOG(ERROR)<<"获取总体文件信息["<<simulatorName<<"失败";
            return;
        }
        //LOG(INFO)<<"获取总体文件信息成功";

        Json::Reader reader;
        Json::Value value;

        reader.parse(string1,value);

        Json::Value value1;
        value1=value["JSONScripts"];
        scenarioFile=value1["scenario"].asString();
        lockFile=value1["lock"]["lock"].asString();
        gwFile=value1["gw"]["gw"].asString();
}

string TotalFile::getScenarioFile()
{
        return  scenarioFile;
}

string TotalFile::getGWFile()
{
        return gwFile;
}

string TotalFile::getLockFile()
{
        return  lockFile;
}



