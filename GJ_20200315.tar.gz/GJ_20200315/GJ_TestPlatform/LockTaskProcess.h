//
// Created by hantao on 18-12-15.
//

#ifndef GJ_TESTPLATFORM_LOCKTASKPROCESS_H
#define GJ_TESTPLATFORM_LOCKTASKPROCESS_H

#include "include/pub.h"
#include "common/config.h"
#include "include/LockMsgGw.h"
#include "SQLITE3.h"
using namespace SQLITE3;
class Lock_Task_Process{
private:
    string gw_lock_ID;
    string gw_id;
    ev::timer lock_timer;
    int start_time;
    int _timeInterval;

    //map<string,map<string,string>> lockid_data; //门锁初略数据
    map<string,string>lock_data;//发生的数据
    map<string,string>RST_DATA;

    queue<DATA>lockData;

    string LOCK_LOG;

     queue<MYLOCK_NODE_FRAME> *queueData;
    //queue<MYLOCK_NODE_FRAME> *taskWriteData;

    //map<string,MYLOCK_NODE_FRAME> *queueData;
    map<u32 ,MYLOCK_NODE_FRAME> *taskWriteData;

    ev::timer sDataTimer;
    MYLOCK_NODE_FRAME requestData;

    u32 gwInternetID;
    u32 lockInternetID;
    u16 ID16;


    u32 auth_data;
    u32 lock_random_data;
    u32 id_lock_random_data;
    u32 lock_passwd_key[4];

    int onLineFlag;
    int onLineAck;
    ev::timer onLineTimer;

    ev::timer PwrTimer;

    u8  passwd[30][16];

    int lock_fist_line;
    sqlite3 *db;
private:
    void lock_callback(ev::timer &m_timer,int revents);
    int getLockMsg(string &str);
    int  LockTaskData();//讲指令解析出来，是否需要和网关交互


    void setTaskQueueData(MYLOCK_NODE_FRAME &mylockNodeFrame);
    void getRequestData();

    void sDataTimer_callback(ev::timer &m_timer,int revents);
    int requestDataParse();

    void requestGw();

    //定时上报门锁在线
    void OnLineLock(ev::timer &w,int revents);
    //定时上报电量
    void PowerLock(ev::timer &w,int revetns);

    void  RestartLock();
public:
    Lock_Task_Process();
    ~Lock_Task_Process();
    void setStartTime(int &time);
    void setGwLockId(string ID,string gwid);

    int setLockData(queue<DATA>&s_data);
    void setQueueData(queue<MYLOCK_NODE_FRAME> *queueData,map<u32 ,MYLOCK_NODE_FRAME>*taskWriteData);

    int Lock_Task_Porcess_start();


};
#endif //GJ_TESTPLATFORM_LOCKTASKPROCESS_H
