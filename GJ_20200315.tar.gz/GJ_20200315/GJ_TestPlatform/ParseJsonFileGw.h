//
// Created by hantao on 18-12-15.
//

#ifndef GJ_TESTPLATFORM_PARSEJSONFILEGW_H
#define GJ_TESTPLATFORM_PARSEJSONFILEGW_H

#include "include/pub.h"
#include "common/config.h"
class GwDevice{

private:
    string divName;
public:
    string _comment;
    string deviceName;
    string deviceType;
    string description;



    string actionSeriesName;
    string startTime;
    string repeatMode;
    string params;


    string divFilePath;




public:

    queue<DATA> GW_DATA;
    map<string,string>gwAndLock;

    int lockTotal;
    GwDevice();

    ~GwDevice();

    void setDivMsg(string filepath,string divName);

    int getDiveceACTION();
};


#endif //GJ_TESTPLATFORM_PARSEJSONFILEGW_H
