#!/bin/sh

killall -9 GJ_TestPlatform

sleep 3
echo `ps -ef|grep GJ_TestPlatform`
