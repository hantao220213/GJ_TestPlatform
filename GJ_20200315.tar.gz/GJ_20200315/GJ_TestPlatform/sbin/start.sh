#!/bin/sh
chmod +x ../bin/Debug/GJ_TestPlatform 
../bin/Debug/GJ_TestPlatform >/dev/null 2>&1 &
#../bin/Debug/GJ_TestPlatform >/dev/null

sleep 3
echo toatal+ `ps -ef |grep GJ_TestPlatform | wc -l`
echo `ps -ef |grep GJ_TestPlatform |awk '{print  $8}'`
