//
// Created by hantao on 18-12-15.
//

#include "LockTaskProcess.h"

Lock_Task_Process::Lock_Task_Process() {
    gw_lock_ID="";
    start_time=0;
    _timeInterval=0;
    LOCK_LOG="";

    gwInternetID=0;
    lockInternetID=0;
    ID16=0;

    onLineFlag=0;
    onLineAck=0;
}
Lock_Task_Process::~Lock_Task_Process() {
    sqlite3_close(db);
}

void Lock_Task_Process::setGwLockId(string ID,string gwid)
{
    gw_lock_ID=ID;
    gw_id=gwid;
    LOCK_LOG= "["+gwid+"->"+ID+"]";
    gwInternetID=HostIpToNet(gwid);
    lockInternetID=HostIpToNet(ID);
    //ID16=(HostIpToNet(ID));
    ID16=lockInternetID;
}

void Lock_Task_Process::setStartTime(int &time) {

    start_time=time;
}

int Lock_Task_Process::setLockData(queue<DATA> &lockdata)
{
    if (lockdata.empty()) {
        LOG(ERROR) << LOCK_LOG<<"数据不存在";
        return -1;
    }

    lockData=lockdata;
}


int Lock_Task_Process::getLockMsg(string &src) {

    if (src.empty()){
        LOG(ERROR)<< LOCK_LOG<<"指令数据为空，无法指令解析";
        return -1;
    }
    Json::Reader reader;
    Json::Value value;
    reader.parse(src,value);
    int cn=0;
    for (int i = 0; i < 10; ++i) {
        char buf[8]={'\0'};
        char c;
        for (int j = 0; j <20 ; ++j) {
            if (j>20){
                c=char(55+j);
                sprintf(buf,"%s%d%c","0x",i,c);
            } else{
                sprintf(buf,"%s%d%d","0x",i,j);
            }
            if (value[cn][buf].isNull())
                continue;
            string cmdData= value[cn][buf].toStyledString();
           // LOG(INFO)<<" cmd : "<<buf<< " cmddata : " <<cmdData;
            lock_data.insert(pair<string,string>(buf,cmdData));

        }

    }
    RST_DATA=lock_data;
}

int Lock_Task_Process::LockTaskData() {

//    LOG(INFO)<<LOCK_LOG<<"---------LockTaskData start----------- ";
    //获取指令的数据
    if (lock_data.empty()){
//        LOG(ERROR)<<LOCK_LOG<<" 无指令数据可以获取 ";
        return -1;
    }
    string Data="";
    MYLOCK_NODE_FRAME lockNodeFrame;
    memset(&lockNodeFrame,0,sizeof(LOCK_NODE_FRAME));

    map<string,string>::iterator it=lock_data.begin();

    string cmd=it->first;
    string cmdData=it->second;
    LOG(INFO)<< " CMD :" <<cmd;
    //LOG(INFO)<< " CMDDATA : "<<cmdData;
    Json::Reader reader;
    Json::Value value;
    reader.parse(cmdData,value);

    int cn=0;
    if (cmd == "0x12"){

        //1.解析交易的具体字段值，并进行赋值
        //2.若有其他操作可直接进行其他操作
        //3.是否需要和网关进行通信，给网关数据队列中放入数据，或者从门锁数据队列中获取数据

    }
    else if(cmd == "0x40")
    {

        string joinin_flag=value["joinin_flag"].asCString();
        string hard_ver= value["hard_ver"].asCString();
        string soft_ver= value["soft_ver"].asCString();
        string lock_type= value["lock_type"].asCString();
        string lock_factory = value["lock_factory"].asCString();


        Join_Req joinReq;
        memset(&joinReq,0,sizeof(Join_Req));

        joinReq.lock_id=HostIpToNet(gw_lock_ID);
        LOG(INFO)<<LOCK_LOG<<"joinReq.lock_id : "<<joinReq.lock_id;

        //joinReq.joinin_flag=0;

        joinReq.hard_ver=hard_ver[0];

        joinReq.soft_ver=soft_ver[0];
        joinReq.lock_type=lock_type[0];
        joinReq.lock_factory=lock_factory[0];
        joinReq.trans_lock_key=0;
        joinReq.lock_random_data=atoi(MyRand(4).c_str());

        u32 curr_time=getCurrentTime();
        memset(lock_passwd_key,0x00,sizeof(lock_passwd_key));

        LOG(INFO)<< LOCK_LOG<<"curr_time : "<<curr_time;
        LOG(INFO)<< LOCK_LOG <<"lockInternetID :  "<<lockInternetID;

        /*
        sqlite3 *db1;
        char *h=getenv("HOME");
        char path[1024]={'\0'};
        sprintf(path,"%s%s",h,GW_DB_DIR);


        char sql[2048]={'\0'};
        int rc = sqlite3_open(path,&db1);
        if(rc < 0)
        {
            LOG(ERROR)<<" 创建gwDatabase.db数据库失败!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!1";
            return -1;
        }
        else
        {
            LOG(INFO)<<"打开gwDatabase.db数据库成功";
        }
        */

        /*
        string path = getdir()+"DB/gwDatabase.db";

        int ret = sqlite3_open(path.c_str(),&db);
        if(ret < 0)
        {
            LOG(ERROR)<<" 创建gwDatabase.db数据库失败!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!1";
            return -1;
        }
        */
        char tsql[1024]={'\0'};
        char *ssql="select count(*) as count from lock_id_key where status=1 and lock_id='%s';";
        sprintf(tsql,ssql,gw_lock_ID.c_str());
        char **pazReuslt=NULL;
        int nrow=0;
        int nclomun=0;
        char *zErrMsg=NULL;
        int rc= sqlite3_get_table(db,tsql,&pazReuslt,&nrow,&nclomun,&zErrMsg);
        if(rc != SQLITE_OK)
        {
            sqlite3_free(zErrMsg);
            LOG(INFO)<<LOCK_LOG<<" 门锁密钥不存在，首次接入";
            lock_fist_line=0;
        } else
        {
            lock_fist_line=atoi(pazReuslt[1]);
            sqlite3_free_table(pazReuslt);

        }
        LOG(INFO)<<LOCK_LOG<<" 获取门锁密钥完成.......................lock_fist_line: "<<lock_fist_line;
        KEY_NULL:
        if (lock_fist_line == 0)
        {
            reinit_key_passwd(curr_time,lockInternetID,lock_passwd_key);
            LOG(INFO)<<LOCK_LOG<<" insert lock start.............................1...........";
            char *lsql="insert into lock_id_key (lock_id,u32_id,key,status) values('%s',%d,'%s',%d);";

            sprintf(tsql,lsql,gw_lock_ID.c_str(),HostIpToNet(gw_lock_ID),lock_passwd_key,1);
            LOG(INFO)<<LOCK_LOG<<" insert lock start...........................2.............";

            LOG(INFO)<<LOCK_LOG<<"=======================pwd:"<<tsql;
            InsertDB(db,tsql);
        } else{
            ssql="select key from lock_id_key where lock_id='%s' and status=1;";
            sprintf(tsql,ssql,gw_lock_ID.c_str());
            rc=sqlite3_get_table(db,tsql,&pazReuslt,&nrow,&nclomun,&zErrMsg);
            if(rc != SQLITE_OK)
            {
                LOG(INFO)<<LOCK_LOG<<"获取门锁128位随机数失败,首次接入";
                sqlite3_free(zErrMsg);
                DeleteDB(db);
                lock_fist_line=0;
                goto KEY_NULL;
            }
            memcpy(lock_passwd_key,(u32*)pazReuslt[1],32);
            sqlite3_free_table(pazReuslt);
        }
        //sqlite3_close(db);

        if(lock_fist_line == 0)
        {
            joinReq.joinin_flag=0;
        } else{
            joinReq.joinin_flag=1;
        }
        LOG(INFO)<<LOCK_LOG<<" insert lock start.............................3...........";

        GenAuthKey(lockInternetID,lock_passwd_key,joinReq.lock_random_data,&(joinReq.id_lock_random_data),CHECK_ADD_LOCK_KEY);

        //joinReq.id_lock_random_data=0;
        joinReq.lock_factory=0;

        LOG(INFO)<<LOCK_LOG<<"gwInternetID: "<<gwInternetID;
        LOG(INFO)<<LOCK_LOG<<"lockInternetID : "<<lockInternetID;
        LOG(INFO)<<LOCK_LOG<<"joinReq.lock_random_data :"<<joinReq.lock_random_data;
        LOG(INFO)<<LOCK_LOG<<"joinReq.id_lock_random_data : "<<joinReq.id_lock_random_data;


        lockNodeFrame.dst_id=(HostIpToNet(gw_id));
        lockNodeFrame.data_len= sizeof(Join_Req);//(4+1+1+1+1+1+4+4+4+1); //atoi(num2str(sizeof(Join_Req)).c_str());
        lockNodeFrame.crc8=0;
        lockNodeFrame.src_id=(HostIpToNet(gw_lock_ID));
        lockNodeFrame.data_type=0x40;
        lockNodeFrame.data_label=0;
        memcpy(lockNodeFrame.Data,(char  *)&joinReq,sizeof(Join_Req));

        LOG(INFO)<<LOCK_LOG<<" LEN : "<<sizeof(Join_Req);


        char print[2]={'\0'};
        string s_print="";
        print[2]={'\0'};
        s_print="";
        for (int i = 0; i < sizeof(Join_Req); ++i) {
            sprintf(print,"%02x",lockNodeFrame.Data[i]);
            s_print=s_print+print;
        }
        LOG(INFO)<<LOCK_LOG <<" lockNodeFrame data : "<<s_print;
        LOG(INFO)<<LOCK_LOG<<"dst: :"<<lockNodeFrame.src_id;

        setTaskQueueData(lockNodeFrame);
    }
    else if (cmd == "0x1E"){
        string info_type=value["info_type"].asCString();
        string info_len =value["info_len"].asCString();
        string info=value["info"].asCString();

        Lock_Info lockInfo;
        memset(&lockInfo,0x00,sizeof(Lock_Info));
        lockInfo.info_type=info_type[0];
        lockInfo.info_len=info_len[0];
        if(info_type == "4")
        {
            Lock_Pwr lockPwr;
            memset(&lockPwr,0x00,sizeof(Lock_Pwr));
            lockPwr.pwr_cap_time=getCurrentTime();
            lockPwr.pwr_data=80;

            memcpy(lockInfo.info,(u8*)&lockPwr,sizeof(Lock_Pwr));
        }
        else if( info_type == "3"|| info_type == "2"||info_type == "1")
        {
            int len=atoi(info_len.c_str());
            memcpy(lockInfo.info,info.c_str(),len);
        }
        else{

        }

    }

    else if(cmd == "0x22")
    {
        MYLOCK_NODE_FRAME mylockNodeFrame;
        memset(&mylockNodeFrame,0x00,sizeof(MYLOCK_NODE_FRAME));
        mylockNodeFrame.dst_id=gwInternetID;
        mylockNodeFrame.data_len=1;
        char p[2]="0";
        mylockNodeFrame.crc8=CRC8_Table((u8 *)p,1);
        mylockNodeFrame.src_id=lockInternetID;
        mylockNodeFrame.data_type=0x22;
        mylockNodeFrame.data_label=0;
        mylockNodeFrame.Data[0]='0';
        setTaskQueueData(mylockNodeFrame);

    }

    else
    {
        LOG(INFO)<<LOCK_LOG<<"门锁没有此指令 ："<<cmd;
        return -2;
    }
    lock_data.erase(cmd);
    return  0;
}


void Lock_Task_Process::lock_callback(ev::timer &m_timer, int revents) {
//    LOG(INFO) << LOCK_LOG << " 开始操作执行................";

    if (lockData.empty())
    {
       // LOG(INFO)<<LOCK_LOG<<" 无任何数据";
        lock_timer.stop();
        return;
    } else{
        DATA AC=lockData.front();
        string mycmd=AC.action;
        string cmdMsg=AC.data;
        _timeInterval=atoi(AC.timeInterval.c_str());
        LOG(INFO)<<LOCK_LOG<<"cmd : "<<mycmd;

        if (mycmd == "on")
        {
            getLockMsg(cmdMsg);
            sDataTimer.set<Lock_Task_Process,&Lock_Task_Process::sDataTimer_callback>(this);
            sDataTimer.start(0,1);

            onLineTimer.set<Lock_Task_Process,&Lock_Task_Process::OnLineLock>(this);
            onLineTimer.start(0,30);

            PwrTimer.set<Lock_Task_Process,&Lock_Task_Process::PowerLock>(this);
            PwrTimer.start(0,60*2);

        } else if(mycmd == "off")
        {


        } else{

        }

        lockData.pop();

    }


}

int Lock_Task_Process::Lock_Task_Porcess_start() {

    string path = getdir()+"DB/gwDatabase.db";

    int ret = sqlite3_open(path.c_str(),&db);
    if(ret < 0)
    {
        LOG(ERROR)<<" 创建gwDatabase.db数据库失败!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!1";
        return -1;
    }

    u32 curr_time=getCurrentTime();
    reinit_key_passwd(curr_time,lockInternetID,lock_passwd_key);
    lock_timer.set<Lock_Task_Process,&Lock_Task_Process::lock_callback>(this);
    lock_timer.start(1,0);
}

void Lock_Task_Process::setTaskQueueData(MYLOCK_NODE_FRAME &mylockNodeFrame)
{
    queueData->push(mylockNodeFrame);
}
void Lock_Task_Process::setQueueData(queue<MYLOCK_NODE_FRAME> *queueData,map<u32 ,MYLOCK_NODE_FRAME>*taskWriteData)
{
    this->queueData=queueData;
    this->taskWriteData=taskWriteData;
}

void Lock_Task_Process::sDataTimer_callback(ev::timer &m_timer, int revents)
{
    if(LockTaskData()!=0)
    {
        getRequestData();
    }

}
void Lock_Task_Process::getRequestData()
{

//    LOG(INFO)<<LOCK_LOG<<"门锁深度--------------------:"<<taskWriteData->size();

    if (taskWriteData->empty())
    {
        onLineFlag=1;

        return;
    }

    onLineFlag=0;
    map<u32 ,MYLOCK_NODE_FRAME>::iterator it=taskWriteData->find(lockInternetID);
    if(it == taskWriteData->end())
    {
        LOG(INFO)<<LOCK_LOG<<"无此门锁应答数据处理";
        return;
    }
    memset(&requestData,0x00,sizeof(MYLOCK_NODE_FRAME));
    memcpy((char *)&requestData,(char *)&(it->second),sizeof(MYLOCK_NODE_FRAME));

    taskWriteData->erase(lockInternetID);

    if(requestDataParse() !=0)
    {
        LOG(ERROR)<<LOCK_LOG<<" 网关应答数据错误";
    }

    //LOG(INFO)<<LOCK_LOG<<"--------------------------getRequestData sucess--------------------";
    return;
}

int Lock_Task_Process::requestDataParse()
{
    LOG(INFO)<<LOCK_LOG<<" requestDataParse  data ----------: "<<requestData.src_id;

    LOG(INFO)<<LOCK_LOG<<"门锁指令 : "<<requestData.data_type;
    if (requestData.data_type==0x36)
    {
        LOG(INFO)<<LOCK_LOG<<" ------->远程开门";
        Open_door_info cmd36;
        memset(&cmd36,0x00,sizeof(Open_door_info));
        memcpy(&cmd36,(Open_door_info *)requestData.Data,requestData.data_len);

    }
    else if(requestData.data_type ==0x34)
    {
        LOG(INFO)<<LOCK_LOG<<"---->删除门锁普通密码";
        requestGw();
    }
    else if(requestData.data_type == 0x32)
    {
        LOG(INFO)<<LOCK_LOG<<"----->删除门锁算法密钥";
        requestGw();
    }
    else if(requestData.data_type == 0x12)
    {
        LOG(INFO)<<LOCK_LOG<<"---->增加或修改密码";

        //应答网关下发的请求
        requestGw();
    }
   else if(requestData.data_type == 0x18)
    {
        LOG(INFO)<<LOCK_LOG<<"----->网关发送时间";

    }else if(requestData.data_type == 0x20)
    {
        LOG(INFO)<<LOCK_LOG<<"---->门锁查询密码应答";
        requestGw();

    }else if(requestData.data_type == 0x24||requestData.data_type ==0x26)
    {
        LOG(INFO)<<LOCK_LOG<<"---->网关查询门锁数据";

        requestGw();
    } else if(requestData.data_type == 0x3A)
    {
        LOG(INFO)<<LOCK_LOG<<"----->门锁重置，复位指令";
    } else if(requestData.data_type==60)
    {
        LOG(INFO)<<LOCK_LOG<<"----->门锁重启开始";
        requestGw();
    }
    else if(requestData.data_type==0x42)
    {
        LOG(INFO)<<LOCK_LOG<<"----->门锁接入";
        //是否同意门锁接入指令
        Inform_Joinin informJoinin;
        memset(&informJoinin,0x00,sizeof(Inform_Joinin));
        memcpy(&informJoinin,(Inform_Joinin *)requestData.Data,requestData.data_len);

        char tmp[2]={'\0'};
        sprintf(tmp,"%02x",informJoinin.status);
        int status=atoi(tmp);
        if(status == 0)
        {
            LOG(INFO)<<LOCK_LOG<<"同意门锁接入,status : "<<status;
        } else if(status == 1)
        {
            LOG(INFO)<<LOCK_LOG<<"拒绝门锁接入,status : "<<status;
            return status;
        } else
        {
            LOG(INFO)<<LOCK_LOG<<"等待接入门锁接入,status : "<<status;
            return status;
        }
        requestGw();
    }
    else if(requestData.data_type==0x02)
    {
        LOG(INFO)<<LOCK_LOG<<"------->普通应答指令";
        requestGw();
    }

    LOG(INFO)<<LOCK_LOG<<"-------requestDataParse  sucess-------";
    return 0;
}


void Lock_Task_Process::requestGw()
{

   // LOG(INFO)<<LOCK_LOG<<"门锁指令 : "<<requestData.data_type << "0X3C : "<<0x3c;

    MYLOCK_NODE_FRAME mylockNodeFrame;
    memset(&mylockNodeFrame,0x00,sizeof(MYLOCK_NODE_FRAME));

    char tmp1[2];
    string string1="";
    switch (requestData.data_type)
    {
        case 0x32:
        case 0x34:
        case 0x12:
        case 0x20:
            SetPwd_Result setPwdResult;
            memset(&setPwdResult,0x00,sizeof(SetPwd_Result));

            SETPWD_info setpwdInfo;
            memset(&setpwdInfo,0x00,sizeof(SETPWD_info));
            memcpy(&setpwdInfo,requestData.Data,sizeof(SETPWD_info));



            setPwdResult.pwd_status=0;
            mylockNodeFrame.data_type=0x30;
            mylockNodeFrame.src_id=lockInternetID;
            mylockNodeFrame.dst_id=gwInternetID;
            mylockNodeFrame.data_label=0;
            mylockNodeFrame.crc8=CRC8_Table((u8 *)&setPwdResult,1);
            mylockNodeFrame.data_len=1;
            setTaskQueueData(mylockNodeFrame);
            break;
        case 0x24:
        case 0x26:
            Query_Lock_Info queryLockInfo;
            memset(&queryLockInfo,0x00,sizeof(Query_Lock_Info));
            memcpy(&queryLockInfo,(Query_Lock_Info *)requestData.Data,sizeof(Query_Lock_Info));

            Query_Lock_Info_ack queryLockInfoAck;
            memset(&queryLockInfoAck,0x00,sizeof(Query_Lock_Info_ack));
            queryLockInfoAck.query_type=queryLockInfo.query_type;


            switch (queryLockInfo.query_type)
            {
                case 0x00:
                case 0x01:
                case 0x02:
                case 0x03:
                case 0x04:
                case 0x05:
                case 0x06:
                case 0x1e:
                    LOG(INFO)<<LOCK_LOG<<"门锁密码查询";
                    break;
                case 0x30:
                    LOG(INFO)<<LOCK_LOG<<"门锁软件版本号";
                    //memcpy(queryLockInfoAck.ack_data,"30",2);
                    queryLockInfoAck.ack_data[0]=0x30;
                    break;
                case 0x31:
                    LOG(INFO)<<LOCK_LOG<<"门锁硬件版本号";
                    queryLockInfoAck.ack_data[0]=0x31;
                    break;
                case 0x32:
                    Lock_time lockTime;
                    memset(&lockTime,0x00,sizeof(Lock_time));
                    lockTime.lock_time=getCurrentTime();
                    lockTime.ms_time=getCurrentTime()/1000;
                    memcpy(queryLockInfoAck.ack_data,(char *)&lockTime,sizeof(Lock_time));
                    break;
                case 0x33:
                    Work_Channel workChannel;
                    memset(&workChannel,0x00,sizeof(Work_Channel));
                    workChannel.channel_data=9;
                    workChannel.start_slice=0;
                    workChannel.end_slice=255;
                    memcpy(queryLockInfoAck.ack_data,(char *)&workChannel,sizeof(Work_Channel));
                    break;
                case 0x40:
                    Lock_Pwr_Charge lockPwrCharge;
                    memset(&lockPwrCharge,0x00,sizeof(Lock_Pwr_Charge));
                    lockPwrCharge.pwr_data=0xfe;
                    lockPwrCharge.pwr_cap_time=getCurrentTime();
                    memcpy(queryLockInfoAck.ack_data,(char *)&lockPwrCharge,sizeof(Lock_Pwr_Charge));
                    break;
                case 0x41:
                    queryLockInfoAck.ack_data[0]=1;
                    break;
                case 0x42:
                    queryLockInfoAck.ack_data[0]=1;
                    break;
                case 0x44:
                    queryLockInfoAck.ack_data[0]=1;
                    break;

                default:
                    break;

            }
            mylockNodeFrame.data_type=queryLockInfo.query_type;
            mylockNodeFrame.src_id=lockInternetID;
            mylockNodeFrame.dst_id=gwInternetID;
            mylockNodeFrame.data_label=0;
            mylockNodeFrame.crc8=CRC8_Table((u8 *)&setPwdResult,1);
            mylockNodeFrame.data_len=sizeof(Query_Lock_Info_ack);
            memcpy(mylockNodeFrame.Data,(u8 *)&queryLockInfoAck,sizeof(Query_Lock_Info_ack));

            setTaskQueueData(mylockNodeFrame);
            break;

        case 0x42:
            Inform_Joinin cmd42;
            memset(&cmd42,0x00,sizeof(Inform_Joinin));
            memcpy(&cmd42,requestData.Data,requestData.data_len);
            auth_data=cmd42.auth_data;


            Lock_Key lockKey;
            memset(&lockKey,0,sizeof(Lock_Key));
            //CheckAuthKey(lockInternetID,lock_passwd_key,auth_data,lockKey.check_auth_data,CHECK_ADD_LOCK_KEY);

            UINT32 check_auth_data;
            GenAuthKey(lockInternetID,lock_passwd_key,auth_data,&check_auth_data,CHECK_REMOTE_DOOR);

            lockKey.check_auth_data=check_auth_data;
            LOG(INFO)<<LOCK_LOG<<" auth_data : "<<auth_data;
            LOG(INFO)<<LOCK_LOG<<"lock_passwd_key: "<<lock_passwd_key;
            LOG(INFO)<<LOCK_LOG<<"lockKey.check_auth_data : "<<lockKey.check_auth_data;

            lockKey.lock_key_len=16;
            memcpy(lockKey.lock_key,(u8 *)lock_passwd_key,16);

            LOG(INFO)<<LOCK_LOG<<".lock_key_len : "<<sizeof(lockKey.lock_key);
            LOG(INFO)<<LOCK_LOG<<"loclockKeykKey.lock_key : "<<lockKey.lock_key;
            for (int j = 0; j <16 ; ++j) {
                sprintf(tmp1,"%02x",lockKey.lock_key[j]);
                string1=string1+tmp1;
            }
            LOG(INFO)<<LOCK_LOG<<" lock_key ["<<string1<<"]";

            mylockNodeFrame.data_type=0x48;
            mylockNodeFrame.src_id=lockInternetID;
            mylockNodeFrame.dst_id=gwInternetID;
            mylockNodeFrame.data_label=0;
            mylockNodeFrame.crc8=CRC8_Table((u8 *)&lockKey,1);
            mylockNodeFrame.data_len=sizeof(Lock_Key);
            memcpy(mylockNodeFrame.Data,(u8 *)&lockKey,sizeof(Lock_Key));
            setTaskQueueData(mylockNodeFrame);



            LOG(INFO)<<LOCK_LOG<<"组装上送门锁密钥数据完成";
            break;
        case 0x02:
            RC_CMD_ACK cmd02;
            memset(&cmd02,0x00,sizeof(RC_CMD_ACK));
            if(onLineAck == 1)
            {
                Upload_LockRssi cmd31;
                memset(&cmd31,0x00,sizeof(Upload_LockRssi));
                cmd31.rssi_level=4;
                mylockNodeFrame.data_type=0x31;
                mylockNodeFrame.src_id=lockInternetID;
                mylockNodeFrame.dst_id=gwInternetID;
                mylockNodeFrame.data_label=0;
                mylockNodeFrame.crc8=CRC8_Table((u8 *)&cmd31,1);
                mylockNodeFrame.data_len=sizeof(Upload_LockRssi);
                setTaskQueueData(mylockNodeFrame);
                onLineAck=0;
            }
            break;
        case 0x3c:
            RestartLock();
            break;
        default:
            break;
    }
}

void Lock_Task_Process::OnLineLock(ev::timer &w, int revents)
{
    if(onLineFlag == 1)
    {
        MYLOCK_NODE_FRAME mylockNodeFrame;
        Lock_Info cmd1E;
        memset(&mylockNodeFrame,0x00,sizeof(MYLOCK_NODE_FRAME));
        memset(&cmd1E,0x00,sizeof(Lock_Info));
        cmd1E.info_type=0;
        cmd1E.info_len=0;

        mylockNodeFrame.data_type=0x1E;
        mylockNodeFrame.src_id=lockInternetID;
        mylockNodeFrame.dst_id=gwInternetID;
        mylockNodeFrame.data_label=0;
        mylockNodeFrame.crc8=CRC8_Table((u8 *)&cmd1E,1);
        mylockNodeFrame.data_len=sizeof(Lock_Info);
        memcpy(mylockNodeFrame.Data,(u8 *)&cmd1E,sizeof(Lock_Key));
        setTaskQueueData(mylockNodeFrame);
        onLineAck=1;
    }
}

void Lock_Task_Process::PowerLock(ev::timer &w, int revetns)
{
    //门锁在线上报门锁电量
    if (onLineFlag == 1)
    {
        Lock_Pwr lockPwr;
        Lock_Info lockInfo;
        MYLOCK_NODE_FRAME mylockNodeFrame;
        memset(&lockPwr,0x00,sizeof(Lock_Pwr));
        memset(&lockInfo,0x00,sizeof(Lock_Info));
        memset(&mylockNodeFrame,0x00,sizeof(MYLOCK_NODE_FRAME));

        lockPwr.pwr_data='9';
        lockPwr.pwr_cap_time=getCurrentTime();

        lockInfo.info_type=4;
        lockInfo.info_len=sizeof(Lock_Pwr);
        memcpy(&lockInfo.info,(u8*)&lockPwr,sizeof(Lock_Pwr));

        mylockNodeFrame.data_type=0x1E;
        mylockNodeFrame.src_id=lockInternetID;
        mylockNodeFrame.dst_id=gwInternetID;
        mylockNodeFrame.data_label=0;
        mylockNodeFrame.crc8=CRC8_Table((u8 *)&lockInfo,1);
        mylockNodeFrame.data_len=sizeof(Lock_Info);
        memcpy(mylockNodeFrame.Data,(u8 *)&lockInfo,sizeof(Lock_Key));
        setTaskQueueData(mylockNodeFrame);

        LOG(INFO)<<LOCK_LOG<<" 门锁上报自己的电量开始......................";
    }

}

void Lock_Task_Process::RestartLock()
{

    LOG(INFO)<<LOCK_LOG<<"++++++++++++++++++++++++++++++ 重启门锁开始+++++++++++++++++++++++++++++++++++";
    lock_data.clear();
    lock_data =RST_DATA;
    lock_timer.stop();
    sDataTimer.stop();
    onLineTimer.stop();
    PwrTimer.stop();

    auth_data=0;
    lock_random_data=0;
    id_lock_random_data=0;
    memset(&lock_passwd_key,0x00,sizeof(lock_passwd_key));
    onLineFlag=0;

    sDataTimer.set<Lock_Task_Process,&Lock_Task_Process::sDataTimer_callback>(this);
    sDataTimer.start(0,1);

    onLineTimer.set<Lock_Task_Process,&Lock_Task_Process::OnLineLock>(this);
    onLineTimer.start(0,20);

    PwrTimer.set<Lock_Task_Process,&Lock_Task_Process::PowerLock>(this);
    PwrTimer.start(0,60*2);


}