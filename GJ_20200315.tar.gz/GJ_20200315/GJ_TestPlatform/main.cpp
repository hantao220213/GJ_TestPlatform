
//#include "include/pub.h"
#include "TestPlatForm.h"
#include "SQLITE3.h"
//using namespace std;


/*
 * https://github.com/hantao220213/GJ_TestPlatform.git
 */
using  namespace SQLITE3;
#include "test_loop.h"


int main(int argc,char *argv[])
{
    if(InitGLog("GJ_TestPlatForm")<0){
        return -1;
    }
    sqlite3 *db;
    InitDB(db);

    InitTable(db);
    CloseDB(db);

#if 1

    TestPlatForm platForm;
    string jsonfile;

    //jsonfile=argv[1];
    jsonfile="simulator.json"; //测试
    platForm.setJsonFileName(jsonfile);
    platForm.run();

#endif


    while (1)
    {
        sleep(1);
    }

    //getchar();

    return 0;

}



