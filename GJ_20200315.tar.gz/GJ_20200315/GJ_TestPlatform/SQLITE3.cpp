//
// Created by hantao on 19-4-25.
//

#include "SQLITE3.h"

int SQLITE3::callback_open(void *NotUsed, int argc, char **argv, char **azColName) {
    LOG(INFO)<<"SELECT ONE  DATA START :---------------------------------------";
    for (int i = 0; i <argc ; ++i) {
        LOG(INFO)<<azColName[i]<<"="<<argv[i]?argv[i]:NULL;
    }
    LOG(INFO)<<"SELECT ONE  DATA END :---------------------------------------";
}

int SQLITE3::callback_insert(void *NotUsed, int argc, char **argv, char **azColName) {

    LOG(INFO)<<"INSERT ONE  DATA START :---------------------------------------";
    for (int i = 0; i <argc ; ++i) {
        LOG(INFO)<<azColName[i]<<"="<<argv[i]?argv[i]:NULL;
    }
    LOG(INFO)<<"INSERT ONE  DATA END :---------------------------------------";
}

int SQLITE3::callback_del(void *NotUsed, int argc, char **argv, char **azColName) {

    LOG(INFO)<<"DELETE ONE  DATA START :---------------------------------------";
    for (int i = 0; i <argc ; ++i) {
        LOG(INFO)<<azColName[i]<<"="<<argv[i]?argv[i]:NULL;
    }
    LOG(INFO)<<"DELTE ONE  DATA END :---------------------------------------";
}


void SQLITE3::CloseDB(sqlite3 *db) {
    sqlite3_close(db);
}

int SQLITE3::OpenDB(sqlite3 *db) {


    string path = getdir()+"DB/gwDatabase.db";

    char sql[2048]={'\0'};
    char zErrMsg[1024]={'\0'};
    int ret = sqlite3_open(path.c_str(),&db);
    if(ret < 0)
    {
        LOG(ERROR)<<" 创建gwDatabase.db数据库失败!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!1";
        return -1;
    }
    else
    {
        LOG(INFO)<<"打开gwDatabase.db数据库成功";
    }
    return 0;
}
int SQLITE3::CreateDBTable(sqlite3 *db,char *sql) {
    char *zErrMsg;
    int ret = sqlite3_exec(db,sql,callback_open,0,&zErrMsg);
    if(ret != SQLITE_OK)
    {
        LOG(INFO)<<"Create Table  ERROR: ["<<sql<<" ] error msg: "<<zErrMsg;
        return -1;
    }
    else
    {
        LOG(INFO)<<"Create Table SUCESS :["<<sql<<" ]";
    }
    return 0;
}
int SQLITE3::InsertDB(sqlite3* db,char *sql) {

    char *zErrMsg;
    int  ret = sqlite3_exec(db,sql,callback_insert,0,&zErrMsg);
    if (ret != SQLITE_OK)
    {
        LOG(INFO)<<"Insert table error : "<< zErrMsg;
        return -1;
    }
    LOG(INFO)<<"Insert table data sucess";
    return 0;
}

int SQLITE3::DeleteDB(sqlite3 *db) {
    char *zErrMsg;
    char sql[2048]={'\0'};
    int ret = sqlite3_exec(db,sql,callback_del,0,&zErrMsg);
    if(ret != SQLITE_OK)
    {
        LOG(INFO)<<"delete error : "<<sql;
        return -1;
    }
    return 0;
}

int SQLITE3::InitDB(sqlite3 *db) {
    if(OpenDB(db)<0)
    {
        LOG(INFO)<< "create sqlite3 db failed";
        return -1;
    }
    return 0;
}
int SQLITE3::InitTable(sqlite3 *db) {
    char *sql="create table gw_id_key(gw_id char(64) primary key not null ,u32_id int, key char(128),status int);";
    if(CreateDBTable(db,sql)<0)
    {
        LOG(INFO)<<" 执行 :"<<sql<<" 失败";
    }
    sql="create table lock_id_key(lock_id char(64) primary key not null,u32_id int,key char(128) not null,status int);";
    if(CreateDBTable(db,sql) < 0)
    {
        LOG(INFO)<<" 执行 :"<<sql<<" 失败";
    }
    return 0;
}