//
// Created by hantao on 19-2-21.
//

#ifndef GJ_TESTPLATFORM_LOCKMSGGW_H
#define GJ_TESTPLATFORM_LOCKMSGGW_H



#define   RC_CMD_LOCK_REPORT_DATA          0x1E

extern "C"{
typedef unsigned int u32;
typedef unsigned short int u16;
typedef unsigned char u8;

struct MYLOCK_NODE_FRAME {
    u16		dst_id;				//目的ID，0xFFFF：广播地址
    u8		data_len;				//数据长度
    u8		crc8;
    u16		src_id;				//源ID
    u8		data_type;			//数据类型
    u8		data_label;			//帧标签
    u8		Data[28];		//数据，最多28字节
}__attribute__ ((packed));


#define  rc_cmd_ack 0x02
struct  RC_CMD_ACK
{
    u32 status;
}__attribute__ ((packed)) ;

#define RC_CMD_UPLOAD_LOCKRSSI 0x31;
struct Upload_LockRssi{
    u8 rssi_level;
};

#define   RC_CMD_OPEN_DOOR      0x36		//远程开门指令
struct Open_door_info{
    u8	open_door_type;				//加密类型
    u32 rand_data;					//服务器发出的不重复随机数
    u32 check_rand_data;			//rand_data校验值
}__attribute__ ((packed));

#define   RC_CMD_DEL_PWD            	0x34
//删除指定密码或者有删除所有密码。
struct Del_PWD_info {
    u32  lock_id;			//门锁编码
    u8   pwd_cnt;			//密码数量；pwd_cnt ==0xFF：删除所有密码
    u8	 pwd_type[30];  //密码类型列表
}__attribute__ ((packed));

#define   RC_CMD_DEL_ALGORITHM_PWD    0x32
//删除指定算法密码或一次性密码。
struct DEL_ALGORITHM_PWD_info {
    u8 Algorim_otp;		// 0：算法密码，1：一次性密码
    u8	pwd_len;
    u8	pwd[256];
}__attribute__ ((packed));

#define   RC_CMD_SETPWD             0x12
struct SETPWD_info {
    u8	pwd_type;
    u8	pwd_len;
    u8	pwd[20];
    u32	 pwd_start_time;
    u32 pwd_end_time;
}__attribute__ ((packed));

#define	  RC_CMD_SETPWD_ACK			0x30
//0x30：删除、添加或修改密码应答
struct SetPwd_Result {
    u8	pwd_status;	//密码操作结果，0：成功， 1：失败
}__attribute__ ((packed));

#define   RC_CMD_TIME_INFO               0x18     //发送时间信息
struct 	Time_Info {
    u32	 s_time;			//以秒计时的格林尼治时间
    u16  ms_time;		//毫秒
}__attribute__ ((packed));

#define   RC_CMD_LOCK_REPORT_DATA          0x1E
struct 	Lock_Info {
    u8	 info_type ;				//门锁信息类型
    u8  info_len;
    u8  info[28];
}__attribute__ ((packed));

struct Lock_Pwr{
    u8 pwr_data;
    u32 pwr_cap_time;
}__attribute__ ((packed));

#define   RC_CMD_PWD_INQUIRY           0x22
struct PWD_info {
    u8	pwd_type;
    u8	pwd_len;
    u8	pwd[256];
    u32 pwd_start_time;
    u32 pwd_end_time;
}__attribute__ ((packed));

#define   RC_CMD_NODE_QUERY_LOCK             0x24
#define   RC_CMD_NODE_QUERY_LOCK_ACK        0x26

struct 	Query_Lock_Info {
    u8	query_type;
}__attribute__ ((packed));
struct	 Query_Lock_Info_ack {
    u8	 query_type;					//查询类型
    u8  ack_data[256];	//查询结果
}__attribute__ ((packed));


#define	RC_CMD_CHANGE_CHANNEL					0x28
struct 	Change_Channel {
    u8	work_channel;		//工作信道
    u8	start_slice;			//网关和门锁通信起始时隙
    u8  end_slice;		//网关和门锁通信结束时隙
}__attribute__ ((packed));

#define	  RC_CMD_SYS_RST_LOCK				0x3A
//0x3A：门锁进行重置。
struct	 Sys_RST_Lock_struct{
    u32  lock_id;			//门锁编码
    u8	rst_data[4];			//复位门锁数据
    u8	rst_data_check[4];	//复位门锁校验数据
}__attribute__ ((packed));

#define	  RC_CMD_RESTART_LOCK				0x3C
//0x3C：门锁重新启动，重新寻找网关，重新申请接入系统。
struct	 Sys_Restart_Lock {
    u32	 lock_id;		//门锁编码，32位
}__attribute__ ((packed));

#define	  RC_BROAD_CAST_INFO				0x3E
//0x3E：网关在广播信道广播的内容
struct Broad_Info{
    u32	 node_id; 			//网关编码
    u8	node_channel;    	//网关工作信道
    u8	start_slice;			//网关通信起始时隙
    u8	end_slice;	   		//网关通信结束时隙
    u32 time;              //格林尼治时间
    u16 ms_time;			   //毫秒
}__attribute__ ((packed));

#define	  RC_CMD_REQ_JOININ				0x40
struct Join_Req {
    u32 lock_id;     	//门锁编码，低位在前，高位在后
    u8	joinin_flag;		//标记门锁是否已接入系统，
//0：没有接入系统，1：已接入系统
//已接入系统的含义，服务器已确认收到门锁密钥
    u8	hard_ver;    	//主控板硬件版本
    u8	soft_ver;	    	//主控板嵌入式软件版本
    u8	lock_type;   	//门锁类型: 	A221      	0x01
    /*
    A121      	0x03
    A120T     	0x02 
    A220T     0x04
    A120Q     0x05
    A130      	0x20        
    A230      	0x30 
    F1     	0x10
    F1S       0x15
    F2       0x18
    F0        0x40 
    A821      0xA0
    A830S     	0xA1
    A830T     0xA2
     */
    u8	lock_factory; 	//门锁生产厂家
    u32	 trans_lock_key;   //门锁会话密钥，门锁会话密钥分成2部分，
//在门锁加入网关时生成，一部分由门锁生成，
//一部分由网关生成
    u32 lock_random_data;		//门锁端生产的不重复随机数，
//用于门锁被通知强制删除时，做身份确认
    u32 id_lock_random_data;	//门锁再次加入系统时，需要门锁身份认证，
    //用于验证门锁密钥
}__attribute__ ((packed));

#define	  RC_CMD_INFORM_JOININ				0x42
struct Inform_Joinin{
    u8 	status;		//是否同意门锁接入，0同意，1拒绝，2等待，
//3门锁已强制删除，请重新接入
    u32 trans_node_key; 	//门锁通信用密钥，此部分密钥是由网关生成的
    u8	lock_channel;	//门锁的工作信道
    u32 auth_data;	//门锁验证身份数据，由服务器给出，在门锁汇报
//门锁秘钥时，汇报验证数据
    u32 check_lock_random_data;		//lock_random_data校验值
    //网关通知门锁强制删除时，门锁需要验证此值
}__attribute__ ((packed));

///////////////////////////////////////////////////////////////////////////////////////////////////////////
#define	  RC_CMD_LOCK_KEY					0x48
//0x48：该指令对于首次加入系统的密钥获取过程。
struct Lock_Key {
    u32 check_auth_data;	//校验值
    u8 lock_key_len;
    u8 lock_key[16];
}__attribute__ ((packed));



#define   RC_CMD_START_UPDATE               0x4A
struct	Start_Update {
    u8  factory;		//门锁生产厂家
    u8	hard_ver;    //主控板硬件版本，指当前门锁的硬件版本
    u8	soft_ver;	   	//主控板嵌入式软件版本，指门锁即将升级的软件版本
    u32	 s_time;		//以秒计时的当前时间
    u16 ms_time;		//门锁和网关之间通讯的毫秒数
    u32 CRC32;			//升级文件校验值
    u32 CRC32_check;	//CRC32的校验值
}__attribute__ ((packed));

#define   RC_CMD_CHECK_SPEED               0x4E
struct 	Check_Speed_struct {
    u8	cur_speed;		//空中通信，当前速率
    u8  next_speed;		//空中通信，下次通信速率
    u8	send_cnt;		//本次空中速率下，第几次发送，第一次发送为1
    u32	 s_time;			//以秒计时的当前时间
    u16  ms_time;		//门锁和网关之间通讯的毫秒数
}__attribute__ ((packed));

#define   RC_CMD_CHECK_SPEED_ACK          0x50
struct 	Check_Speed_Ack_struct {
    u8	speed_ack;		//对应速率测试的cur_speed
    u8	ack_cnt;			//对应 send_cnt
    u8  receive_rssi;	//门锁收到的信号强度，为相对值，0,1,2,3,4
    u32	 s_time;			//以秒计时的当前时间
    u16  ms_time;		//门锁和网关之间通讯的毫秒数
}__attribute__ ((packed));

#define   RC_CMD_OPTIMAL_SPEED               0x52
struct		Optimal_Speed {
    u8	optimal_speed;		//
    u32	 s_time_start;	//以秒计时的数据传输的开始时间，
//一般比当前时间多3秒
    u16  ms_time;		//门锁和网关之间通讯的毫秒数
}__attribute__ ((packed));




};



#endif //GJ_TESTPLATFORM_LOCKMSGGW_H
