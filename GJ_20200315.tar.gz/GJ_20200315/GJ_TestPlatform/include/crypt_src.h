#ifndef WIFI_SOFT_AP_CRYPT_SRC_H_
#define WIFI_SOFT_AP_CRYPT_SRC_H_


#define SVR_MAX_DATA_LEN					1024		//网关与服务器通信，数据部分最大长度
#define	MAX_DATA_LEN				64	//433发送数据部分长度

#define CMD_SIZE            256
#define CMD_SIZE_SUB        244
#define KEY_LENGTH          4
#define NET_EXIT            0x1f
#define OPEN_TIME_DATA      50
#define CMD_LENGTH_AUTH     8
#define MAX_CFG             1024


/****/
//
////错误类型定义
#define 	HUOHE_SUCCEED 				0
#define 	HUOHE_FAIL 				!HUOHE_SUCCEED
#define 	ERR_LOCK_ID				0x01 //锁ID不对
#define		ERR_LENGTH_NOT_ENOUGH			0x02//数据包长度不够
#define		ERR_LENGTH				0x03//长度出错，即长度过长
#define		ERR_CHECK_WRONG				0x04//数据check不通过
#define		ERR_CRC					0x05//CRC校验出错
#define		ERR_CMD					0x06//命令字不对
#define		ERR_KEY_CODE				0x07//错误的密钥
#define 	ERR_KEYWORD				0x08//密钥的格式不对
#define 	ERR_KEYWORD_LEN 			0x09//密钥的长度不对
#define 	ERR_PWD_MODE				0x0A//加解密的密码不对
#define 	ERR_PWD_LEN 				0x0B//加解密的密码长度不对
#define		ERR_DATA_NOT_ENCRYPT			0x0C//数据需要加密，不是加密的返回错误。
#define 	ERR_NODE_CMD				0x0D	//命令错
#define 	ERR_SEQ					0x0E	//序号错
#define 	ERR_NODEID				0x0F  //NodeID错
#define 	ERR_CMD_ANALYSIS			0x10 //解析完数据包，后续处理出错
#define 	ERR_KEYID_NOT_VALID			0x11//该锁ID不在该节点上
#define 	ERR_NOT_ENOUGH_LOCK			0x12//没有足够的锁去删除
#define 	ERR_DB_RESULT				0x13
#define		INF_TEST_MODE_DATA			0x14
#define		INF_PRO_MODE_ENTER_ACK			0x15//返回该值表示接收到测试模式的指令。
#define		INF_MCU_REV_CHECK_ACK			0x16
#define		NET_NO_DATA				0x17
#define		INF_MCU_RESTART_ACK			0x18
#define		INF_MCU_RESTORE_ACK			0x19
#define		INF_MCU_433M_TEST_RESULT		0x1A
#define		INF_MCU_KEY_TEST_RESULT			0x1B

#define LOCK_LOST               1   //表示该锁失去连接
extern "C" {
typedef unsigned int u32;
typedef unsigned short int u16;
typedef unsigned char u8;

typedef unsigned char uchar;
typedef unsigned char UCHAR;

typedef unsigned char INT8U;
typedef unsigned short int INT16U;
typedef unsigned int INT32U;


// Prefer
typedef signed char INT8;
typedef signed short int INT16;
typedef signed int INT32;
typedef signed long long INT64;

typedef unsigned char UINT8;
typedef unsigned short int UINT16;
typedef unsigned int UINT32;
typedef unsigned long long UINT64;

//#define int64_t INT64
//#define uint64_t   UINT64

#define HEAD_AUTH_LENGTH        15
#define HEAD_CMD_LENGTH         12
#define HEAD_CRC                11
#define RF_DATA_LEN             50

//Net Frame
struct _NODE2SVR_FRAME_STRUCT {
    u32 node_id;            //网关编号
    u16 trans_len;      //数据加密后的长度，加密范围：
    // data_len，cmd_data，serial_num，data[MAX_CFG]。
    u8 encrypt_type;       //加密算法类型，目前定义的加密类型为1
    u32 crc32;          //crc=0时整个数据32bit校验和，数据从
    //node_id开始，到data[MAX_CFG]
    u8 data[MAX_CFG];       //data数据: data_len，cmd_data，serial_num，data[MAX_CFG]。
}__attribute__ ((packed));


//RF Frame
struct LOCK_NODE_FRAME {
    u16 dst_id;             //目的ID，0xFFFF：广播地址
    u8 data_len;               //数据长度
    u8 crc8;
    u8 data[36];
}__attribute__ ((packed));


typedef struct {
    UINT8 hour;
    UINT8 min;
    UINT8 sec;
    UINT16 w_year;
    UINT8 w_month;
    UINT8 w_date;
    UINT8 week;
} RTC_TIMER;


#define DH_KEY_LENGTH   (16)

//typedef unsigned char DH_KEY[DH_KEY_LENGTH];
typedef u8 DH_KEY[DH_KEY_LENGTH];
//srand();
void DH_generate_key_pair(DH_KEY public_key, DH_KEY private_key);
void DH_generate_key_secret(DH_KEY secret_key, const DH_KEY my_private, const DH_KEY another_public);
//解密数据包
/*
输入参数的具体说明:
	u32 node_id:指网关ID，例如：0x0A050201,表示网关的id为："10.5.2.1"
	u32 *keyword:	指输入的密钥，该密钥为门锁的密钥，128位密钥。例如：
				keyword[0]= 0x41534f33;
				keyword[1]= 0x529378b4;
				keyword[2]= 0x6eaae41c;
				keyword[3]= 0xc12301d7;
	u8 *ucData:指对加密的数据包，在协议中指加密的部分，如下的数据结构中包括dst_id，data_len，crc8以及它后面加密部分的数据。
		struct NODE2SVR_FRAME_STRUCT{	
			u32 node_id;				//网关编号
			u16 trans_len;			//数据加密后的长度，加密范围：
									// data_len，cmd_data，serial_num，data[MAX_CFG]。
			u8	encrypt_type;			//加密算法类型，0：明文传输，1：加密类型1
									//2：加密类型2
									//目前只定义了明文传输和加密类型1加密
									//心跳包和网关请求接入系统指令，采用明文传输
			u32 crc32;				//crc=0时整个数据32bit校验和，数据从
									//node_id开始，到data[MAX_CFG]
									//最后一个字节结束
									//先加密再计算crc32
			u16 data_len;				//指示data数据长度。
		
			u16 cmd_data;				//命令字	
			u32 serial_num; 			//流水单号
			u8 data[MAX_CFG];			//data数据内容见相应的命令。
		};

		运行函数后，该数组返回解密后的数据包，该数据包是协议中符合标准的数据明文包，其结构符合上面的结构体。
	u8 *ucData_len:输入指加密的数据包的长度，输出的是指解密后的数据包的长度。例如
返回值的说明：
	函数的返回值为u8: 	如下面定义
			#define 		HUOHE_SUCCEED 			0
			#define 		HUOHE_FAIL 				!HUOHE_SUCCEED
			#define 		ERR_LOCK_ID				0x01
			#define		ERR_LENGTH_NOT_ENOUGH		0x02
			#define		ERR_LENGTH				0x03
			#define		ERR_CHECK_WRONG			0x04			//数据check不通过
			#define		ERR_CRC					0x05
			#define		ERR_CMD					0x06
			#define		ERR_KEY_CODE				0x07	//错误的密钥
			#define 		ERR_KEYWORD				0x08
			#define 		ERR_KEYWORD_LEN 			0x09
			#define 		ERR_PWD_MODE				0x0A
			#define 		ERR_PWD_LEN 				0x0B

例如:
	从加密函数的例子当中获得加密数据包，传入到该函数的解密数据包中为例，具体如下
node_id = 0x0A000001;
例如数据加密后得到的数据包为：
u8 *ucData={0x01,0x00,0x00,0x0A,0x10,0x00,0x01,0x89,Ox99,0x30,0x4D,0x0F,0xE2,0x16,0x6C,0x5F,0xAE,0x25,0x9F,0x0C,0x31,0xEA,0x23,0x46,0x8F,0xBD,0x6E}.
u8 *ucData_len=0x1B；							
经过调用该函数可以得到如下
得到u8 *ucData 例如:{0x01,0x00,0x00,0x0A,0x0C,0x00,0x00,0x00,0x00,0x00,0x00,0x04,0x00,0x00,0x10,0x2B,0x29,0x44,0x25,0x00,0x00,0x00,0x00};
得到u8 *ucData_len;例如:0x17


*/
u8 NetDecodePacket(u32 node_id, u32 *keyword, u8 *ucData, u16 *ucData_len);
//加密数据包
/*
输入参数的具体说明:
	u32 node_id:指网关ID，例如：0x0A050201,表示网关的id为："10.5.2.1"
	u32 *keyword:	指输入的密钥，该密钥为网关的密钥，128位密钥。例如：
				keyword[0]= 0x41534f33;
				keyword[1]= 0x529378b4;
				keyword[2]= 0x6eaae41c;
				keyword[3]= 0xc12301d7;
	u8 *ucData:指需要加密部分的数据包，在协议中指加密的部分，如下的数据结构中包括data_len，cmd_data，serial_num，data[data_len]。
		struct NODE2SVR_FRAME_STRUCT{	
			u32 node_id;				//网关编号
			u16 trans_len;			//数据加密后的长度，加密范围：
									// data_len，cmd_data，serial_num，data[MAX_CFG]。
			u8	encrypt_type;			//加密算法类型，0：明文传输，1：加密类型1
									//2：加密类型2
									//目前只定义了明文传输和加密类型1加密
									//心跳包和网关请求接入系统指令，采用明文传输
			u32 crc32;				//crc=0时整个数据32bit校验和，数据从
									//node_id开始，到data[MAX_CFG]
									//最后一个字节结束
									//先加密再计算crc32
			u16 data_len;				//指示data数据长度。
		
			u16 cmd_data;				//命令字	
			u32 serial_num; 			//流水单号
			u8 data[MAX_CFG];			//data数据内容见相应的命令。
		};

		输出加密后的完整包，即需要发给服务器或者网关的数据包。运行函数后，该数组返回解密后的数据，因此调用该函数的时候，需要注意的数组大小最好1024个字节。
	u8 *ucData_len:输入指需要加密的数据包的长度，输出的是指加密后的数据包的长度。例如
	u8 ucEncrypt_type:加密算法的输入，目前都固定为Tea加密算法，其值为0x01。
返回值的说明：
	函数的返回值为u8: 	HUOHE_FAIL
					HUOHE_SUCCEED

例如:

node_id = 0x0A000001;
u8 *ucData 例如:{0x04,0x00,0x00,0x10,0x2B,0x29,0x44,0x25,0x00,0x00,0x00,0x00};
u8 *ucData_len;例如:0x0C

例如上面的数据加密后得到的数据为：
得到u8 *ucData={0x01,0x00,0x00,0x0A,0x10,0x00,0x01,0x89,Ox99,0x30,0x4D,0x0F,0xE2,0x16,0x6C,0x5F,0xAE,0x25,0x9F,0x0C,0x31,0xEA,0x23,0x46,0x8F,0xBD,0x6E}.
得到u8 *ucData_len=0x1B；				
*/
u8 NetEncodePacket(u32 node_id, u32 *keyword, u8 *ucData, u16 *ucData_len, u8 ucEncrypt_type);
//解密密码
//需要注意的是如果密钥不对，解密错误，没有对数据进行保护，或者说怎么判断解密出错
/*
输入参数的具体说明:
	u32 lock_id:输入门锁的ID
	u32 *keyword:输入的密钥数，支持128位密钥
	u8 *ucKeyPwd:输入的密码的0~9,A~F,a~f之间的字符串，例如"A87267601C0AE9AB4837CDE1C21644B3";
	u8 *ucKeyPwd_len:输入的字符串的长度
返回值的说明：
	函数的返回值为u8: 	如下面定义
			#define 		HUOHE_SUCCEED 			0
			#define 		HUOHE_FAIL 				!HUOHE_SUCCEED
			#define 		ERR_LOCK_ID				0x01
			#define		ERR_LENGTH_NOT_ENOUGH		0x02
			#define		ERR_LENGTH				0x03
			#define		ERR_CHECK_WRONG			0x04			//数据check不通过
			#define		ERR_CRC					0x05
			#define		ERR_CMD					0x06
			#define		ERR_KEY_CODE				0x07	//错误的密钥
			#define 		ERR_KEYWORD				0x08
			#define 		ERR_KEYWORD_LEN 			0x09
			#define 		ERR_PWD_MODE				0x0A
			#define 		ERR_PWD_LEN 				0x0B
*/
u8 DecodeKeyPwd(u32 lock_id, u32 *keyword, u8 *ucKeyPwd, u8 *ucKeyPwd_len);
/*
注意:data_len的最高第二位为作为加解密的标志位。
struct LOCK_NODE_FRAME {
	u16		dst_id;				//目的ID，0xFFFF：广播地址
	u8		data_len;				//数据长度,从src_id开始之后的
	u8		crc8;
	u16		src_id;				//源ID
	u8		data_type;			//数据类型
	u8		data_label;			//帧标签
	u8		Data[data_len];		//数据，最多24字节
};

struct LOCK_NODE_FRAME {
	u16		dst_id;				//目的ID，0xFFFF：广播地址
	u8		tran_data_len;		//数据长度,从src_id开始之后的
	u8		crc8;
	
	u8		data_len;				//数据长度,从src_id开始之后的
	u16		src_id;				//源ID
	u8		data_type;			//数据类型
	u8		data_label;			//帧标签
	u8		Data[data_len];		//数据，最多24字节
};

*/

#define    RF_PACKET_LEN                4
#define    RF_ENCODE_PACKET_LEN        4
#define    RF_ADDR_TRAN_LEN            2
#define    RF_ADDR_CRC8_DATA            3

//无线通讯的数据包的加密
/*
输入参数的具体说明:
	u32 dst_id:指数据包发送的目的门锁ID，例如：0x0A050201,表示门锁的id为："10.5.2.1"
	u32 src_id:指数据包发送的源门锁ID，例如：0x0A050201,表示门锁的id为："10.5.2.1"
	u32 *keyword:	指输入的密钥，该密钥为门锁的密钥，128位密钥。例如：
				keyword[0]= 0x41534f33;
				keyword[1]= 0x529378b4;
				keyword[2]= 0x6eaae41c;
				keyword[3]= 0xc12301d7;
	u8 *ucData:指需要加密部分的数据包，在协议中指加密的部分，如下的数据结构中包括src_id，data_type，data_label，Data[data_len]。
		struct LOCK_NODE_FRAME {
			u16 	dst_id; 			//目的ID，0xFFFF：广播地址
			u8	data_len;			//数据长度
			u8	crc8;
			u16 	src_id; 			//源ID
			u8	data_type;		//数据类型
			u8	data_label; 		//帧标签
			u8	Data[data_len]; 	//数据，最多28字节
		}；
		输出加密后的完整包，即需要发给另一个门锁的数据包。运行函数后，该数组返回解密后的数据，因此调用该函数的时候，需要注意的数组大小最好64个字节。
	u8 *ucData_len:输入指需要加密的数据包的长度，输出的是指加密后的数据包的长度。例如
	u8 ucEncrypt_type:加密算法的输入，目前都固定为Tea加密算法，其值为0x01。
返回值的说明：
	函数的返回值为u8: 	HUOHE_FAIL
					HUOHE_SUCCEED

例如:

dst_id = 0x0A000001;src_id=0x06050403;
u8 *ucData 例如:{0x03,0x04,0x93,0x01,0x00,0x0a,0x07,0x02,0x00,0x00,0x02,0x10};
u8 *ucData_len;例如:0x0C

例如上面的数据加密后得到的数据为：
得到u8 *ucData={0x01,0x00,0x0C,0x41,0x16,0xA7,0x75,0x58,Ox47,0x46,0xD6,0xF1,0x23,0x1E,0x77,0x23,0x57,0x96,0x28,0x2B}.
得到u8 *ucData_len=0x14；				
*/
u8 RfEncodePacket(u32 dst_id, u32 src_id, u32 *keyword, u8 *ucData, u8 *ucData_len, u8 ucEncrypt_type);

//无线通讯的数据包的解密
/*
输入参数的具体说明:
	u32 dst_id:指数据包发送的目的门锁ID，例如：0x0A050201,表示门锁的id为："10.5.2.1"
	u32 src_id:指数据包发送的源门锁ID，例如：0x0A050201,表示门锁的id为："10.5.2.1"
	u32 *keyword:	指输入的密钥，该密钥为门锁的密钥，128位密钥。例如：
				keyword[0]= 0x41534f33;
				keyword[1]= 0x529378b4;
				keyword[2]= 0x6eaae41c;
				keyword[3]= 0xc12301d7;
	u8 *ucData:指对加密的数据包，在协议中指加密的部分，如下的数据结构中包括dst_id，data_len，crc8以及它后面加密部分的数据。
		struct LOCK_NODE_FRAME {
			u16 	dst_id; 			//目的ID，0xFFFF：广播地址
			u8	data_len;			//数据长度
			u8	crc8;
			u16 	src_id; 			//源ID
			u8	data_type;		//数据类型
			u8	data_label; 		//帧标签
			u8	Data[data_len]; 	//数据，最多28字节
		}；
		运行函数后，该数组返回解密后的数据包，该数据包是协议中符合标准的数据明文包，其结构符合上面的结构体。
	u8 *ucData_len:输入指加密的数据包的长度，输出的是指解密后的数据包的长度。例如
返回值的说明：
	函数的返回值为u8: 	如下面定义
			#define 		HUOHE_SUCCEED 			0
			#define 		HUOHE_FAIL 				!HUOHE_SUCCEED
			#define 		ERR_LOCK_ID				0x01
			#define		ERR_LENGTH_NOT_ENOUGH		0x02
			#define		ERR_LENGTH				0x03
			#define		ERR_CHECK_WRONG			0x04			//数据check不通过
			#define		ERR_CRC					0x05
			#define		ERR_CMD					0x06
			#define		ERR_KEY_CODE				0x07	//错误的密钥
			#define 		ERR_KEYWORD				0x08
			#define 		ERR_KEYWORD_LEN 			0x09
			#define 		ERR_PWD_MODE				0x0A
			#define 		ERR_PWD_LEN 				0x0B

例如:
	从加密函数的例子当中获得加密数据包，传入到该函数的解密数据包中为例，具体如下
dst_id = 0x0A000001;src_id=0x06050403;
例如数据加密后得到的数据包为：
u8 *ucData={0x01,0x00,0x0C,0x41,0x16,0xA7,0x75,0x58,Ox47,0x46,0xD6,0xF1,0x23,0x1E,0x77,0x23,0x57,0x96,0x28,0x2B}.
u8 *ucData_len=0x14；							
经过调用该函数可以得到如下
得到u8 *ucData 例如:{0x01,0x00,0x08,0x00,0x03,0x04,0x93,0x01,0x00,0x0a,0x07,0x02,0x00,0x00,0x02,0x10};
得到u8 *ucData_len;例如:0x10

*/
u8 RfDecodePacket(u32 dst_id, u32 *keyword, u8 *ucData, u8 *ucData_len, u8 *ucEncrypt);

/*
函数输入参数说明:
	u8 *data_input:算法密码(包括一次性密码)输入，该数据格式0~9之间的字符。例如:"12345678"
	u8 *ucPwd_type_out:如果输入密码有效，该输出开门的流水通道号，算法密码支持0~7共八种。例如:5
	u32 *key_word:指输入的密钥，该密钥为门锁的密钥，128位密钥。例如：
			keyword[0]= 0x41534f33;
			keyword[1]= 0x529378b4;
			keyword[2]= 0x6eaae41c;
			keyword[3]= 0xc12301d7;
	u32 lock_id:门锁的ID，例如：0x0A050201,表示门锁的id为："10.5.2.1"
	RTC_TIMER *rc_time:指输入的当前时间，其数据结构如下：
		typedef struct			
		{
			//时分秒
			u8 hour;
			u8 min;
			u8 sec; 				 
			
			//年月日
			UINT16 w_year;
			u8	w_month;
			u8	w_date;
			u8	week;			  
		}RTC_TIMER; 
		调用程序后输出一次性密码的授权时间。
	u32 *valid_time:指该解出来的密码持续的时间是多少，单位为秒数。例如：6000，即该密码为设置的起始时间到结束时间，总共6000秒，并不是该密码从输入的当前时间持续。

函数返回参数说明:
	返回值为u8: 	HUOHE_FAIL
				HUOHE_SUCCEED
#define 		HUOHE_SUCCEED 			0
#define 		HUOHE_FAIL 				!HUOHE_SUCCEED
*/
u8 Decode_Input(u8 *data_input, u8 *ucPwd_num_out, u32 *key_word, u32 lock_id, RTC_TIMER *rc_time, u32 *valid_time,
                u8 *ucPwd_type);


#define    CHECK_SET_LOCK_KEY        0//重置密码，
#define    CHECK_ADD_LOCK_KEY        1//首次加入门锁，网关的时候密钥
#define    CHECK_UPPRO_CRC_KEY    2//门锁，网关的CRC32校验算法
#define    CHECK_REMOTE_DOOR        3//远程开门的校验
#define    CHECK_NODE_LOCK_KEY    4//首次加入网关，网关的时候密钥
/*
输入参数的具体说明:
	u32 lock_id:指门锁ID，例如：0x0A050201,表示门锁的id为："10.5.2.1"
	u32 *keyword:	指输入的密钥，该密钥为门锁的密钥，128位密钥。例如：
				keyword[0]= 0x41534f33;
				keyword[1]= 0x529378b4;
				keyword[2]= 0x6eaae41c;
				keyword[3]= 0xc12301d7;
	u32 init_Data:指输入的初始化的值，该值用来生成验证值。

	u32 *Check_Data:返回产生的验证值。
	u8 ucFunc_type:预留接口，是用来把各种身份验证作为区分的接口。
返回值的说明：
	
	函数的返回值为u8: 	如下面定义
			#define 		HUOHE_SUCCEED 			0
			#define 		HUOHE_FAIL 				!HUOHE_SUCCEED
			#define 		ERR_LOCK_ID				0x01
			#define		ERR_LENGTH_NOT_ENOUGH		0x02
			#define		ERR_LENGTH				0x03
			#define		ERR_CHECK_WRONG			0x04		//数据check不通过
			#define		ERR_CRC					0x05
			#define		ERR_CMD					0x06
			#define		ERR_KEY_CODE				0x07	//错误的密钥
			#define 		ERR_KEYWORD				0x08
			#define 		ERR_KEYWORD_LEN 			0x09
			#define 		ERR_PWD_MODE				0x0A
			#define 		ERR_PWD_LEN 				0x0B

*/


u8 GenAuthKey(u32 lock_id, u32 *keyword, u32 init_Data, u32 *Check_Data, u8 ucFunc_type);


/*
输入参数的具体说明:
	u32 lock_id:指门锁ID，例如：0x0A050201,表示门锁的id为："10.5.2.1"
	u32 *keyword:	指输入的密钥，该密钥为门锁的密钥，128位密钥。例如：
				keyword[0]= 0x41534f33;
				keyword[1]= 0x529378b4;
				keyword[2]= 0x6eaae41c;
				keyword[3]= 0xc12301d7;
	u32 init_Data:指输入的初始化的值，该值用来生成验证值。

	u32 Check_Data:指输入的验证值。
	u8 ucFunc_type:预留接口，是用来把各种身份验证作为区分的接口。
返回值的说明：
		验证成功：HUOHE_SUCCEED
		验证失败：ERR_CHECK_WRONG
	函数的返回值为u8: 	如下面定义
			#define 		HUOHE_SUCCEED 			0
			#define 		HUOHE_FAIL 				!HUOHE_SUCCEED
			#define 		ERR_LOCK_ID				0x01
			#define		ERR_LENGTH_NOT_ENOUGH		0x02
			#define		ERR_LENGTH				0x03
			#define		ERR_CHECK_WRONG			0x04		//数据check不通过
			#define		ERR_CRC					0x05
			#define		ERR_CMD					0x06
			#define		ERR_KEY_CODE				0x07	//错误的密钥
			#define 		ERR_KEYWORD				0x08
			#define 		ERR_KEYWORD_LEN 			0x09
			#define 		ERR_PWD_MODE				0x0A
			#define 		ERR_PWD_LEN 				0x0B

*/

u8 CheckAuthKey(u32 lock_id, u32 *keyword, UINT32 init_Data, UINT32 Check_Data, u8 ucFunc_type);
};

#endif /* WIFI_SOFT_AP_CRYPT_SRC_H_ */
