//
// Created by hantao on 18-11-5.
//

#ifndef GJ_TESTPLATFORM_PUB_H_H
#define GJ_TESTPLATFORM_PUB_H_H
#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <thread>
#include <sys/socket.h>
#include <sys/types.h>
#include <arpa/inet.h>
#include <map>
#include <string>
#include <vector>
#include <fstream>
#include <string.h>
#include <string>
#include "thread"
#include <mutex>
#include <setjmp.h>
#include <queue>
#include <sys/time.h>
#include <ctime>
#include <sys/ioctl.h>
#include <fcntl.h>
#include <unistd.h>
#include <wait.h>

#include <execinfo.h>
#include "GJlibev.h"
#include "Glog.h"
#include "GJjson.h"
#include "crypt_src.h"

#include "GwMsgNhap.h"
#include "../common/config.h"

#include "crypt_src_lock.h"

#include "sqlite3/sqlite3.h"

#define RECV_MAX 1024
#define dataMax 1024
#define lockMax 20

/*#define  DATA_DIR "/GJ_TestPlatform/etc/testData/"*/

#define  PWD_DIR "/GJ_TestPlatform/etc/testData/id_key.txt"

/*#define  GW_DB_DIR "/GJ_TestPlatform/DB/gwDatabase.db"*/
using namespace std;
using namespace std::this_thread;

#define  FILEPATH_MAX 80
static string getdir() {
    char file_path_getcwd[FILEPATH_MAX];
    getcwd(file_path_getcwd,FILEPATH_MAX);
    string p =file_path_getcwd;
    int npos = p.find("sbin");
    return  p.substr(0,npos);
}

struct data{
    string action;
    string data;
    string timeInterval;
};

/*
struct data{
    char action[32];
    char data[1024];
    int timeInterval;
};
 */
typedef struct data DATA;

struct gwaction{
    int number;
    string actionName;
    DATA data1[20];
};
typedef gwaction ACTION;



#endif //GJ_TESTPLATFORM_PUB_H_H
