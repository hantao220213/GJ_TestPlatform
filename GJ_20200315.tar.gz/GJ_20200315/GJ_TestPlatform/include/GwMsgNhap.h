//
// Created by hantao on 18-12-17.
//

#ifndef GJ_TESTPLATFORM_GWTONHAP_H
#define GJ_TESTPLATFORM_GWTONHAP_H

//#define  MAX_CFG 1024
//#define  DH_KEY_LENGTH 16
#include "crypt_src.h"
extern "C"{
struct NODE2SVR_FRAME_STRUCT {
    u32 node_id;                //网关编号
    u16 trans_len;            //数据加密后的长度，加密范围：
    // data_len，cmd_data，serial_num，data[MAX_CFG]。
    u8 encrypt_type;        //加密算法类型，
    //0：门锁明文传输，
    //1：门锁加密类型
    //2：电表明文类型
    //3：电表加密类型
    //目前定义了门锁明文传输和门锁加密类型
    //
    //心跳包和网关请求接入系统指令，采用明文传输
    u32 crc32;                //crc=0时整个数据32bit校验和，数据从
    //node_id开始，到data[MAX_CFG]
    //最后一个字节结束
    //先加密再计算crc32
    u16 data_len;            //指示data数据长度。

    u16 cmd_data;            //命令字
    u32 serial_num;            //流水单号
    u8 data[MAX_CFG];        //data数据内容见相应的命令。
}__attribute__((packed));

/*
 * 心跳包请求0x1001
 */
#define CMD_NODE_HELLO                0x1000
struct NODE_HELLO_INFO {
    u32 hello;        //保留参数，值为0
}__attribute__ ((packed));

#define SVR_ECHO_HELLO                0x4000
struct SVR_ECHO_HELLO_INFO {
    u32 status;        //返回值，0：成功收到数据，1：数据出错
}__attribute__ ((packed));

#define CMD_NODE_NODE_JOININ            0x1001
struct NODE_NODE_JOININ_INFO {
    u32 join_flag;        //网关初次接入系统，join_flag为0，
    //成功接入系统后再次请求接入，join_flag为1
    //join_flag为1时，node_public无效
    u32 node_random_data;//32位随机数，网关被强制删除时做身份认证
    u16 node_public_len;
    u8 node_public[DH_KEY_LENGTH];
}__attribute__ ((packed));

#define SVR_ECHO_NODE_JOININ            0x4001
struct SVR_ECHO_NODE_JOININ_INFO {
    u32 status;            //返回值，0：同意接入，1：拒绝接入，
//2：服务器忙，3：强制删除
    u32 auth_data;        //服务器同意接入返回随机数，用于网关身份认证
    //此为不重复的随机数
    u32 check_node_random_data;    //node_random_data校验值
    u16 svr_public_len;
    u8 svr_public[DH_KEY_LENGTH];
}__attribute__ ((packed));

#define CMD_NODE_NOTIFY_VALID        0x1002
struct NODE_NODE_VALID {
    u16 hard_ver;        //硬件版本号，0xmain,slave
    //网关硬件版本采用4位数字表示，例如：2.1.1.0
    //2.1为主版本号，1.0为子版本号
    u16 soft_ver;        //软件版本号，0xmain,slave
    //网关嵌入式软件版本采用4位数字表示
    u16 node_type;        //网关类型
    u16 node_factory;    //网关生产厂家
    u32 check_auth_data; //auth_data验证值
}__attribute__ ((packed));
#define SVR_ECHO_NOTIFY_VALID        0x4002
struct SVR_ECHO_NOTIFY_VALID_INFO {
    u32 status;                //返回值，0：成功收到数据，1：数据出错
    u8 node_work_chn;        //网关工作信道，如果数据库存有以前网关
    //工作信道，返回以前工作信道，如果没有，返回0
    u8 start_slice;        //通信起始时隙（网关工作信道有效才有意义，
    //否则返回0
    u8 end_slice;            //通信结束时隙（网关工作信道有效才有意义，
    //否则返回0
    u8 lock_num;                //网关管理的门锁数量
    struct {
        u32 lock_id;                //门锁编号
        u8 work_channel;        //门锁工作信道
    } lock_info[20];
}__attribute__ ((packed));

#define CMD_NODE_NODE_NEW_KEY_RAND            0x1008
struct NODE_NODE_NEW_KEY_RAND_INFO {
    u32 status;        //status 值为0
}__attribute__ ((packed));


#define SVR_ECHO_NODE_NEW_KEY_RAND            0x4008
struct SVR_ECHO_NODE_NEW_KEY_RAND_INFO {
    u32 status;            //返回值，0：成功收到，1：数据出错，
    u32 rand_data;        //服务器返回随机数，用于密钥更新确认
    //此为不重复的随机数
}__attribute__ ((packed));


#define CMD_NODE_NODE_NEW_KEY            0x1016
struct NODE_NODE_NEW_KEY_INFO {
    u32 old_key_rand_data;    //采用旧密钥加密rand_data
    u8 key_len;
    u8 old_key_new_key[128];    //采用旧密钥加密新密钥
    u32 new_key_rand_data;    //采用新密钥加密rand_data
}__attribute__ ((packed));


//应答：
#define SVR_ECHO_NODE_NEW_KEY			0x4016
struct SVR_ECHO_NODE_NEW_KEY_INFO {
    u32 status;			//返回值，0：成功收到，1：数据出错，
}__attribute__ ((packed));



#define CMD_NODE_OPEN_DOOR_TIME        0x1003
//网关报告开门时间
//注意：网关汇报上来的开门时间，为格林尼治时间。

struct NODE_OPEN_DOOR_TIME {
    u8 lock_num;                //门锁数量
    struct {
        u32 lock_id;            //门锁编码
        u32 rec_num;            //记录数量
        struct {
            u8 open_type;        //开门类型
            u8 index;            //通道索引（1--30）
            u32 open_time;        //开门时间
        } open_rec[1024];
    } time[20];
}__attribute__ ((packed));
#define SVR_ECHO_OPEN_DOOR_TIME        0x4003
struct SVR_ECHO_OPEN_DOOR_TIME_INFO {
    u32 status;        //0：收到数据，1：数据出错
}__attribute__ ((packed));


#define CMD_NODE_LOCK_INFO            0x1004
struct NODE_LOCK_INFO {
    u8 lock_num;            //门锁数量
    struct {
        u32 lock_id;            //门锁编码
        u8 rec_num;
        struct {
            u8 info_type;        //门锁信息类型
            u8 info_len;
            u8 info[28];
        } lock_info[20];
    } lock_list[20];
}__attribute__ ((packed));

//应答：
#define SVR_ECHO_LOCK_INFO            0x4004
struct SVR_ECHO_LOCK_INFO_INFO {
    u32 status;            //0：成功收到数据，1：数据出错
}__attribute__ ((packed));


//命令：网关请求服务器校准当前时间，作为网关的统一时间,该时间是格林尼治时间。
#define CMD_NODE_NTP_CALI_TIME            0x1005
struct NODE_NTP_CALI_TIME_INFO {
    u32 time;            //网关时间，为格林尼治时间
    u16 ms_time;        //网关时间，毫秒
}__attribute__ ((packed));

//应答：服务器应答网关校时请求
#define SVR_ECHO_NTP_CALI_TIME            0x4005
struct SVR_ECHO_NTP_CALI_TIME_INFO {
    u32 status;        //返回值，0：成功收到数据，1：数据出错
    u32 time;            //接收到的网关时间
    u16 ms_time;        //接收到的毫秒时间
    u32 rcv_time;        //服务器收到请求时间，服务器格林尼治时间
    u16 rcv_ms_time;//毫秒
    u32 send_time;    //服务器发送数据时间，服务器格林尼治时间
    u16 send_ms_time;        //毫秒
}__attribute__ ((packed));


//命令：网关向服务器查询门锁密码，每次查询一把门锁密码
#define CMD_NODE_QUERY_LOCK_PWD        0x1006
struct NODE_QUERY_LOCK_PWD_INFO {
    u32 lock_id;        //门锁编码
    u8 pwd_num;            //密码数量，pwd_num=255，查询全部密码
    u8 pwd_type[255];        //密码类型
}__attribute__ ((packed));

//应答：服务器应答网关请求查询门锁密码
#define SVR_ECHO_QUERY_LOCK_PWD        0x4006
struct SVR_ECHO_QUERY_LOCK_PWD_INFO {
    u32 status;        //返回值，0：成功收到数据，1：数据出错
    u32 lock_id;            //门锁编码
    u8 pwd_num;            //密码数量
    struct {
        u8 pwd_type;            //密码类型索引（1--30）
        u8 pwd_len;            //密码长度
        u8 rfid_pwd;            //密码或卡号，0：普通密码，1：RFID卡号
        u8 pwd_en;            //密码启用标志：0：启用，1： 禁用
        u8 pwd[256];    //门锁密码，采用门锁秘钥加密
        u32 start_time;        //开始时间
        u32 end_time;        //结束时间
    } pwd[255];
}__attribute__ ((packed));

//        命令：网关向服务器汇报门锁网络状态
#define CMD_NODE_LOCK_NET_STATUS        0x1007
struct NODE_LOCK_NET_STATUS_INFO {
    u8 lock_num;            //门锁数量
    struct {
        u32 lock_id;        //门锁编码
        u32 report_time;    //汇报时间
        u8 status;        //状态值，0：门锁在线，254：门锁离线
    } status[20];
}__attribute__ ((packed));

//应答：服务器应答网关汇报门锁网络状态
#define SVR_ECHO_LOCK_NET_STATUS        0x4007
struct SVR_ECHO_LOCK_NET_STATUS_INFO {
    u32 status;        //返回值，0：收到数据，1：数据出错
}__attribute__ ((packed));

//命令：网关向服务器汇报门锁密码设置结果
#define CMD_NODE_SET_PWD_RESULT    0x1009

struct NODE_SET_PWD_RESULT_INFO {
    u32 lock_id;            //门锁编码
    u32 serial_num;//服务器下发设置门锁密码指令时的流水单号
    u8 pwd_num;            //密码数量
    //struct {
        u8 pwd_type;        //密码类型
        u8 pwd_status;        //密码设置结果，0：成功，1：失败
    //} pwd_result[20];
}__attribute__ ((packed));

//应答：服务器应答网关汇报密码设置结果
#define SVR_ECHO_SET_PWD_RESUTL 0x4009
struct SVR_ECHO_SET_PWD_RESULT_INFO {
    u32 status;    //返回值，0：收到数据，1：数据出错
}__attribute__ ((packed));

#define CMD_NODE_NODE_WORK_PARAMETER        0x100A
struct NODE_NODE_WORK_PARAMETER_INFO {
    u8 status;            //0：信道没有冲突，1：信道有冲突
    u8 work_channel;    //网关工作信道
    u8 start_slice;        //网关和门锁通信起始时隙
    u8 end_slice;        //网关和门锁通信结束时隙
    u16 hard_ver;        //硬件版本号，0xmain,slave
    //网关硬件版本采用4位数字表示，例如：2.1.1.0
    //2.1为主版本号，1.0为子版本号
    u16 soft_ver;        //软件版本号，0xmain,slave
    //网关嵌入式软件版本采用4位数字表示
}__attribute__ ((packed));

//应答：应答网关向服务器汇报网关参数

#define SVR_ECHO_NODE_WORK_PARAMETER     0x400A
struct SVR_ECHO_NODE_WORK_PARAMETER_INFO {
    u32 status;    //返回值，0：数据收到，1：数据出错
}__attribute__ ((packed));

//命令：网关向服务器查询门锁的配置信息（目前主要指信道）
#define CMD_NODE_QUERY_CONFIG		0x100B
struct NODE_QUERY_CONFIG_INFO {
    u8	 lock_num;					//门锁数量
    u32 lock_id[20];  		//门锁编码
}__attribute__ ((packed));

//应答：服务器应答网关门锁的配置信息
#define SVR_ECHO_QUERY_CONFIG		0x400B
struct SVR_ECHO_QUERY_CONFIG_INFO {
    u32 status;				//返回值，0：数据收到，1：数据出错
    u8	 lock_num;			//门锁数量
    struct	{
        u32 lock_id;  		//门锁编码
        u8	 work_channel; 	//门锁工作信道
    }Lock_info[20];
}__attribute__ ((packed));

//命令：网关向服务器汇报门锁重置结果
#define CMD_NODE_SYS_RST_LOCK_RESULT		0x100D
struct NODE_SYS_RST_LOCK_RESULT_INFO {
    u32 lock_id;			//门锁编码
    u32 serial_num;//服务器下发重置门锁指令时的流水单号
    u8 status;			//门锁重置结果，0：成功，1：失败，2：门锁离线
}__attribute__ ((packed));

//应答：服务器应答重置门锁结果
#define SVR_ECHO_SYS_RST_LOCK_RESULT 	0x400D
struct SVR_ECHO_SYS_RST_LOCK_RESULT_INFO {
    u32 status;			//返回值，0：数据收到，1：数据出错
}__attribute__ ((packed));

//该请求包请服务器确认，是否同意门锁加入网关，如拒绝门锁加入，返回拒绝的原因。
//命令：网关请求服务器，门锁加入系统。
#define CMD_NODE_ADD_LOCK			0x100E
struct NODE_ADD_LOCK_INFO {
    u8 lock_num;			//门锁数量
    struct {
        u32 lock_id;			//门锁编码
        u8	joinin_flag;	 //标记门锁是否接入系统，0：未接入，1：已接入
        //已接入系统的含义，服务器已确认收到门锁密钥
        u8	hard_ver;    //主控板硬件版本
        u8	soft_ver;    //主控板嵌入式软件版本
        u8	lock_type;   //门锁类型
        u8	lock_factory; //门锁生产厂家
        u32 lock_random_data;//门锁产生的随机数，
//在门锁被强制删除时做身份认证用
        u32 id_lock_random_data;//门锁再次加入系统，用于门锁身份认证
    }__attribute__ ((packed));
}__attribute__ ((packed));

//id_lock_random_data = check_lock_key(lock_random_data, lock_key );
//应答：服务器应答网关请求增加门锁

#define SVR_ECHO_ADD_LOCK			0x400E
struct SVR_ECHO_ADD_LOCK_INFO {
    u32 status;			//返回值，0：数据收到，1：数据出错
    u8 lock_num;			//门锁数量
    //struct  {
        u32 lock_id;			//门锁编码
        u8	 work_channel; //工作信道
                           //0：门锁以前没有加入过系统，
                           //   网关决定门锁工作信道
                           //1-39（奇数）：门锁以前加入过系统，以前的
                           //   工作信道
                           //其它：错误数据
        u8 lstatus;			//0:同意，1:拒绝，2:服务器忙，
                            //3:门锁已强制删除，请重新接入
        u32 check_lock_random_data; // lock_random_data校验值
        u32 auth_data;		//门锁初次加入系统，服务器发给门锁，用于身//份认证的数据；
                            //在门锁汇报门锁秘钥时，同时汇报校验值，从而验证是否是火河门锁。
                            //注意：auth_data是不重复的随机数
    //}Add_lock_ack __attribute__ ((packed));
}__attribute__ ((packed));

//命令：网关向服务器汇报门锁信号强度
#define CMD_NODE_RSSI_DATA		0x100F
struct NODE_RSSI_DATA_INFO {
    u8 lock_num; 		//门锁数量
    struct {
        u32 lock_id; 	//门锁编码
        u32 cap_time; 	//信号强度获取时间
        u8  Rssi;			//信号强度，范围，0,1,2,3,4
    } rssi_data[20] __attribute__ ((packed));
}__attribute__ ((packed));

//应答：服务器应答
#define SVR_ECHO_RSSI_DATA		0x400F
struct SVR_ECHO_RSSI_DATA_INFO {
    u32 	status; 		//返回值，0：成功收到数据，1：数据出错
}__attribute__ ((packed));


//命令：网关向服务器汇报门锁工作信道
#define CMD_NODE_LOCK_WORK_CHANNEL		0x1011
struct NODE_LOCK_WORK_CHANNEL_INFO {
    u8 lock_num; 			//门锁数量
    struct {
        u32 lock_id; 		//门锁编码
        u8  work_channel;	//门锁工作信道
        u8  start_slice;	//起始时隙
        u8  end_slice;		//结束时隙
    } work_channel[20] __attribute__ ((packed));
}__attribute__ ((packed));

//应答：服务器应答
#define SVR_ECHO_LOCK_WORK_CHANNEL		0x4011
struct SVR_ECHO_LOCK_WORK_CHANNEL_INFO {
    u32 	status; 		//返回值，0：收到数据，1：数据出错
}__attribute__ ((packed));

//命令：网关向服务器汇报门锁嵌入式软件升级结果
#define CMD_NODE_LOCK_UPDATE_RESULT		0x1012
struct NODE_LOCK_UPDATE_RESULT_INFO {
    u8 lock_num; 			//门锁数量
    struct {
        u32 lock_id; 		//门锁编码
        u8  status;		//门锁升级结果，0：升级成功，1：升级失败
        //2：门锁离线，3：门锁通信出错
    } update_result[20] __attribute__ ((packed));
}__attribute__ ((packed));

//应答：服务器应答
#define SVR_ECHO_LOCK_UPDATE_RESULT		0x4012
struct SVR_ECHO_LOCK_UPDATE_RESULT_INFO {
    u32 	status; 		//返回值，0：收到数据，1：数据出错
}__attribute__ ((packed));

//命令：网关向服务器汇报网关嵌入式软件升级结果 网关在收到服务器下发的升级指令和数据后，开始升级，升级成功后，必须通知服务器，网关升级成功。

#define CMD_NODE_NODE_UPDATE_RESULT		0x1013
struct NODE_NODE_UPDATE_RESULT_INFO {
    u32  node_id;	//网关编码
    u32  status;		//网关升级结果，0：升级成功，1：升级失败
}__attribute__ ((packed));

//应答：
#define SVR_ECHO_NODE_UPDATE_RESULT		0x4013
struct SVR_ECHO_NODE_UPDATE_RESULT_INFO {
    u32 	status; 		//返回值，0：收到数据，1：数据出错
}__attribute__ ((packed));


//命令：网关向服务器汇报门锁随机生成的128位密钥
#define CMD_NODE_LOCK_KEY		0x1014
struct NODE_LOCK_KEY_INFO {
    u32 lock_id;			//门锁编码
    u8  lock_key_len;
    u8 lock_key[16];	//门锁秘钥
    u32 check_auth_data; //随机数的校验值
}__attribute__ ((packed));

//应答：
#define SVR_ECHO_LOCK_KEY		0x4014
struct SVR_ECHO_LOCK_KEY_INFO {
    u32 	status; 		//返回值，0：收到数据，1：数据出错
}__attribute__ ((packed));

//命令：网关向服务器汇报删除门锁普通密码结果
#define CMD_NODE_DEL_LOCK_PWD_RESULT		0x100C
struct NODE_DEL_LOCK_PWD_RESULT_INFO {
    u32 lock_id;			//门锁编码
    u32 serial_num;	//服务器请求网关删除门锁密码指令时流水单号
    u8  pwd_num;			//密码数量, pwd_num=255表示删除全部密码，
    u8  del_all_status;//删除全部密码的结果, 0：成功，1：失败
    //如果删除部分成功，部分失败，此变量没有意义,
    //采用下面的结构体应答
    //struct {
        u8  pwd_type;	//密码通道索引（1--30）
        u8 status;		//删除结果，0：删除成功，1：删除失败
    //} pwd_status[20] __attribute__ ((packed));
}__attribute__ ((packed));

//应答：服务器端收到应答删除所有密码结果
#define SVR_ECHO_DEL_LOCK_PWD_RESUTL 0x400C
struct SVR_ECHO_DEL_LOCK_PWD_RESULT_INFO {
    u32  status;			//返回值，0：成功收到，1：数据出错
}__attribute__ ((packed));

//命令：网关向服务器汇报删除门锁算法或一次性密码结果
#define CMD_NODE_DEL_LOCK_ALGORIM_PWD_RESULT		0x1015
struct NODE_DEL_LOCK_ALGORIM_PWD_RESULT_INFO {
    u32 lock_id;			//门锁编码
    u32 serial_num;	//服务器请求网关删除门锁密码指令时流水单号
    u8  pwd_num;			//密码数量
    struct {
        u8 Algorim_otp;//0:算法密码，1：一次性密码
        u8  pwd_type;	//密码通道索引（0--7）
        u8 status;		//删除结果，0：删除成功，1：删除失败
    } pwd_status[20] __attribute__ ((packed)) ;
}__attribute__ ((packed));

//应答：服务器端收到应答删除所有密码结果
#define SVR_ECHO_DEL_LOCK_ALGORIM_PWD_RESUTL 0x4015
struct SVR_ECHO_DEL_LOCK_ALGORIM_PWD_RESULT_INFO {
    u32  status;			//返回值，0：成功收到，1：数据出错
}__attribute__ ((packed));

//命令：网关向列表服务器请求可用服务器列表请求可传入要排除的服务器列表，如果没有可list_num为0。最多不超过5个，切返回数量不超过5个。
#define CMD_NODE_QUERY_SERVER_LIST		0x1017
struct NODE_QUERY_SERVER_LIST_INFO {
    u8 list_num;
    struct {
        u8 addr_len;//服务器地址的长度
        u8 svr_addr[32];//服务器的地址以及端口//需要注意端口的模式 //例如:www.huohetech.com:50000 //192.168.1.152:8080//只支持英文 ASCII 模式,不支持中文模式
    } exclude_list[5];
}__attribute__ ((packed));

//应答：服务器端收到应答返回可用的服务器列表
#define SVR_ECHO_QUERY_SERVER_LIST 0x4017
struct SVR_ECHO_QUERY_SERVER_LIST_INFO {
    u32 status; //0:成功,1:失败,2:格式不认以及其他
    u8 list_num;
    struct {
        u8 addr_len;//服务器地址的长度
        u8 svr_addr[32];//服务器的地址以及端口//需要注意端口的模式 //例如:www.huohetech.com:50000 //192.168.1.152:8080//只支持英文 ASCII 模式,不支持中文模式
    } svr_list[20];
}__attribute__ ((packed));

/*
 * ////////////////////不完整
网关收到Zigbee模组数据后，一方面应答发送方，一方面将数据转发给服务器。 命令
#define CMD_NODE_REPEAT_DATA		0x1018

        应答
应答：服务器端应答收到转发数据
#define SVR_ECHO_REPEAT_DATA 		0x4018
struct SVR_ECHO_REPEAT_DATA_INFO {
    u32  status;			//返回值，0：成功收到，1：数据出错
};
*/

/////////////////////////////////////////////////////////////////////////////////////////////////////
//5.2.23 网关向服务器上报GPRS网络信号强度(该指令目前为A830TG独有)(此指令不加密)
#define CMD_NODE_GPRS_RSSI				0x1010
struct CMD_NODE_GPRS_RSSI_INFO {
    u32 cap_time; 	//信号强度获取时间
    u8 rssi_level;		//取值范围为0~4
}__attribute__ ((packed));
//应答：服务器应答网关
#define SVR_RPY_NODE_GPRS_RSSI				0x4010
struct SVR_RPY_NODE_GPRS_RSSI_INFO {
    u32 status; 		//返回值，0：成功收到数据，1：数据出错
}__attribute__ ((packed));

//5.2.24 网关向服务器上报SIM卡的ICCID号(该指令目前为A830TG独有)
#define CMD_NODE_ICCID				0x101A
struct CMD_NODE_ICCID_INFO {
    u8 datalen;
    u8 iccid[20];
//iccid[]固定20字节长度，有效数据长度datalen
}__attribute__ ((packed));
//应答：服务器应答网关
#define SVR_RPY_NODE_ICCID				0x401A
struct SVR_RPY_NODE_ICCID_INFO {
    u32 status; 		//返回值，0：成功收到数据，1：数据出错
}__attribute__ ((packed));
//5.2.25 网关向服务器上报GPRS模块的固件版本号(该指令目前为A830TG独有)
#define CMD_NODE_GPRS_VERS				0x1019
struct CMD_NODE_GPRS_VERS_INFO {
    u8  datalen;
    u8 gprs_version[20];
//gprs_version[]固定长度20字节，有效长度datalen
}__attribute__ ((packed));
//应答：服务器应答网关
#define SVR_RPY_GPRS_VERS				0x4019
struct SVR_RPY_GPRS_VERS_INFO {
    u32 status; 		//返回值，0：成功收到数据，1：数据出错
}__attribute__ ((packed));

///////////////////////////////////////////////////////////////////////////////////////////////////
#define CMD_SVR_SET_LOCK_PWD			0x3000
struct SVR_SET_LOCK_PWD_INFO {
    u32 lock_id;				//门锁编码
    u8 pwd_num;            //密码数量
    //struct {
        u8 pwd_type;			//密码通道类型（0--30）
        u8 pwd_len;			//密码长度
        u8 pwd_en;			//密码启用标志：0：启用，1：禁用
        u8 RFID_pwd;			//密码或者RFID卡号，0：密码，1：卡号
        u8	pwd_op_flag;		//操作码：增加，删除，修改
        //0：增加
        //1：删除
        //2：修改
        u8 pwd[48];
        //密码，需要和门锁和网关通信部分的密
        //码表示方式一致，
        //密码需要用门锁密钥加密
        u32 start_time;		//开始时间，为格林尼治时间
        u32 end_time;		//结束时间，为格林尼治时间
  //  } pwd[20];
}__attribute__ ((packed));
/* 应答*/
#define NODE_ECHO_SET_PWD		0x2000
struct NODE_ECHO_SET_PWD_INFO {
    u32 status;				//返回值，0：收到数据，1：数据出错
}__attribute__ ((packed));

/*服务器请求网关解除门锁绑定*/
#define CMD_SVR_DEL_LOCK			0x3003

struct SVR_DEL_LOCK_INFO {
    u8 lock_num;					//门锁数量
    u32 lock_id;	//门锁编码
}__attribute__ ((packed));

/*应答：*/
#define NODE_ECHO_DEL_LOCK			0x2003
struct NODE_ECHO_DEL_LOCK_INFO {
    u8 lock_num;					//门锁数量
   // struct {
        u32 lock_id;				//门锁编码
        u32 status;				//0：解绑成功，1：解绑失败
    //} del_lock[20];
}__attribute__ ((packed));

/*命令：设置网关与门锁通信时隙*/
#define CMD_SVR_SET_TIME_SLICE			0x3004
struct SVR_SET_TIME_SLICE_INFO {
    u8 start_slice;		//起始时隙
    u8 end_slice;		//结束时隙
}__attribute__ ((packed));

/*应答：*/
#define NODE_ECHO_SET_TIME_SLICE		0x2004
struct NODE_ECHO_SET_TIME_SLICE_INFO {
    u32 status;			//0:设置成功，1:设置失败
}__attribute__ ((packed));

/*命令：查询网关和门锁通信时隙*/
#define CMD_SVR_QUERY_TIME_SLICE			0x3014
struct SVR_QUERY_TIME_SLICE_INFO {
    u32 status;		//保留参数，为0，没有使用
}__attribute__ ((packed));

/*应答：*/
#define NODE_ECHO_QUERY_TIME_SLICE		0x2014
struct NODE_ECHO_QUERY_TIME_SLICE_INFO {
    u32 status;			//0:查询成功，1:查询失败
    u8 start_slice;		//开始时隙
    u8 end_slice;		//结束时隙
}__attribute__ ((packed));

/*命令：设置网关的工作频点值*/
#define CMD_SVR_SET_NODE_WORK_CHANNEL		0x3005
struct SVR_SET_NODE_WORK_CHANNEL_INFO {
    u8 work_channel;		//网关工作信道
}__attribute__ ((packed));

/*应答：*/
#define NODE_ECHO_SET_NODE_WORK_CHANNEL		0x2005
struct NODE_ECHO_SET_NODE_WORK_CHANNEL_INFO {
    u32 status;				//返回值，0:设置成功，1:设置失败
}__attribute__ ((packed));

/*命令：查询网关的工作频点值*/
#define CMD_SVR_QUERY_NODE_WORK_CHANNEL		0x3015
struct SVR_QUERY_NODE_WORK_CHANNEL_INFO {
    u32 status;		//保留参数，为0，没用使用
}__attribute__ ((packed));

/*应答：*/
#define NODE_ECHO_QUERY_NODE_WORK_CHANNEL		0x2015
struct NODE_ECHO_QUERY_NODE_WORK_CHANNEL_INFO {
    u32 status;				//0:查询成功，1:查询失败
    u8 work_channel;			//网关工作信道
}__attribute__ ((packed));

/*命令：设置网关访问的服务器地址*/
#define CMD_SVR_SET_SERVER_ADDRESS	0x3006
struct SVR_SET_SERVER_ADDRESS_INFO {
    u8	 addr_len;					//服务器地址的长度
    u8 svr_addr[255];		//服务器的地址以及端口
//需要注意端口的模式
    //例如：www.huohetech.com:50000
    //192.168.1.152:8080
    //只支持英文ASCII模式，不支持中文模式
}__attribute__ ((packed));

/*应答：*/
#define NODE_ECHO_SET_SERVER_ADDRESS		0x2006
struct NODE_ECHO_SET_SERVER_ADDRESS_INFO {
    u32 status;				//0:成功，1:失败，2：格式不认以及其他
}__attribute__ ((packed));

/*命令：查询网关访问的服务器地址*/
#define CMD_SVR_QUERY_SERVER_ADDRESS		0x3016
struct SVR_QUERY_SERVER_ADDRESS_INFO {
    u32 status;		//保留参数，为0，没用使用
}__attribute__ ((packed));

/*应答：*/
#define NODE_ECHO_QUERY_SERVER_ADDRESS	0x2016
struct NODE_ECHO_QUERY_SERVER_ADDRESS_INFO {
    u32 status;				//0:查询成功，1:查询失败
    u8	 addr_len;				//服务器地址的长度
    char svr_addr[255];		//服务器的地址以及端口
//需要注意端口的模式
    //例如：huohetech.com:50000
    //192.168.1.152:8080
}__attribute__ ((packed));

/*命令：删除网关下门锁密码*/
#define CMD_SVR_DEL_LOCK_PWD			0x3007
struct SVR_DEL_LOCK_PWD_INFO {
    u32 lock_id;			//门锁编码
    u8  pwd_num;			//密码数量，pwd_num=255，删除门锁全部密码
    u8  pwd_type[30];  //密码类型
}__attribute__ ((packed));

/*应答：应答删除网关下门锁密码*/
#define NODE_ECHO_DEL_LOCK_PWD		0x2007
struct NODE_ECHO_DEL_LOCK_PWD_INFO {
    u32 status;			//返回值，0：数据收到，1：数据错误
}__attribute__ ((packed));

/*命令：重置门锁指令，等同于门锁系统复位。*/
#define CMD_SVR_SYS_RST_LOCK			0x3008
struct SVR_SYS_RST_LOCK_INFO {
    u32 lock_id;		//门锁编码
    u32 rst_data;	//随机数据
    u32 rst_data_check;	//检验数据
}__attribute__ ((packed));
/*
rst_data_check：校验值，校验rst_data,具体校验值的算法，由动态库单独给出。函数定义如下：
rst_data_check = check_lock_key( data,lock_key );
应答：
 */
#define NODE_ECHO_SYS_RST_LOCK			0x2008
struct NODE_ECHO_SYS_RST_LOCK_INFO {
    u32 status;		//返回值，0：数据收到，1：数据出错，2：门锁离线
}__attribute__ ((packed));

/*服务器通知网关固件升级*/

#define	CMD_SVR_DEVICE_UPDATE		0x3009
struct CMD_SVR_DEVICE_UPDATE_INFO{
u8     node_lock;		// 0：升级门锁，1：升级网关，2：升级电表
u8		hard_ver;			//硬件版本，门锁或网关当前版本（当为网关时，版本号为上报硬件版本U16的高8位）
u8     soft_ver;		//软件版本，升级的版本（当为网关时，版本号为上报软件版本U16的高8位）
u8		device_type;   	//设备类型
u8		device_factory; //设备生产厂家
u32		device_id;		//设备编码
u8	 	addr_len;			//文件服务器地址长度
char 	svr_addr[255];	//文件服务器的地址以及端口
//需要注意端口的模式
u32    CRC32;			//升级文件校验值
u32    CRC32_check;	//CRC32的校验值
}__attribute__ ((packed));
/*
CRC32_check：校验值，校验CRC32,具体校验值的算法，由动态库单独给出。函数定义如下：
CRC32_check = check_lock_key(CRC32,device_key );

应答：
 */
#define	NODE_ECHO_DEVICE_UPDATE		0x2009
struct NODE_ECHO_DEVICE_UPDATE_ACK{
    u32		status;		//返回值：0：成功收到，1：数据错误
}__attribute__ ((packed));


#define  CMD_SVR_QUERY_LOCK					0x300D
struct CMD_SVR_QUERY_LOCK_INFO{
    u32  	lock_id; 				//门锁编码
    u8     query_type; 			//查询数据类型
}__attribute__ ((packed));

//应答：
#define  NODE_ECHO_QUERY_LOCK				0x200D
struct NODE_ECHO_QUERY_LOCK_INFO {
    u32		lock_id ;	 			//门锁编码
    u32  	status;				//返回值，0：成功查询数据，1：查询失败
    u8     ack_type; 			//应答数据类型
    u8	 	ack_data[1024];  //应答数据
}__attribute__ ((packed));

/* 服务器通知网关重启门锁 */
#define  CMD_SVR_RESTART_LOCK					0x300E
struct CMD_SVR_RESTART_LOCK_INFO{
    u32  	lock_id; 				//门锁编码
}__attribute__ ((packed));

/*应答：*/
#define  NODE_ECHO_RESTART_LOCK				0x200E
struct NODE_ECHO_RESTART_LOCK_INFO {
    u32		lock_id ;	 			//门锁编码
    u32  	status;				//返回值，0：重启成功，1：重启失败
}__attribute__ ((packed));

/*命令：请求门锁开门*/
#define CMD_SVR_OPEN_DOOR			0x3010
struct Open_door_info1 {
    u8	open_door_type;			//加密类型
    u32 rand_data;		//32位不重复随机数
    u32 check_rand_data;	//rand_data校验值
}__attribute__ ((packed));
struct SVR_OPEN_DOOR_INFO {
    u32  lock_id;		//门锁编码
    Open_door_info1 Open_door_info;
}__attribute__ ((packed));

//应答：
#define NODE_ECHO_OPEN_DOOR		0x2010
struct NODE_ECHO_OPEN_DOOR_INFO {
    u32 lock_id;			//门锁编码
    u32 status;			//0:开门成功，1:开门失败
}__attribute__ ((packed));

#define CMD_SVR_DEL_LOCK_ALGORIM_PWD			0x3011
struct SVR_SET_DEL_LOCK_ALGORIM_PWD_INFO {
    u32 lock_id;				//门锁编码
    u8 pwd_num;            //密码数量
    struct {
        u8 Algorim_otp;		// 0：算法密码，1：一次性密码
        u8 pwd_type;			// 密码类型（0--7）
        u8 pwd_len;			//密码长度
        u8 pwd[20];
        //密码，需要和门锁和网关通信部分的密
        //码表示方式一致，
        //密码需要用门锁密钥加密
    } pwd;
}__attribute__ ((packed));

//应答：设置密码应答，表示网关收到服务器下发的门锁密码。
#define NODE_ECHO_DEL_LOCK_ALGORIM_PWD		0x2011
struct NODE_ECHO_DEL_LOCK_ALGORIM_PWD_INFO {
    u32 status;				//返回值，0：收到数据，1：数据出错
}__attribute__ ((packed));








/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

struct pwd {
    u8 pwd_type;		//密码类型
    u8 pwd_len;		//密码长度
    u8 pwd_en;		//密码启用标志：0：启用，1：禁用
    u8 RFID_pwd;		//密码或卡号，0：密码，1：卡号
    u8 pwd[(255+1)/2];
//密码，需要和门锁和网关通信部分的密
//码表示方式一致，
    //密码需要用门锁密钥加密
    u32 start_time;		//开始时间
    u32 end_time;		//结束时间
}__attribute__ ((packed));

struct Lock_time {
    u32 	lock_time;
    u16 	ms_time;
}__attribute__ ((packed));

struct Work_Channel {
    u8	channel_data;		//信道
    u8	start_slice;		//网关起始时隙，保留
    u8  end_slice;		//网关结束时隙，保留
}__attribute__ ((packed));

struct Lock_Pwr_Charge {
    u8	pwr_data;			//电池电量
    u32 pwr_cap_time;	//电量采集时间
}__attribute__ ((packed));
















};


#endif //GJ_TESTPLATFORM_GWTONHAP_H
