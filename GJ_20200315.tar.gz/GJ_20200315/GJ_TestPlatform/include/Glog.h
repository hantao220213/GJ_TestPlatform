//
// Created by hantao on 18-11-5.
//

#ifndef GJ_TESTPLATFORM_GLOG_H
#define GJ_TESTPLATFORM_GLOG_H

#include "glog/glog/logging.h"
#include "glog/glog/raw_logging.h"
#include "glog/glog/vlog_is_on.h"



using  namespace std;
int InitGLog(const char *program);



#endif //GJ_TESTPLATFORM_GLOG_H
