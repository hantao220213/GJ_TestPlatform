//
// Created by hantao on 18-12-15.
//

#include "ParseJsonFileLock.h"

LockDevice::LockDevice()
{
     lock_file="";
     Lock_Name="";
     _comment="";
     deviceName="";
     deviceType="";
     description="";

    divName="";
    actionSeriesName="";
    startTime="";
    repeatMode="";
    params="";
}
LockDevice::~LockDevice()
{

}
void LockDevice::setLockFilePaht(string file,string divName)
{
    lock_file = file;
    this->divName=divName;
}

int LockDevice::getLockDvAction()
{

    string string1="";
    if (getSimulatorParam(lock_file, string1) < 0) {
        LOG(ERROR) << " 获取文件:[" << lock_file << "]失败";
        return -1;
    }

    LOG(INFO)<<"DIV_NAME :"<<divName;

    Json::Reader reader;
    Json::Value value;
    Json::Value value1;
    Json::Value value3;

    reader.parse(string1, value);
    for (int k = 0; k < value.size(); ++k) {
        if (divName != value[k]["deviceName"].asString()){
            LOG(WARNING)<<" WARNING :"<<value[k]["deviceName"].asString();
            continue;
        }


        _comment = value[k]["_comment"].asString();
        deviceName = value[k]["deviceName"].asString();
        deviceType = value[k]["deviceType"].asString();
        description = value[k]["description"].asString();
        Json::Value par = value[k]["params"];
        if (!par.empty()){
            //解析params数组,待定
        }

        value1 = value[k]["actionSerials"];
        for (int i = 0; i < value1.size(); ++i)
        {

            actionSeriesName=value1[i]["actionSeriesName"].asString();
            startTime=value1[i]["startTime"].asString();
            repeatMode=value1[i]["repeatMode"].asString();

            Json::Value actions=value1[i]["actions"];

            for (int j = 0; j <actions.size() ; ++j)
            {
                DATA lockDATA;
                Json::Value action = actions[j]["action"];
                Json::Value params1=action["params"];


                lockDATA.timeInterval=actions[j]["timeInterval"].asString();
                lockDATA.action=action["actionName"].asString();
                lockDATA.data=params1.toStyledString();

                /*
                memset(&lockDATA,0x00,sizeof(DATA));
                string act=action["actionName"].asString();
                memcpy(lockDATA.action,act.c_str(),act.size());
                string data=params1.toStyledString();
                memcpy(lockDATA.data,data.c_str(),data.size());
                lockDATA.timeInterval=atoi(actions[j]["timeInterval"].asString().c_str());
                */
                LOCK_DATA.push(lockDATA);
            }

        }

    }
}